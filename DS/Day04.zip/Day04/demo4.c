#include<stdio.h>
void fun()
{
    static int no=1;
    if( no>10)
        return;
    else 
    {
        printf("\n%5d [%u]", no, &no);
        no++;
    }
    fun();
}
int main(void)
{
    fun();
    return 0;
}
