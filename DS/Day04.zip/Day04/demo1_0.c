#include<stdio.h>
struct node
{
    int data;  // data
    struct node *next;  // store address of its own type
};
// self ref structure contains pointers of its own  type (store address of its own type)
// as data member of structure
int main(void)
{
    return 0;
}