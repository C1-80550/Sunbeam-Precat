#include<stdio.h>

int main(void)
{
    static int no=1;
    if( no>10)
        return;
    else 
    {
        printf("\n%5d [%u]", no, &no);
        no++;
    }
    main();
    return 0;
}
