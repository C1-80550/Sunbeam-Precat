
// add_last ,add_first and display
#include<stdio.h>
#include<stdlib.h>
#pragma pack(1)
typedef struct node
{
    int data;  // data
    struct node *next;  // store address of its own type
}node_t;
// self ref structure contains pointers of its own  type (store address of its own type)
// as data member of structure
node_t *head;//struct node *head= NULL;
node_t* create_node(int value);
void display_list();
void add_first(int value);
void add_last(int value);
int main(void)
{
    display_list();

    add_last(10);
    display_list();

    add_last(20);
    display_list();

    add_last(30);
    display_list();
    
    add_last(40);
    display_list();
    
    return 0;
}
void add_last(int value)
{
    node_t * newnode=NULL;
    node_t *trav= NULL;
    newnode=create_node(value);
    if( head==NULL)  // if list is empty
        head=newnode;
    else
    {
        trav=head;  // go to 1st node of linked list
        while (trav->next!=NULL)
        {
            trav=trav->next;
        }
        // trav till last node of linked list
        trav->next=newnode;   // store address of new node in last node next pointer
        
    }
    return;
}
void display_list()
{
    node_t *trav=NULL;
    if( head== NULL)
    {
        printf("\n list is empty \n");
    }
    else
    {
        trav=head;
        while (trav!=NULL)
        {
            printf("%5d--->", trav->data);
            trav= trav->next;
        }
        printf("\n");
    }
    return;
}
void add_first(int value)
{
    node_t * newnode=NULL;
    newnode= create_node(value);
    if( head== NULL)  // if linked list is empty
    {
        head= newnode;   // store address of newnode into head pointer
    }
    else 
    {
        newnode->next= head;
        head=newnode;
    }
    return;
}
node_t* create_node(int value)
{
    node_t *new_node= NULL;
    new_node=(node_t*)malloc(sizeof(node_t)*1);
    if( new_node == NULL)
    {
        printf("\n unable to allocate memory");
        exit(0);
    }
    else 
    {
        new_node->data= value;
        new_node->next=NULL;
    }
    return new_node;
}