#include <stdio.h>
int main()
{
    static char *s = "SunBeam";
    char ch = *s;
    if(*s)
    {
        ++s; 
        main(); 
        printf("%c", ch);
    }
    return 0;
}  //print maeBnuS