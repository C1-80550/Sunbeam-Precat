// accept array of 6 int and sort it in asc order using selection sort
// array are pass by address/ reference / using pointer
#include<stdio.h>
#define SIZE 6
//void accept_array(int a[SIZE], int size);
void accept_array(int a[], int size);
void print_array(const int *a, int size);
void buble_sort_asc(int *a, int size);

int main(void)
{
    int arr[ SIZE ];

    printf("\n Enter elements of array =");
    accept_array(arr, SIZE);

    printf("\n Elements of array =");
    print_array(arr, SIZE);
    
    printf("\n asc sort using  buble sort ");
    buble_sort_asc(arr, SIZE);
    print_array(arr, SIZE);

    return 0;
}
void  buble_sort_asc(int *a, int size)
{
    int i, j, temp;
    for(i=0; i<size; i++) 
    {
        for( j=0; j<size-i-1; j++)
        {
            printf("\n a[%d] %d a[%d] %d", j,a[j], j+1,a[j+1]);
            if( a[j] > a[j+1])  //asc
            //if( a[j] < a[j+1])  //desc
            {  
                // swap using  temp variable
                temp=a[j];
                a[j]=a[j+1];
                a[j+1]=temp;
            }
        }
        if( i<size-1)
            printf("\n itration %d\n ", i+1);
    }
    return;
}
void accept_array(int a[], int size)
{
    int index;
    for( index=0; index<size; index++)
    {
        printf("\n arr[%d] =", index);
        scanf("%d", &a[index]);
    }    
    return;
}
void print_array(const int *a, int size)
{
    int index;
    for( index=0; index<size; ++index)
    {
        printf("\n arr[%d]  %5d   [%u]", index, a[index], &a[index]);
    }
    return;
}  // a[index]== *(a+index)   display
  //  index[a]== *(index+a)

  //  &a[index]== (a+index)   scan
  //  &index[a]== (index+a)
  