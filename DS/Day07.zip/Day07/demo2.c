
// add_last ,add_first and display
#include<stdio.h>
#include<stdlib.h>
#pragma pack(1)
typedef struct node
{
    int data;  // data
    struct node *next;  // store address of its own type
}node_t;
typedef struct list
{
    node_t *head;
}list_t;
// self ref structure contains pointers of its own  type (store address of its own type)
// as data member of structure
//struct node *head= NULL;
node_t* create_node(int value);
void init_list(list_t *list);
void display_list(list_t *list);
void add_first(list_t *list,int value);
void add_last(list_t *list,int value);
int main(void)
{
    list_t l1, l2;
    init_list(&l1);

    display_list(&l1);

    add_last(&l1,10);
    display_list(&l1);

    add_last(&l1,20);
    display_list(&l1);

    add_last(&l1,30);
    display_list(&l1);
    
    add_last(&l1,40);
    display_list(&l1);
    
    printf("\n list 2 \n");
    init_list(&l2);

    display_list(&l2);

    add_first(&l2,10);
    display_list(&l2);

    add_first(&l2,20);
    display_list(&l2);

    add_first(&l2,30);
    display_list(&l2);
    
    add_first(&l2,40);
    display_list(&l2);

    add_first(&l1, 99);
    display_list(&l1);

    add_last(&l2, 99);
    display_list(&l2);


    return 0;
}
void init_list(list_t *list)
{
    list->head=NULL;
}
void add_last(list_t *list,int value)
{
    node_t * newnode=NULL;
    node_t *trav= NULL;
    newnode=create_node(value);
    if( list->head==NULL)  // if list is empty
        list->head=newnode;
    else
    {
        trav=list->head;  // go to 1st node of linked list
        while (trav->next!=NULL)
        {
            trav=trav->next;
        }
        // trav till last node of linked list
        trav->next=newnode;   // store address of new node in last node next pointer
        
    }
    return;
}
void display_list(list_t *list)
{
    node_t *trav=NULL;
    if( list->head== NULL)
    {
        printf("\n list is empty \n");
    }
    else
    {
        trav=list->head;
        while (trav!=NULL)
        {
            printf("%5d--->", trav->data);
            trav= trav->next;
        }
        printf("\n");
    }
    return;
}
void add_first(list_t *list,int value)
{
    node_t * newnode=NULL;
    newnode= create_node(value);
    if( list->head== NULL)  // if linked list is empty
    {
        list->head= newnode;   // store address of newnode into head pointer
    }
    else 
    {
        newnode->next= list->head;
        list->head=newnode;
    }
    return;
}
node_t* create_node(int value)
{
    node_t *new_node= NULL;
    new_node=(node_t*)malloc(sizeof(node_t)*1);
    if( new_node == NULL)
    {
        printf("\n unable to allocate memory");
        exit(0);
    }
    else 
    {
        new_node->data= value;
        new_node->next=NULL;
    }
    return new_node;
}