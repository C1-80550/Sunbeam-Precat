// accept array of 6 int and sort it in asc order using selection sort using SWAP marco
// array are pass by address/ reference / using pointer
#include<stdio.h>
#define SIZE 6
//void accept_array(int a[SIZE], int size);
void accept_array(int a[], int size);
void print_array(const int *a, int size);
void inserion_sort(int *a, int size);
int main(void)
{
    int arr[ SIZE ];

    printf("\n Enter elements of array 1_3 =");
    accept_array(arr, SIZE);

    printf("\n Elements of array =");
    print_array(arr, SIZE);
    
    printf("\n asc sort using inserion_sort  ");
    inserion_sort(arr, SIZE);
    print_array(arr, SIZE);

    return 0;
}
void inserion_sort(int *a, int size)
{
    int i, j, key;
    for(i=1; i<size; i++)
    {
        j= i-1;
        key= a[i];
        print_array(a, size);
        while( j>=0 && key<=a[j] ) // asc
        {
            // shif elements towords it right side
            a[j+1]= a[j];
            j--;
        }
        // insert key into array
        a[j+1]= key;
        printf("\n key=%d j=%d", key, j);
        print_array(a, size);
    }
    return;
}
void accept_array(int a[], int size)
{
    int index;
    for( index=0; index<size; index++)
    {
        printf("\n arr[%d] =", index);
        scanf("%d", &a[index]);
    }    
    return;
}
void print_array(const int *a, int size)
{
    int index;
    for( index=0; index<size; ++index)
    {
        printf("\n arr[%d]  %5d   [%u]", index, a[index], &a[index]);
    }
    return;
}  // a[index]== *(a+index)
  //  index[a]== *(index+a)
// gcc -E -o demo1_3.i demo1_3.c