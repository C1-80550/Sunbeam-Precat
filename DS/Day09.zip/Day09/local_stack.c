// global stack
#include<stdio.h>
#define MAX 5
typedef struct  stack
{
    int arr[MAX];
    int top;
}STACK;
void init_stack(STACK *st);  // init top=-1 and all elements assign to -1
void push(STACK *st,int value);  // add element at top into stack
void pop(STACK *st);            // remove top most element from stack
int peek(const STACK *st);            // return top most element from stack
int is_empty(const STACK *st); 
int is_full(const STACK *st);
void print_stack(const STACK *st);
int menu_choice();
int main()
{
    STACK s1;  // local stack
    int choice, data;
    init_stack(&s1);     // ctor
    print_stack(&s1);  // s1.print_stack
    do
    {
        choice= menu_choice();
        switch(choice)
        {
            case 1:  // push
                if( !is_full(&s1))
                {
                    printf("\n Enter data=");
                    scanf("%d", &data);
                    push(&s1,data);
                }
                else 
                {
                    printf("\n stack is full");
                }
                break;
            case 2:  // pop
                {
                    if( !is_empty(&s1))
                    {
                        data= peek(&s1);
                        printf("\n pop=%d", data);
                        pop(&s1);
                    }
                    else    
                        printf("\n stack is empty");
                }
                    break;
            case 3:  // peek
                {
                    if( !is_empty(&s1))
                    {
                        data= peek(&s1);
                        printf("\n peek=%d", data);
                    }
                    else    
                        printf("\n stack is empty");
                }
                    break;
            case 4: // print stack
                    print_stack(&s1);
                    break;
            case 0:  return 0;  // exit(0);
        }   
        print_stack(&s1);
        printf("\n Enter 1 to contiue or 0 to exit ::");
        scanf("%d", &choice);
    } while (choice!=0);    
    return 0;
}

void push(STACK *st,int value)  // add element at top into stack
{
    st->top++;//top= top+1;  // increment value of top by 1
    st->arr[st->top]= value;  // add value at top most postion in array
    return;

}
void pop(STACK *st)           // remove top most element from stack
{
    st->arr[st->top]=-1; // over right top most elements data with -1
    st->top--;// top=top-1;  // decrement top by 1
    return;
}
int peek(const STACK *st)            // return top most element from stack
{
    int value;
    value= st->arr[st->top];  
    return value;     // return top most of array
}
int is_empty(const STACK *st)
{
    /*
    if( top==-1)
        return 1;  stack is empty
    else 
        return 0; // stack is not empty
    */
    // top==-1 ? return 1 : return 0;
    return (st->top==-1 ? 1 : 0 );
}
int is_full(const STACK *st)
{
    /*
    if( top== MAX-1) 
        return 1;  // stack is full
    else    
        return 0; // stack is not full
    */
   return (st->top==MAX-1 ? 1 : 0);
}
void print_stack(const STACK *st)
{
    int index;
    for( index= MAX-1; index>=0 ; index--)
    {
        printf("\n [  %d  ]   arr[%d]  [  %u  ]  ", st->arr[index], index, &st->arr[index]);
    }
    printf("\n top=%d \n", st->top);
    return;
}
void init_stack(STACK *st)
{
    int index=0;
    st->top=-1;
    for(index=0; index<MAX; index++)
    {
        st->arr[index]=-1;
    }
    return;
}
int menu_choice()
{
    int choice;
    printf("\n 1. Push \n 2. Pop \n 3. Peek \n 4, Print stack \n 0. Exit ");
    printf("\n Enter Your choice::");
    scanf("%d", &choice);
    return choice;
}