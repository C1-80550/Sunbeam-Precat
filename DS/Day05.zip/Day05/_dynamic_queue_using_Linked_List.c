#include <stdio.h>
#include <stdlib.h>
typedef struct node
{
	int data;
	struct node *next;
}node_t;
node_t *head; //add tail pointer here in code
//NODE *tail; //add tail pointer here in code
node_t* create_node(int value);
void add_last(int value); //push / insert /addqueue
void display_list();
int del_first(); // pop // delete //removequeue
//please implement pick and isempty functionality
void free_list();
int main(void)
{
	int data;
	add_last(10);
	add_last(20);
	add_last(30);
	add_last(40);
	display_list();

	data= del_first();
	printf("\n %d data node is deleted \n", data);
	display_list();

	data= del_first();
	printf("\n %d data node is deleted \n", data);
	display_list();

	data= del_first();
	printf("\n %d data node is deleted \n", data);
	display_list();

	data= del_first();
	printf("\n %d data node is deleted \n", data);
	display_list();

	free_list();

	return EXIT_SUCCESS;
}
node_t* create_node(int value)
{
	node_t* newnode=NULL;
	newnode= (node_t*)malloc(sizeof(node_t)*1);
	newnode->data=value;
	newnode->next=NULL;
	return newnode;
}
void display_list()
{
	node_t *trav=NULL;
	if(head==NULL)
		printf("\n linked list is empty\n");
	else
	{
		trav=head;
		while(trav!=NULL)
		{
			printf("%d---->", trav->data);
			trav=trav->next;
		}
	}
	printf("\n");
	return;
}
void add_last(int value)
{
	node_t* newnode=create_node(value);
	node_t* trav=NULL;
	if(head==NULL)
		head=newnode;
	else
	{
		trav=head;
		while(trav->next!=NULL)
		{
			trav=trav->next;
		}
		trav->next=newnode;
	}
	return;
}
int del_first()
{
	int value=0;
	node_t *temp=NULL;
	if(head==NULL)
		printf("\n List is empty ");
	else
	{
		temp=head;//1.1
		head= head->next;//1.2
		value= temp->data;//1.3
		free(temp);//1.4
		temp=NULL; //1.5
	}
	return value;
}
void free_list()
{
	node_t *temp=NULL;
	int value=0;
	while(head!=NULL)
	{
		temp=head;
		head=head->next;
		value=temp->data;
		free(temp);
		temp=NULL;
		printf("\n node whose data is %d deleted", value);
	}
	return;
}


