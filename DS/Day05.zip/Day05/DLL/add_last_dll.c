// add_last
// DLL with head and tail pointer
#include<stdio.h>
#include<stdlib.h>
typedef struct node
{
    struct node *prev;  // address
    int data;           // data   
    struct node *next;  // address
}node_t;
node_t *head; // struct node *head=NULL;
node_t *tail; // struct node *tail=NULL;
node_t* create_node(int value);
void add_last(int value);
void display_list();
int main(void)
{
    display_list();

    add_last(10);
    display_list();

    add_last(20);
    display_list();

    add_last(30);
    display_list();



    return 0;
}
void display_list()
{
    node_t *trav=NULL;
    if( head== NULL)
    {
        printf("\n list is empty \n");
    }
    else
    {
        printf("\n forword display");
        trav=head; // store address of 1st node into trav
        while (trav!=NULL)
        {
            printf("%5d--->", trav->data);  // print data of current node
            trav= trav->next; // goto next node
        }
        printf("\n");

        printf("\n backword display");
        trav=tail;// store address of last node into trav
        while (trav!=NULL)
        {
            printf("<-----%5d", trav->data);// print data of current node
            trav= trav->prev;// goto prev node
        }
        printf("\n");

    }
}
void add_last(int value)
{
    node_t *newnode=NULL;
    newnode= create_node(value);
    if( head== NULL) // if list is empty
    {
        head= newnode;   // store address of 1st node in head pointer
        tail= newnode;   // store address of  last node in tail pointer
    }
    else
    {
        newnode->prev=tail;  // store address of last node into prev of new node
        tail->next= newnode; // store address of new node into next of tail pointer
        tail= newnode; // store address of newnode into tail pointer
    }
    return;
}
node_t* create_node(int value)
{
    node_t *new_node= NULL;
    new_node= (node_t*)malloc(1*sizeof(new_node));
    if( new_node==NULL)
    {
        printf("\n unable to allocate memeory");
        exit(0);
    }
    else 
    {
        new_node->data= value;  // copy data
        new_node->next=NULL;    // assign next and prev pointers to NULL
        new_node->prev=NULL;
    }
    return new_node;
}