// accept elements array and display
// array are pass by address/ reference / using pointer
#include<stdio.h>
#define SIZE 6
//void accept_array(int a[SIZE], int size);
void accept_array(int a[], int size);
void print_array(const int *a, int size);
int main(void)
{
    int arr[ SIZE ], arr1[10];

    printf("\n Enter elements of array =");
    accept_array(arr, SIZE);

    printf("\n Elements of array =");
    print_array(arr, SIZE);

    printf("\n Enter elements of array1 =");
    accept_array(arr1, 10);

    printf("\n Elements of array1 =");
    print_array(arr1, 10);

    return 0;
}
void accept_array(int a[], int size)
{
    int index;
    for( index=0; index<size; index++)
    {
        printf("\n arr[%d] =", index);
        scanf("%d", &a[index]);
    }    
    return;
}
//void print_array(int const  *a, int size)
void print_array(const int *a, int size)
{
    int index;
    for( index=0; index<size; ++index)
    {
        printf("\n arr[%d]  %5d   [%u]", index, a[index], &a[index]);
    }
    return;
}
