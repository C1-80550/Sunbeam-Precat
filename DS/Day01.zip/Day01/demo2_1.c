// linear search or seq_search using function (strchr in string.h)
// 
#include<stdio.h>
#define SIZE 6
//void accept_array(int a[SIZE], int size);
void accept_array(int a[], int size);
void print_array(const int *a, int size);

int* seq_search(const int *a, int key, int size);

int main(void)
{
    int arr[ SIZE ], find, *ptr=NULL;


    printf("\n Enter elements of array =");
    accept_array(arr, SIZE);

    printf("\n Elements of array =");
    print_array(arr, SIZE);

    printf("\n Enter element of find 2_1 = ");
    scanf("%d", &find);

    ptr= seq_search(arr, find, SIZE);
    if(ptr==NULL)
        printf("\n %d is not found in array\n", find);
    else
        printf("\n %d is found in array at %d position\n", find, ptr-arr);
    
    return 0;
}
int* seq_search(const int *a, int key, int size)
{
    int index;
    for(index=0; index<size; ++index)
    {
        if( a[index]== key)
            return &a[index]; // return (a+index);    //return index when key found       
    }
    return NULL;  // return NULL index when key not found
}
void accept_array(int a[], int size)
{
    int index;
    for( index=0; index<size; index++)
    {
        printf("\n arr[%d] =", index);
        scanf("%d", &a[index]);
    }    
    return;
}
//void print_array(int const  *a, int size)
void print_array(const int *a, int size)
{
    int index;
    for( index=0; index<size; ++index)
    {
        printf("\n arr[%d]  %5d   [%u]", index, a[index], &a[index]);
    }
    return;
}
