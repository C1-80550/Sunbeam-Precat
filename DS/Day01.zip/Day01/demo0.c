/*
DS --   7 question

sorting & seraching  ----           2 que
      sorting   1.selection     2. buble  3. insertion   4.  merge  5. quick
      searching 1. linear/seq search (strchr) 2. binary search

stack and queue -                   2 que

linked lists    -                  1/2 que
Tree, graph , hashing     -        1/2 que
*/