// accept array of 6 int and sort it in asc order using selection sort using SWAP marco
// array are pass by address/ reference / using pointer
#include<stdio.h>
#define SIZE 6
//void accept_array(int a[SIZE], int size);
void accept_array(int a[], int size);
void print_array(const int *a, int size);
void selection_sort_asc(int *a, int size);
void swap(int *n1, int *n2);
#define SWAP(n1, n2, data_type) { data_type temp; temp=n1; n1=n2; n2=temp;}
int main(void)
{
    int arr[ SIZE ];

    printf("\n Enter elements of array 1_3 =");
    accept_array(arr, SIZE);

    printf("\n Elements of array =");
    print_array(arr, SIZE);
    
    printf("\n asc sort using selection sort ");
    selection_sort_asc(arr, SIZE);
    print_array(arr, SIZE);

    return 0;
}
void swap(int *n1, int *n2)
{
    int temp;
    temp=*n1;
    *n1=*n2;
    *n2=temp;
    return;
}
void selection_sort_asc(int *a, int size)
{
    int i, j, temp;
    for(i=0; i<size; i++) 
    {
        for( j=i+1; j<size; j++)
        {
            printf("\n a[%d] %d a[%d] %d", i,a[i], j,a[j]);
            if( a[i] > a[j])  //asc
            //if( a[i] < a[j])  //desc
            {  
                //way 1 swap using  temp variable
                 /*temp=a[i];
                   a[i]=a[j];
                   a[j]=temp;
                */
               // way2 using swap function
               //swap(&a[i], &a[j]);
                 //way3 using swap macro
                 SWAP(a[i], a[j], int);
            }
        }
        if( i<size-1)
            printf("\n itration %d\n ", i+1);
    }
    return;
}
void accept_array(int a[], int size)
{
    int index;
    for( index=0; index<size; index++)
    {
        printf("\n arr[%d] =", index);
        scanf("%d", &a[index]);
    }    
    return;
}
void print_array(const int *a, int size)
{
    int index;
    for( index=0; index<size; ++index)
    {
        printf("\n arr[%d]  %5d   [%u]", index, a[index], &a[index]);
    }
    return;
}  // a[index]== *(a+index)
  //  index[a]== *(index+a)
// gcc -E -o demo1_3.i demo1_3.c