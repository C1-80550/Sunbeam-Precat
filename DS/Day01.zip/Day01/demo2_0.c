// linear search or seq_search using function (strchr in string.h)
// 
#include<stdio.h>
#define SIZE 6
//void accept_array(int a[SIZE], int size);
void accept_array(int a[], int size);
void print_array(const int *a, int size);
int linear_search(const int *a, int key, int size);


int main(void)
{
    int arr[ SIZE ], find, ans;


    printf("\n Enter elements of array =");
    accept_array(arr, SIZE);

    printf("\n Elements of array =");
    print_array(arr, SIZE);

    printf("\n Enter element of find =");
    scanf("%d", &find);

    ans= linear_search(arr, find, SIZE);
    if(ans==-1)
        printf("\n %d is not found in array\n", find);
    else
        printf("\n %d is found in array at %d position\n", find, ans);
    
    return 0;
}
int linear_search(const int *a, int key, int size)
{
    int index;
    for(index=0; index<size; ++index)
    {
        if( a[index]== key)
            return index;     //return index when key found       
    }
    return -1;  // return -1 index when key not found
}
void accept_array(int a[], int size)
{
    int index;
    for( index=0; index<size; index++)
    {
        printf("\n arr[%d] =", index);
        scanf("%d", &a[index]);
    }    
    return;
}
//void print_array(int const  *a, int size)
void print_array(const int *a, int size)
{
    int index;
    for( index=0; index<size; ++index)
    {
        printf("\n arr[%d]  %5d   [%u]", index, a[index], &a[index]);
    }
    return;
}
