// global circular queue queue using array
#include<stdio.h>
#define MAX 5
int arr[MAX];
int front, rear;
void init_queue();  // init top=-1 and all elements assign to -1
void addq(int value);  // add element at rear into queue
void deleteq();            // remove front element from queue
int peek();            // return front element from queue
int is_empty(); 
int is_full();
void print_queue();
int menu_choice();
int main()
{
    int choice, data;
    init_queue();
    print_queue();
    do
    {
        choice= menu_choice();
        switch(choice)
        {
            case 1:  // add queue
                if( !is_full())
                {
                    printf("\n Enter data=");
                    scanf("%d", &data);
                    addq(data);
                }
                else 
                {
                    printf("\n queue is full \n");
                }
                break;
            case 2:  // delete from queue
                {
                    if( !is_empty())
                    {
                        data= peek();
                        printf("\n deleted from queue=%d\n", data);
                        deleteq();
                    }
                    else    
                        printf("\n queue is empty\n");
                }
                    break;
            case 3:  // peek
                {
                    if( !is_empty())
                    {
                        data= peek();
                        printf("\n peek=%d \n", data);
                    }
                    else    
                        printf("\n queue is empty\n");
                }
                    break;
            case 4: // print stack
                    print_queue();
                    break;
            case 0:  return 0;  // exit(0);
        }   
        print_queue();
        printf("\n Enter 1 to contiue or 0 to exit ::");
        scanf("%d", &choice);
    } while (choice!=0);    
    return 0;
}

void addq(int value)  // add element at top into stack
{
    if( rear== MAX-1)
        rear=0;
    else
        rear++;//rear= rear+1;  // increment value of rear by 1
    arr[rear]= value;  // add value at rear postion in array
    return;
}

void deleteq()           // remove top most element from stack
{
    if( front== MAX-1)
        front=0;
    else 
        front= front+1;  // incecrement front by 1        
    arr[front]=-1; // over right front elements data with -1
    if( front== rear)  // if rear== front then reset rear and front to -1
    {
           front= rear=-1; 
    }
    
    return;
}
int peek()            // return top most element from stack
{
    int value;
    if( front == MAX-1)
        value= arr[0];
    else 
        value= arr[front+1];  // -1+1=0  value= arr[0];
    return value;     // return top most of array
}
int is_empty()
{
    if( rear==-1 && front==-1)
        return 1; // queue is empty
    else 
        return 0; // queue id  not empty
}
int is_full()
{
    if( (front==-1 && rear== MAX-1) || ( rear== front && rear!=-1) )
        return 1; // queue is full
    else
        return 0;
}

void print_queue()
{
    int index;
    //for( index=0; index< MAX ; index++)
    for( index=0; index<= MAX-1 ; index++)
    {
        printf("\t arr[%d]", index);
    }
    printf("\n");
    for( index=0; index<= MAX-1 ; index++)
    {
        printf("\t   [%d]",arr[index]);
    }
    printf("\n front =%d  rear=%d\n",front, rear);
    return;
}
void init_queue()
{
    int index=0;
    front=rear=-1;  // at start rear front init to -1
    for(index=0; index<MAX; index++)
    {
        arr[index]=-1;  // all elements of array init  with -1
    }
    return;
}
int menu_choice()
{
    int choice;
    //printf("\n 1. add queue \n 2. delete queue \n 3. Peek \n 4, Print queue \n 0. Exit ");
    printf("\n Enter Your choice::");
    printf("\n 1. add queue  2. delete queue  3. Peek  4, Print queue  0. Exit \n ");

    scanf("%d", &choice);
    return choice;
}