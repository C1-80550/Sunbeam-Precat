// global stack (dyanamic memory allocation)
#include<stdio.h>
#include<stdlib.h>
int MAX;
int *arr; // int *arr=NULL;
int top;
void init_stack();  // init top=-1 and all elements assign to -1
void push(int value);  // add element at top into stack
void pop();            // remove top most element from stack
int peek();            // return top most element from stack
int is_empty(); 
int is_full();
void print_stack();
int menu_choice();
void free_array();
int main()
{
    int choice, data;
    init_stack();
    print_stack();
    do
    {
        choice= menu_choice();
        switch(choice)
        {
            case 1:  // push
                if( !is_full())
                {
                    printf("\n Enter data=");
                    scanf("%d", &data);
                    push(data);
                }
                else 
                {
                    printf("\n stack is full");
                }
                break;
            case 2:  // pop
                {
                    if( !is_empty())
                    {
                        data= peek();
                        printf("\n pop=%d", data);
                        pop();
                    }
                    else    
                        printf("\n stack is empty");
                }
                    break;
            case 3:  // peek
                {
                    if( !is_empty())
                    {
                        data= peek();
                        printf("\n peek=%d", data);
                    }
                    else    
                        printf("\n stack is empty");
                }
                    break;
            case 4: // print stack
                    print_stack();
                    break;
            case 0: 
                    free_array() ;
                    return 0;  // exit(0);
        }   
        print_stack();
        printf("\n Enter 1 to contiue or 0 to exit ::");
        scanf("%d", &choice);
    } while (choice!=0);    
    free_array();
    return 0;
}

void push(int value)  // add element at top into stack
{
    top++;//top= top+1;  // increment value of top by 1
    arr[top]= value;  // add value at top most postion in array
    return;

}
void pop()           // remove top most element from stack
{
    arr[top]=-1; // over right top most elements data with -1
    top--;// top=top-1;  // decrement top by 1
    return;
}
int peek()            // return top most element from stack
{
    int value;
    value= arr[top];  
    return value;     // return top most of array
}
int is_empty()
{
    /*
    if( top==-1)
        return 1;  stack is empty
    else 
        return 0; // stack is not empty
    */
    // top==-1 ? return 1 : return 0;
    return (top==-1 ? 1 : 0 );
}
int is_full()
{
    /*
    if( top== MAX-1) 
        return 1;  // stack is full
    else    
        return 0; // stack is not full
    */
   return (top==MAX-1 ? 1 : 0);
}
void print_stack()
{
    int index;
    for( index= MAX-1; index>=0 ; index--)
    {
        printf("\n [  %d  ]   arr[%d]  [  %u  ]  ", arr[index], index, &arr[index]);
    }
    printf("\n top=%d \n", top);
    return;
}
void init_stack()
{
    int index=0;
    printf("\n how many elemets you wnat=");
    scanf("%d", &MAX);
    arr=(int*) malloc(MAX*sizeof(int));
    if( arr==NULL)
    {
        printf("unable to allocate memory");
        return 0;
    }
    else 
    {
        top=-1;
        for(index=0; index<MAX; index++)
        {
            arr[index]=-1;
        }
    }
    return;
}
void free_array()
{
    if( arr!=NULL)
    {
        free(arr);
        arr=NULL;
        printf("\n mmeory is free");
    }
    return;
}
int menu_choice()
{
    int choice;
    printf("\n 1. Push \n 2. Pop \n 3. Peek \n 4, Print stack \n 0. Exit ");
    printf("\n Enter Your choice::");
    scanf("%d", &choice);
    return choice;
}