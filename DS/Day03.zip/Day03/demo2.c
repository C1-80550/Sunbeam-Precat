// global linear queue using array
#include<stdio.h>
#define MAX 5
int arr[MAX];
int front, rear;
void init_queue();  // init top=-1 and all elements assign to -1
void addq(int value);  // add element at rear into queue
void deleteq();            // remove front element from queue
int peek();            // return front element from queue
int is_empty(); 
int is_full();
void print_queue();
int menu_choice();
int main()
{
    int choice, data;
    init_queue();
    print_queue();
    do
    {
        choice= menu_choice();
        switch(choice)
        {
            case 1:  // add queue
                if( !is_full())
                {
                    printf("\n Enter data=");
                    scanf("%d", &data);
                    addq(data);
                }
                else 
                {
                    printf("\n queue is full \n");
                }
                break;
            case 2:  // delete from queue
                {
                    if( !is_empty())
                    {
                        data= peek();
                        printf("\n deleted from queue=%d", data);
                        deleteq();
                    }
                    else    
                        printf("\n queue is empty\n");
                }
                    break;
            case 3:  // peek
                {
                    if( !is_empty())
                    {
                        data= peek();
                        printf("\n peek=%d", data);
                    }
                    else    
                        printf("\n queue is empty\n");
                }
                    break;
            case 4: // print stack
                    print_queue();
                    break;
            case 0:  return 0;  // exit(0);
        }   
        print_queue();
        printf("\n Enter 1 to contiue or 0 to exit ::");
        scanf("%d", &choice);
    } while (choice!=0);    
    return 0;
}

void addq(int value)  // add element at top into stack
{
    rear++;//rear= rear+1;  // increment value of rear by 1
    arr[rear]= value;  // add value at rear postion in array
    return;
}

void deleteq()           // remove top most element from stack
{
    front= front+1;  // incecrement front by 1
    arr[front]=-1; // over right front elements data with -1
    
    return;
}
int peek()            // return top most element from stack
{
    int value;
    value= arr[front+1];  // -1+1=0  value= arr[0];
    return value;     // return top most of array
}
int is_empty()
{
    /*
   if( rear==front)   // if(rear==front)  if(-1 == -1)   true    if(4==4)
        return 1;    true
    else
        return 0;    false
    */      
   return (rear==front ? 1 : 0); 
}
int is_full()
{
    /*
    if( rear== MAX-1)    // 4== 5-1    4==4   (index 0 to 4 means 5 elements
        return 1;  // queue is full
    else    
        return 0; // queue is not full
    */
   return (rear==MAX-1 ? 1 : 0);
}

void print_queue()
{
    int index;
    //for( index=0; index< MAX ; index++)
    for( index=0; index<= MAX-1 ; index++)
    {
        printf("\t arr[%d]", index);
    }
    printf("\n");
    for( index=0; index<= MAX-1 ; index++)
    {
        printf("\t   [%d]",arr[index]);
    }
    printf("\n front =%d  rear=%d\n",front, rear);
    return;
}
void init_queue()
{
    int index=0;
    front=rear=-1;  // at start rear front init to -1
    for(index=0; index<MAX; index++)
    {
        arr[index]=-1;  // all elements of array init  with -1
    }
    return;
}
int menu_choice()
{
    int choice;
    printf("\n 1. add queue \n 2. delete queue \n 3. Peek \n 4, Print queue \n 0. Exit ");
    printf("\n Enter Your choice::");
    scanf("%d", &choice);
    return choice;
}