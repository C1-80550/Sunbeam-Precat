// add_last
// DLL with head 
#include<stdio.h>
#include<stdlib.h>
typedef struct node
{
    struct node *prev;  // address
    int data;           // data   
    struct node *next;  // address
}node_t;
node_t *head; // struct node *head=NULL;
node_t* create_node(int value);
void add_last(int value);
void display_list();
int main(void)
{
    display_list();

    add_last(10);
    display_list();

    add_last(20);
    display_list();

    add_last(30);
    display_list();

    add_last(40);
    display_list();

    add_last(50);
    display_list();
    return 0;
}
void display_list()
{
    node_t *trav=NULL, *temp=NULL;
    if( head== NULL)
    {
        printf("\n list is empty \n");
    }
    else
    {
        printf("\n forword display");
        trav=head; // store address of 1st node into trav
        do
        {
            temp=trav;
            printf("%5d--->", trav->data);  // print data of current node
            trav= trav->next; // goto next node
        }while (trav!=head); // trav till last node next pointer(head)
        printf("\n");

       
        printf("\n backword display");
        trav=temp;// store address of last node into trav
        do
        {
            printf("<-----%5d", trav->data);// print data of current node
            trav= trav->prev;// goto prev node
        }while (trav!=temp);
        printf("\n");
        printf("\n===================================\n");
    }
}
void add_last(int value)
{
    node_t *newnode=NULL, *trav=NULL;
    newnode= create_node(value);
    if( head== NULL) // if list is empty
    {
        head= newnode;   // store address of 1st node in head pointer
        newnode->next= head;//// store address 1st node in to newnodes next pointer
        newnode->prev=head; // store address last node in to newnodes prev pointer
    }
    else
    {

       trav=head; // keep the address of 1st node into trav pointre
       while(trav->next!=head )  // trav till last node of linked list ( last->next 1st node(head))
       {
            trav=trav->next;  // go to next node in linked list
       }
       newnode->prev= trav;  // keep the address of current last node into new nodes prev pointer
       newnode->next= head;  // keep the address 1st node into new nodes next pointer
       trav->next= newnode; //  keep the address of new node into trav->next (current last node)
       head->prev= newnode; // kepp the address of new node intp prev pointer of 1st node(head)

       
    }
    return;
}
node_t* create_node(int value)
{
    node_t *new_node= NULL;
    new_node= (node_t*)malloc(1*sizeof(new_node));
    if( new_node==NULL)
    {
        printf("\n unable to allocate memeory");
        exit(0);
    }
    else 
    {
        new_node->data= value;  // copy data
        new_node->next=NULL;    // assign next and prev pointers to NULL
        new_node->prev=NULL;
    }
    return new_node;
}