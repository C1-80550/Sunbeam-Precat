
// add_Last and display for Singly Circular LinkedList with head and tail pointer // SCLL SCL
#include<stdio.h>
#include<stdlib.h>
#pragma pack(1)
typedef struct node
{
    int data;  // data
    struct node *next;  // store address of its own type
}node_t;
node_t *head;//struct node *head= NULL;
node_t *tail;//struct node *tail= NULL;
node_t* create_node(int value);
void display_list();
void add_last(int value);
int main(void)
{
    display_list();

    add_last(10);
    display_list();

    add_last(20);
    display_list();

    add_last(30);
    display_list();
    
    add_last(40);
    display_list();

    add_last(50);
    display_list();
    
    return 0;
}
void display_list()
{
    node_t *trav=NULL;
    if( head== NULL)
    {
        printf("\n list is empty \n");
    }
    else
    {
        trav=head;
        do
        {
            printf("%5d--->", trav->data);
            trav= trav->next;
        }while (trav!=head);
        printf("\n");
    }
    return;
}
void add_last(int value)
{
    node_t * newnode=NULL;
    newnode= create_node(value);
    if( head== NULL)  // if linked list is empty
    {
        head= newnode;   // store address of newnode into head pointer
        tail=newnode;   // store address of newnode into tail pointer
        newnode->next= head; // keep the address of 1st node into new nodes next pointer
    }
    else 
    {
        newnode->next= head;  // keep the address of 1st node into new node next
        tail->next= newnode; // keep the of addeess of new node into last nodes next pointer
        tail=newnode; // kepp the address of new node into tail pointer
    }
    return;
}
node_t* create_node(int value)
{
    node_t *new_node= NULL;
    new_node=(node_t*)malloc(sizeof(node_t)*1);
    if( new_node == NULL)
    {
        printf("\n unable to allocate memory");
        exit(0);
    }
    else 
    {
        new_node->data= value;
        new_node->next=NULL;
    }
    return new_node;
}