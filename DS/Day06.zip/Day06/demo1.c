#include<stdio.h>
int sum(int n1, int n2);
int main(void)
{
    int ans;
    int (*funptr)(int num1, int num2);
    /* funptr is pointer to function which recives2 parameters of int type
     & return integer */
    funptr= sum;
    printf("\n addition of 2 numbers using sum %d", sum(10,20));
    printf("\n addition of 2 numbers using funptr %d using old syntax", (*funptr)(10,20));
    printf("\n addition of 2 numbers using funptr %d using new syntax", funptr(10,20));
    return 0;
}
int sum(int n1, int n2)
{
    return n1+n2;
}