#include<stdio.h>
int sum(int n1, int n2);
int minus(int n1, int n2);
int multiply(int n1, int n2);

int main(void)

{
    int ans, index;
    int (*funptr[3])(int num1, int num2);
    /* funptr is array of 3 function pointers, where each
pointer points to a function which receives two parameters and
return integer */
    funptr[0]= sum;
    funptr[1]= minus;
    funptr[2]= multiply;

    
    //printf("\n addition of 2 numbers using funptr %d using old syntax", (*funptr)(10,20));
    for( index=0; index<3; index++)
        printf("\n using funptr %d using new syntax", funptr[index](10,20));


        funptr[2]= sum;
    funptr[1]= minus;
    funptr[0]= multiply;

    
    //printf("\n addition of 2 numbers using funptr %d using old syntax", (*funptr)(10,20));
    for( index=0; index<3; index++)
        printf("\n using funptr %d using new syntax", funptr[index](10,20));
    return 0;
}
int sum(int n1, int n2)
{
    return n1+n2;
}
int minus(int n1, int n2)
{
    return n1-n2;
}
int multiply(int n1, int n2)
{
    return n1*n2;
}