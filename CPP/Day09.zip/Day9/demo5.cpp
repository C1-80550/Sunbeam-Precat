//virtual functions
#include<iostream>
using namespace std;

class Base 
{
    private:
        int a;
        int b;
    public:
        Base()
        {
            this->a=0;
            this->b=0;
            cout<<"inside parameterless ctor of base class "<<endl;
        }
        Base(int a, int b)
        {
            this->a=a;
            this->b=b;
            cout<<"inside parameterzied ctor of base class "<<endl;
        }
        virtual void print()
        {
            cout<<"inside class base"<<endl;
            cout<<"this->a="<<this->a<<" \t["<<&this->a<<"]"<<endl;
            cout<<"this->b="<<this->b<<" \t["<<&this->b<<"]"<<endl;
        }
        ~Base()
        {
            this->a=0;
            this->b=0;
            cout<<"inside dtor of base class "<<endl;
        }

};// end of base class
class Derived: public Base
{
    private:
        int c;
public:
        Derived()
        {
            this->c=0;
            cout<<"inside parameterless ctor of Derived class "<<endl;
        }
        Derived(int a, int b, int c):Base(a, b)
        {
            this->c=c;            
            cout<<"inside parameterzied ctor of Derived class "<<endl;
        }
        void print()
        {
            Base::print();
            cout<<"inside class Derived"<<endl;
            cout<<"this->c="<<this->c<<" \t["<<&this->c<<"]"<<endl;
            
        }
        ~Derived()
        {
            this->c=0;
            cout<<"inside dtor of Derived class "<<endl;
        }
    

};// end of Derived class

int main(void)
{
    Base *ptrBase1= new Derived; // upcasting
    cout<<"ptrBase1="<<endl;
    ptrBase1->print();  // print is virtual fun Derived:: print();
    delete ptrBase1;
    ptrBase1=NULL;

    Base *ptrBase2=NULL; 
    Derived objDerived2;
    ptrBase2= &objDerived2;  // upcasting
    cout<<"ptrBase2="<<endl;
    ptrBase2->print();  // print is virtual fun Derived:: print();


    //Derived *ptrDerived1=new Base;  // downcasting error

    Derived *ptrDerived2=NULL;
    Base objObject2;
  //  ptrDerived2= &objObject2;  // down casting error
   // cout<<"ptrDerived2="<<endl;
  //  ptrDerived2->print();  //  error;


    




    
    return 0;
}