/*

//0  Diamond Problem  
//1. casting upcasting /downcasting
//2. object slicing
//3. virtual function / pure virtual function
//4. function overriding
//5. RTTI
//6. casting operator
 and multipl file demo



*/

