//  object slicing
#include<iostream>
using namespace std;

class Base 
{
    private:
        int a;
        int b;
    public:
        Base()
        {
            this->a=0;
            this->b=0;
            cout<<"inside parameterless ctor of base class "<<endl;
        }
        Base(int a, int b)
        {
            this->a=a;
            this->b=b;
            cout<<"inside parameterzied ctor of base class "<<endl;
        }
        void print()
        {
            cout<<"inside class base"<<endl;
            cout<<"this->a="<<this->a<<" \t["<<&this->a<<"]"<<endl;
            cout<<"this->b="<<this->b<<" \t["<<&this->b<<"]"<<endl;
        }
        ~Base()
        {
            this->a=0;
            this->b=0;
            cout<<"inside dtor of base class "<<endl;
        }

};// end of base class
class Derived: public Base
{
    private:
        int c;
public:
        Derived()
        {
            this->c=0;
            cout<<"inside parameterless ctor of Derived class "<<endl;
        }
        Derived(int a, int b, int c):Base(a, b)
        {
            this->c=c;            
            cout<<"inside parameterzied ctor of Derived class "<<endl;
        }
        void print()
        {
            Base::print();
            cout<<"inside class Derived"<<endl;
            cout<<"this->c="<<this->c<<" \t["<<&this->c<<"]"<<endl;
            
        }
        ~Derived()
        {
            this->c=0;
            cout<<"inside dtor of Derived class "<<endl;
        }
    

};// end of Derived class

int main(void)
{
    Base  objBase1;  // parameterless 
    cout<<"objBase1="<<endl;
    objBase1.print(); // a=0  b=0

    Derived objDerived1(50,60,70);
    cout<<"objDerived1="<<endl;
    objDerived1.print(); // a=50  b=60 c=70

//    2         3
    objBase1= objDerived1;  // object slicing
    cout<<"objBase1="<<endl;
    objBase1.print(); // a=50  b=60

  // 3             2
   // objDerived1= objBase1  // error
    


}