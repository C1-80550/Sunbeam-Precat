// diamond pro sol no1

#define sizeof_var( var ) ((size_t)(&(var)+1)-(size_t)(&(var))) 
#pragma pack(1)
#include<iostream>
using namespace std;
namespace NDiamindProblem
{
    class A
    {
        private:
            int a;
        public:
            A()
            {
                this->a=10;
                cout<<"inside parameterless ctor of Class A"<<endl;
            }

            A(int a)
            {
                this->a=a;
                cout<<"inside parameterized ctor of Class A"<<endl;
            }
            void Print()
            {
                cout<<"inside class A::"<<endl;
                cout<<"this->a ="<<this->a<<"\t["<<&this->a<<"]"<<endl;
            }
            ~A()
            {
                this->a=0;
                cout<<"inside dtor of Class A"<<endl;
            }
  
            
    }; // end of class A

    class B:virtual public A
    {
        private:
            int b;
        public:
            B()
            {
                this->b=20;
                cout<<"inside parameterless ctor of Class B"<<endl;
            }
        
            B(int a, int b):A(a)
            {
                this->b=b;
                cout<<"inside parameterized ctor of Class B"<<endl;
            }
            void Print()
            {
                A::Print();
                cout<<"inside class B::"<<endl;
                cout<<"this->b ="<<this->b<<"\t["<<&this->b<<"]"<<endl;
            }
            void PrintOnlyB()
            {
                cout<<"inside class B::"<<endl;
                cout<<"this->b ="<<this->b<<"\t["<<&this->b<<"]"<<endl;
            }
            
            ~B()
            {
                this->b=0;
                cout<<"inside dtor of Class B"<<endl;
            }
  
            
    }; // end of class B

     class C: virtual public A
    {
        private:
            int c;
        public:
            C()
            {
                this->c=30;
                cout<<"inside parameterless ctor of Class C"<<endl;
            }

            C(int a, int c):A(a)
            {
                this->c=c;
                cout<<"inside parameterized ctor of Class C"<<endl;
            }
            void Print()
            {
                A::Print();
                cout<<"inside class C::"<<endl;
                cout<<"this->c ="<<this->c<<"\t["<<&this->c<<"]"<<endl;
            }
            void PrintOnlyC()
            {
                cout<<"inside class C::"<<endl;
                cout<<"this->c ="<<this->c<<"\t["<<&this->c<<"]"<<endl;
            }
            ~C()
            {
                this->c=0;
                cout<<"inside dtor of Class C"<<endl;
            }
  
            
    }; // end of class C


    //
   // class D: public C, public B
   class D: public B, public C
    {
        private:
            int d;
        public:
            D()
            {
                this->d=40;
                cout<<"inside parameterless ctor of Class D"<<endl;
            }

            D(int a, int b, int c, int d):B(a,b),C(a,c),A(a)
            {
                this->d=d;
                cout<<"inside parameterized ctor of Class D"<<endl;
            }
            void Print()
            {
                A::Print();
                B::PrintOnlyB();
                C::PrintOnlyC();
                cout<<"inside class D::"<<endl;
                cout<<"this->d ="<<this->d<<"\t["<<&this->d<<"]"<<endl;

            }
            ~D()
            {
                this->d=0;
                cout<<"inside dtor of Class D"<<endl;
            }
  
            
    }; // end of class D

} //end of namespace
using namespace NDiamindProblem;
int main()
{
    /*
    A obj1;  // parmeterless ctor A
    cout<<"obj1="<<endl;
    obj1.Print();
    cout<<"size of obj1="<<sizeof(obj1)<<endl;// 4 bytes
    

    A obj2(111);  // parmeterized ctor A
    cout<<"obj2="<<endl;
    obj2.Print();
    cout<<"size of obj2="<<sizeof(obj2)<<endl;// 4 bytes
    cout<<"sizeof_var( obj2)="<<sizeof_var(obj2)<<endl;  // 4 bytes
    
    */

   /*
    B obj1;  // parmeterless ctor A, B
    cout<<"obj1="<<endl;
    obj1.Print();                               // A B pointer
    cout<<"size of obj1="<<sizeof(obj1)<<endl;  // 4+4+4=12 bytes
    

    B obj2(111,222);  // parmeterized ctor A, B
    cout<<"obj2="<<endl;
    obj2.Print();                               // A B pointer
    cout<<"size of obj2="<<sizeof(obj2)<<endl;  // 4+4+4=12 bytes

    cout<<"sizeof_var( obj2)="<<sizeof_var(obj2)<<endl;
    
   */
  /*
   C obj1;  // parmeterless ctor A, C
    cout<<"obj1="<<endl;
    obj1.Print();
    cout<<"size of obj1="<<sizeof(obj1)<<endl;  // 4+4+4=12 bytes
    

    C obj2(111,333);  // parmeterized ctor A, C
    cout<<"obj2="<<endl;
    obj2.Print();
    cout<<"size of obj2="<<sizeof(obj2)<<endl;  // 4+4+4=12 bytes
    cout<<"sizeof_var( obj2)="<<sizeof_var(obj2)<<endl;
    */


    D obj1;  // parmeterless ctor A,B,C, D
    cout<<"obj1="<<endl;
    obj1.Print();
    cout<<"size of obj1="<<sizeof(obj1)<<endl;  // 4+8+8+4 =24 bytes

    

    D obj2(111,222,333,444);  // parmeterized ctor A, B,  C, D
    cout<<"obj2="<<endl;
    obj2.Print();
    cout<<"size of obj2="<<sizeof(obj2)<<endl;  // 4+4=8 bytes
    cout<<"sizeof_var( obj2)="<<sizeof_var(obj2)<<endl;

    
  
    return 0;
}


















