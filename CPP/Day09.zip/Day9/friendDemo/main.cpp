#include<iostream>
using namespace std;
#include"frienddemo.h"
int main(void)
{
    cout<<"// multiple file demo - return_type classname::Member_Function(datatype parameters)"<<endl;
    sum();
    return 0;
}

//g++ frienddemo.cpp main.cpp ---> // ./a.out
