class FriendDemo
{
    private:
        int a;
        int b;
    public:
    // member function decl
        FriendDemo();
        FriendDemo(int a, int b);
        void print();
        ~FriendDemo();        
        friend void sum();        
}; //end of class
 void sum();