// diamond pro sol no1
#define sizeof_var( var ) ((size_t)(&(var)+1)-(size_t)(&(var))) 
#include<iostream>
using namespace std;
namespace NDiamindProblem
{
    class A
    {
        public:
            int a;
            A()
            {
                this->a=10;
                cout<<"inside parameterless ctor of Class A"<<endl;
            }

            A(int a)
            {
                this->a=a;
                cout<<"inside parameterized ctor of Class A"<<endl;
            }
            void Print()
            {
                cout<<"inside class A::"<<endl;
                cout<<"this->a ="<<this->a<<"\t["<<&this->a<<"]"<<endl;
            }
            ~A()
            {
                this->a=0;
                cout<<"inside dtor of Class A"<<endl;
            }
  
            
    }; // end of class A

     class B: public A
    {
        public:
            int b;
            B()
            {
                this->b=20;
                cout<<"inside parameterless ctor of Class B"<<endl;
            }

            B(int a, int b):A(a)
            {
                this->b=b;
                cout<<"inside parameterized ctor of Class B"<<endl;
            }
            void Print()
            {
                A::Print();
                cout<<"inside class B::"<<endl;
                cout<<"this->a ="<<this->a<<"\t["<<&this->a<<"]"<<endl;
                cout<<"this->b ="<<this->b<<"\t["<<&this->b<<"]"<<endl;
            }
            ~B()
            {
                this->b=0;
                cout<<"inside dtor of Class B"<<endl;
            }
  
            
    }; // end of class B

     class C: public A
    {
        public:
            int c;
            C()
            {
                this->c=30;
                cout<<"inside parameterless ctor of Class C"<<endl;
            }

            C(int a, int c):A(a)
            {
                this->c=c;
                cout<<"inside parameterized ctor of Class C"<<endl;
            }
            void Print()
            {
                A::Print();
                cout<<"inside class C::"<<endl;
                cout<<"this->a ="<<this->a<<"\t["<<&this->a<<"]"<<endl;
                cout<<"this->c ="<<this->c<<"\t["<<&this->c<<"]"<<endl;
            }
            ~C()
            {
                this->c=0;
                cout<<"inside dtor of Class C"<<endl;
            }
  
            
    }; // end of class C


    //
   // class D: public C, public B
   class D: public B, public C
    {
        public:
            int d;
            D()
            {
                this->d=40;
                cout<<"inside parameterless ctor of Class D"<<endl;
            }

            D(int a, int b, int c, int d):B(a,b),C(a,c)
            {
                this->d=d;
                cout<<"inside parameterized ctor of Class D"<<endl;
            }
            void Print()
            {
                B::Print();
                C::Print();
                cout<<"inside class D::"<<endl;
                //"NDiamindProblem::D::a" is ambiguous  via class B , class C   
                //cout<<"this->a ="<<this->a<<"\t["<<&this->a<<"]"<<endl;

                // sol of diamond problem
                cout<<"this->B::a = via class B = "<<this->B::a<<"\t["<<&this->B::a<<"]"<<endl;
                cout<<"this->C::a = via class C = "<<this->C::a<<"\t["<<&this->C::a<<"]"<<endl;
                cout<<"this->b ="<<this->b<<"\t["<<&this->b<<"]"<<endl;
                cout<<"this->c ="<<this->c<<"\t["<<&this->c<<"]"<<endl;
                cout<<"this->d ="<<this->d<<"\t["<<&this->d<<"]"<<endl;

            }
            ~D()
            {
                this->d=0;
                cout<<"inside dtor of Class D"<<endl;
            }
  
            
    }; // end of class D

} //end of namespace
using namespace NDiamindProblem;
int main()
{
    /*
    A obj1;  // parmeterless ctor
    cout<<"obj1="<<endl;
    obj1.Print();
    cout<<"size of obj1="<<sizeof(obj1)<<endl;// 4 bytes
    cout<<"obj1.a in main="<<obj1.a<<endl;

    A obj2(111);  // parmeterized ctor
    cout<<"obj2="<<endl;
    obj2.Print();
    cout<<"size of obj2="<<sizeof(obj2)<<endl;// 4 bytes
    cout<<"sizeof_var( obj2)="<<sizeof_var(obj2)<<endl;  // 4 bytes
    cout<<"obj2.a in main="<<obj2.a<<endl;
    */

   /*
    B obj1;  // parmeterless ctor A, B
    cout<<"obj1="<<endl;
    obj1.Print();
    cout<<"size of obj1="<<sizeof(obj1)<<endl;  // 4+4=8 bytes
    cout<<"obj1.a in main="<<obj1.a<<endl;
    cout<<"obj1.b in main="<<obj1.b<<endl;


    B obj2(111,222);  // parmeterized ctor A, B
    cout<<"obj2="<<endl;
    obj2.Print();
    cout<<"size of obj2="<<sizeof(obj2)<<endl;  // 4+4=8 bytes
    cout<<"sizeof_var( obj2)="<<sizeof_var(obj2)<<endl;
    cout<<"obj2.a in main="<<obj2.a<<endl;
    cout<<"obj2.b in main="<<obj2.b<<endl;
   */
  
  /* C obj1;  // parmeterless ctor A, C
    cout<<"obj1="<<endl;
    obj1.Print();
    cout<<"size of obj1="<<sizeof(obj1)<<endl;  // 4+4=8 bytes
    cout<<"obj1.a in main="<<obj1.a<<endl;
    cout<<"obj1.c in main="<<obj1.c<<endl;


    C obj2(111,333);  // parmeterized ctor A, C
    cout<<"obj2="<<endl;
    obj2.Print();
    cout<<"size of obj2="<<sizeof(obj2)<<endl;  // 4+4=8 bytes
    cout<<"sizeof_var( obj2)="<<sizeof_var(obj2)<<endl;
    cout<<"obj2.a in main="<<obj2.a<<endl;
    cout<<"obj2.c in main="<<obj2.c<<endl;
    */

    D obj1;  // parmeterless ctor A,B, A,C, D
    cout<<"obj1="<<endl;
    obj1.Print();
    cout<<"size of obj1="<<sizeof(obj1)<<endl;  // 4+4=8 bytes
//    "NDiamindProblem::D::a" is ambiguousC/C++
//    cout<<"obj1.a in main="<<obj1.a<<endl;
    cout<<"obj1.B::a via class B in main="<<obj1.B::a<<endl;
    cout<<"obj1.C::a via class C in main="<<obj1.C::a<<endl;

    cout<<"obj1.b in main="<<obj1.b<<endl;
    cout<<"obj1.c in main="<<obj1.c<<endl;
    cout<<"obj1.d in main="<<obj1.d<<endl;


    D obj2(111,222,333,444);  // parmeterized ctor A, B, A, C, D
    cout<<"obj2="<<endl;
    obj2.Print();
    cout<<"size of obj2="<<sizeof(obj2)<<endl;  // 4+4=8 bytes
    cout<<"sizeof_var( obj2)="<<sizeof_var(obj2)<<endl;
//    "NDiamindProblem::D::a" is ambiguousC/C++
//    cout<<"obj2.a in main="<<obj2.a<<endl;
// sol no 1
    cout<<"obj2.B::a via class B in main="<<obj2.B::a<<endl;
    cout<<"obj2.C::a via class C in main="<<obj2.C::a<<endl;
    cout<<"obj2.b in main="<<obj2.b<<endl;
    cout<<"obj2.c in main="<<obj2.c<<endl;
    cout<<"obj2.d in main="<<obj2.d<<endl;
    
    return 0;
}


















