/*
1. swap by temp variable

temp=n1;
n1=n2;
n2=temp;

n1     n2     temp 
10      20     0      before swap
20      10    10     after swap


2. swap using addition and sub

n1= n1+n2;
n2= n1-n2;
n1= n1-n2;

n1          n2  
10          20          before swap
10+20=30    30-20=10
30-10=20
20          10           after swap


3. swap using multiply and divide

n1= n1*n2;
n2= n1/n2;
n1= n1/n2;

n1          n2  
10          20          before swap
10*20=200   200/20=10
200/10=20
20          10           after swap


4. swap using bit wise operator xor







*/
// 1. call by value for swap
#include<iostream>
using namespace std;
void swap(int n1, int n2)
{
    int temp;
    cout<<"before swap in swap n1="<<n1<<"\t &n1 = "<<&n1<<"\tn2="<<n2<<"\t &n2 = "<<&n2<<endl;
    temp=n1;
    n1=n2;
    n2=temp;
    cout<<"aftre swap in swap n1="<<n1<<"\t &n1 = "<<&n1<<"\tn2="<<n2<<"\t &n2 = "<<&n2<<endl;
    return;
}
int main(void)
{
    int no1, no2;
    cout<<"Enter No1=";
    cin>>no1;
    cout<<"Enter No2=";
    cin>>no2;

    cout<<"before swap in main no1="<<no1<<"\t &no1 = "<<&no1<<"\tno2="<<no2<<"\t &no2 = "<<&no2<<endl;
    swap(no1, no2); // call by value
    // no1 , no2 are actaul arguments
    cout<<"after swap in main no1="<<no1<<"\t &no1 = "<<&no1<<"\tno2="<<no2<<"\t &no2 = "<<&no2<<endl;
    
    return 0;
}

