/*
reference
diff between pointer and reference

4 ways of swap 

swap
    call by value
    call by address
    call by reference

dynamic memory alocation 
   malloc, calloc ,realloc  and free  (functions) (stdlib.h)
   new delete operators in cpp

diff between new and malloc
allocate memory for an array

*/