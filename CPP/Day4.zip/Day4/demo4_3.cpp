// memory allocation for single variable of char in cpp using new operator
#include<iostream>
using namespace std;
int main(void)
{
    char *ptr=NULL;
    //ptr= new float; //ptr= (float*)malloc(sizeof(float)*1);
    ptr= new char('A'); // /'A' value will be copy in address of ptr
    if( ptr== NULL)
    {
        printf("\n unable to allocate memory");
    }
    else
    {
        cout<<"*ptr="<<*ptr<<endl;
        cout<<"\n Enter *ptr=";
        cin>>*ptr;    //scanf("%c", ptr);
        cout<<"*ptr="<<*ptr<<endl;
       delete ptr;//free(ptr);
        ptr=NULL;
        cout<<"\n memory is freed"<<endl;;
    }

    return 0;
}
