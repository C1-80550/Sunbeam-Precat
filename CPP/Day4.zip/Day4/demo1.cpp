#include<iostream>
using namespace std;

int main(void)
{
    int a=10;
    int &r=a; // r is reference of a ( r is another name given to a)
  //int *const r=&a;

    cout<<"a=" <<a<<"\t &a="<<&a<<endl;  // a=10
    cout<<"r=" <<r<<"\t &r="<<&r<<endl;  // r=10

    a=100;
    cout<<"a=" <<a<<"\t &a="<<&a<<endl; // a=100
    cout<<"r=" <<r<<"\t &r="<<&r<<endl; // r=100

    r=1000;
    cout<<"a=" <<a<<"\t &a="<<&a<<endl; // a=1000
    cout<<"r=" <<r<<"\t &r="<<&r<<endl; // r=1000

    a++;
    cout<<"a=" <<a<<"\t &a="<<&a<<endl; // a=1001
    cout<<"r=" <<r<<"\t &r="<<&r<<endl; // r=1001

    r++;
    cout<<"a=" <<a<<"\t &a="<<&a<<endl; // a=1002
    cout<<"r=" <<r<<"\t &r="<<&r<<endl; // r=1002




    return 0;
}


