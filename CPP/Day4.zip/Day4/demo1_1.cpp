#include<iostream>
using namespace std;

int main(void)
{
    //int &r1=100; //error
    // we can create a reference to objects(variable)
    // we can not creare a reference to constants


    //int &r=NULL;  // error
   // we can not init reference to NULL (0)

    return 0;
}