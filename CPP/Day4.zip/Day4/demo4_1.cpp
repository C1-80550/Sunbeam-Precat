// memory allocation for single variable of int in cpp using new operator
#include<iostream>
using namespace std;
int main(void)
{
    int *ptr=NULL;
    //ptr= new int; //ptr= (int*)malloc(sizeof(int)*1);
    ptr= new int(125); // /125 value will be copy in address of ptr
    if( ptr== NULL)
    {
        printf("\n unable to allocate memory");
    }
    else
    {
        cout<<"*ptr="<<*ptr<<endl;
        cout<<"\n Enter *ptr=";
        cin>>*ptr;    //scanf("%d", ptr);
        cout<<"*ptr="<<*ptr<<endl;
        delete ptr;//free(ptr);
        ptr=NULL;
        cout<<"\n memory is freed"<<endl;;
    }

    return 0;
}
// g++ demo4_1.cpp ---> a.out
// valgrind ./a.out  ---> to check memory leakage

// valgrind is tool in linux / mac to check memeory leakage
// valgrind is not available on winodw os.
