// memeory allocation for single variable in c using  malloc fun
#include<stdio.h>
#include<stdlib.h>
int main(void)
{
    int *ptr=NULL;
    ptr= (int*)malloc(sizeof(int)*1);
    if( ptr== NULL)
    {
        printf("\n unable to allocate memory");
    }
    else
    {
        printf("\n Enter *ptr=");
        scanf("%d", ptr);
        printf("\n *ptr=%d", *ptr);
        free(ptr);
        ptr=NULL;
        printf("\n memory is freed");
    }

    return 0;
}
// g++ demo4_0.cpp ---> a.out
// valgrind ./a.out  ---> to check memory leakage

// valgrind is tool in linux / mac to check memeory leakage
// valgrind is not available on winodw os.
