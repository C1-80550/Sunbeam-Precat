// 2. call by address(pointers) for swap
#include<iostream>
using namespace std;
void swap(int *n1, int *n2)
{
    int temp;
    cout<<"before swap in swap *n1="<<*n1<<"\t n1 = "<<n1<<"\t *n2="<<*n2<<"\t n2 = "<<n2<<endl;
    
    temp=*n1;
    *n1=*n2;
    *n2=temp;

    cout<<"after swap in swap *n1="<<*n1<<"\t n1 = "<<n1<<"\t *n2="<<*n2<<"\t n2 = "<<n2<<endl;
    return;
}
int main(void)
{
    int no1, no2;
    cout<<"Enter No1=";
    cin>>no1;
    cout<<"Enter No2=";
    cin>>no2;

    cout<<"before swap in main no1="<<no1<<"\t &no1 = "<<&no1<<"\tno2="<<no2<<"\t &no2 = "<<&no2<<endl;
    swap(&no1, &no2); // call by address
    // no1 , no2 are actual arguments
    cout<<"after swap in main no1="<<no1<<"\t &no1 = "<<&no1<<"\tno2="<<no2<<"\t &no2 = "<<&no2<<endl;
    
    return 0;
}

