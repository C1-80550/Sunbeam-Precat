
#include<iostream>
#include<cstdlib>//#include<stdlib.h>
using namespace std;
namespace NComplex
{
    class Compelx
    {
        private:
           //variable/ data member /fields
            int real;
            int imag;
        public:
            // member function / methods

            // 1.1 input 
            //void accept_input(className * const this)
            //void accept_input(Complex * const this)
            void accept_input()
            {
                cout<<"Enter Real=";
                cin>>this->real;
                cout<<"Enter Imag=";
                cin>>this->imag;                
            }
            //1.2 output
            //void display_output(Complex * const this)
            void display_output()
            {
                cout<<"this->Real="<<this->real <<"\t &this->real = ["<< &this->real<<"]\n" ;
                cout<<"this->Imag="<<this->imag <<"\t &this->imag = ["<< &this->imag<<"]\n" ;
                
            }
            
            //2.0  parameterless ctor or no argument ctor
            //Compelx(Complex * const this)
          Compelx()
            {
                this->real=10;
                this->imag=20;
                cout<<"inside parameterless ctor of Complex class"<<endl;
            }
       
            //2.1  parameterzied ctor with 1 argument
            //Compelx(Complex * const this, int value)
            Compelx(int value)
            {
                this->real=value;
                this->imag=value;
                cout<<"inside parameterized ctor with 1 arg of Complex class"<<endl;
            }
            // 2.2  parameterzied ctor with 2 argument
            //Compelx(Complex * const this, int real, int imag )
            Compelx(int real , int imag)
            {
                this->real=real;
                this->imag=imag;
                cout<<"inside parameterized ctor with 2 arg of Complex class"<<endl;
            }

            // 3. dtor
            ~Compelx()
            {
                cout<<"====================="<<endl;
                this->display_output();
                cout<<"====================="<<endl;

                this->real=0;
                this->imag=0;
                cout<<"inside dtor of Complex class"<<endl;
            }
 

    };// end of class Complex

}// end of Namespace NComplex
using namespace NComplex;
int main()
{
    Compelx *ptr1= (Compelx*)malloc(sizeof(Compelx)*1);  // ctor not called
    cout<<"ptr1="<<endl;
    ptr1->display_output();
    free(ptr1);  // dtor not called


    Compelx *ptr2= new Compelx; // parameterless ctor called
    cout<<"ptr2="<<endl;
    ptr2->display_output();
    delete ptr2;  // dtor is called


    Compelx *ptr3= new Compelx(111); // parameterized  ctor with 1 arg called
    cout<<"ptr3="<<endl;
    ptr3->display_output();
    delete ptr3;  // dtor is called


    Compelx *ptr4= new Compelx(77,88); // parameterized  ctor with 2 arg called
    cout<<"ptr4="<<endl;
    ptr4->display_output();
    delete ptr4;  // dtor is called
    return 0;
}

/*
fuctionality of stack -- FILO / LIFO
ctor   dtor
c1     c4       
c2     c3
c3     c2
c4     c1
*/

