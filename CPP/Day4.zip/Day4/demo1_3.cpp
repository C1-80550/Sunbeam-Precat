#include<iostream>
using namespace std;

int main(void)
{
    const int a=10;
   const int &r=a; // r is reference of a ( r is another name given to a)
    //const int *const r=&a;
    
    cout<<"a=" <<a<<"\t &a="<<&a<<endl;  // a=10
    cout<<"r=" <<r<<"\t &r="<<&r<<endl;  // r=10

    //a=100; // not allowed as a in constant
    cout<<"a=" <<a<<"\t &a="<<&a<<endl;  // a=10
    cout<<"r=" <<r<<"\t &r="<<&r<<endl;  // r=10

    //r=1000; error as r is const
    cout<<"a=" <<a<<"\t &a="<<&a<<endl;  // a=10
    cout<<"r=" <<r<<"\t &r="<<&r<<endl;  // r=10


    return 0;
}