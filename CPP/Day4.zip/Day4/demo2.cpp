#include<iostream>
using namespace std;
class Demo
{
    private:
        int &ref1;
        float &ref2;
        char &ref3;

    public:
};
int main(void)
{
    cout<<"size of demo="<<sizeof(Demo)<<endl; //8*3 bytes
    return 0;
}