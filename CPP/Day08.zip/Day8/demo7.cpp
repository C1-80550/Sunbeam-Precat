// demo of template for class Array
// we can not wirte template in multiple (cant write decl and defination seprate )
#include<iostream>
using namespace std;

template <class Type>  // 1. add template before class anme
class Array
{
    private:
        int size;
        Type *arr;//int *arr;  // 2 change int type to Type
    public:
        Array(int size=5)
        {
            this->size=size;
            //3 change int type to Type
            this->arr= new Type[this->size]; 
            //this->arr= new int[this->size];
            int index;
            for(index=0; index<this->size; index++)
            {
                this->arr[index]=0;
            }
            cout<<"inside ctor of Array class"<<endl;
        }
        
        //className(const className& other)
        Array(const Array& other)
        {
         // &a2        // other is a reference of a1
            this->size= other.size; //step 1. copy size
            //this->arr=new int[this->size]; //step 2. allocate new memory
            this->arr=new Type[this->size]; 
            //step 3. copy data from a1 (other) to a2 (this)
            int index;
            for(index=0; index<this->size; index++)
            {
                this->arr[index]= other.arr[index];
            }
            cout<<"inside copy ctor of Array class (deep copy)"<<endl;
        }

        void accept_input()
        {
            int index;
            for(index=0; index<this->size; index++)
            {
                cout<<"this->["<<index<<"]=";
                cin>>this->arr[index];
            }
        }
        void dispaly_output()
        {
            int index;
            for(index=0; index<this->size; index++)
            {
                cout<<"this->["<<index<<"] \t"<< this->arr[index] <<"\t ["<<(void*)&this->arr[index]<<"]\n";
                
            }
        }
        
        ~Array()
        {
            if(this->arr!=NULL)
            {
                delete []this->arr;
                this->arr=NULL;
            }
            cout<<"inside dtor of Array class"<<endl;

        }

};// end of array class
int main(void)
{
    {
        Array<int> a1; // parameterized  with default arg size=5
        cout<<"enter elements of a1="<<endl;
        a1.accept_input();
        cout<<" elements of a1="<<endl;
        a1.dispaly_output();
    }
    {
        Array<float> a1; // parameterized  with default arg size=5
        cout<<"enter elements of a1="<<endl;
        a1.accept_input();
        cout<<" elements of a1="<<endl;
        a1.dispaly_output();
    }

    {
        Array<char> a1; // parameterized  with default arg size=5
        cout<<"enter elements of a1="<<endl;
        a1.accept_input();
        cout<<" elements of a1="<<endl;
        a1.dispaly_output();
    }


    return 0;
}