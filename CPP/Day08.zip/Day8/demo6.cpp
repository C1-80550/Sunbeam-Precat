// stl---- > std template lib
//template- for function
//           for class 
#include<iostream>
using namespace std;
// n1 is reference of no1
// n2 is reference of no2

// demo of template function
namespace NSwap
{
    template<class Type> 
    void swap(Type &n1, Type &n2)
    {
        Type temp;
        cout<<"before swap in swap n1="<<n1<<"\t &n1 = "<<(void*)&n1<<"\tn2="<<n2<<"\t &n2 = "<<(void*)&n2<<endl;
        temp=n1;
        n1=n2;
        n2=temp;
        cout<<"aftre swap in swap n1="<<n1<<"\t (void*)&n1 = "<<(void*)&n1<<"\tn2="<<n2<<"\t &n2 = "<<(void*)&n2<<endl;
        return;

    }
}

int main(void)
{
    cout<<"=====================int data type"<<endl;
    {
        int no1, no2;
        cout<<"Enter No1=";
        cin>>no1;
        cout<<"Enter No2=";
        cin>>no2;

        cout<<"before swap in main no1="<<no1<<"\t &no1 = "<<&no1<<"\tno2="<<no2<<"\t &no2 = "<<&no2<<endl;
        NSwap::swap(no1, no2); // call by reference
        // no1 , no2 are actual arguments
        cout<<"after swap in main no1="<<no1<<"\t &no1 = "<<&no1<<"\tno2="<<no2<<"\t &no2 = "<<&no2<<endl;
    }
    cout<<"=====================float data type"<<endl;
    
    {
        float no1, no2;
        cout<<"Enter No1=";
        cin>>no1;
        cout<<"Enter No2=";
        cin>>no2;

        cout<<"before swap in main no1="<<no1<<"\t &no1 = "<<&no1<<"\tno2="<<no2<<"\t &no2 = "<<&no2<<endl;
        NSwap::swap(no1, no2); // call by reference
        // no1 , no2 are actual arguments
        cout<<"after swap in main no1="<<no1<<"\t &no1 = "<<&no1<<"\tno2="<<no2<<"\t &no2 = "<<&no2<<endl;
    }

    cout<<"=====================char data type"<<endl;
    
    {
        char no1, no2;
        cout<<"Enter No1=";
        cin>>no1;
        cout<<"Enter No2=";
        cin>>no2;

        cout<<"before swap in main no1="<<no1<<"\t &no1 = "<<(void*)&no1<<"\tno2="<<no2<<"\t &no2 = "<<(void*)&no2<<endl;
        NSwap::swap(no1, no2); // call by reference
        // no1 , no2 are actual arguments
        cout<<"after swap in main no1="<<no1<<"\t &no1 = "<<(void*)&no1<<"\tno2="<<no2<<"\t &no2 = "<<(void*)&no2<<endl;
    }
    return 0;
}