/*
	deep copy
		
	// inheritance
	//       types of inherittnace
	//       modes of inherittnace

 template for function 
 	      for class
	
  multiple file demo
/*



