// demo for deep copy to slove issue of shallow copy
#include<iostream>
using namespace std;

class Array
{
    private:
        int size;
        int *arr;
    public:
        Array(int size=5)
        {
            this->size=size;
            this->arr= new int[this->size];
            int index;
            for(index=0; index<this->size; index++)
            {
                this->arr[index]=0;
            }
            cout<<"inside ctor of Array class"<<endl;
        }
        
        //className(const className& other)
        Array(const Array& other)
        {
         // &a2        // other is a reference of a1
            this->size= other.size; //step 1. copy size
            this->arr=new int[this->size]; //step 2. allocate new memory
            //step 3. copy data from a1 (other) to a2 (this)
            int index;
            for(index=0; index<this->size; index++)
            {
                this->arr[index]= other.arr[index];
            }
            cout<<"inside copy ctor of Array class (deep copy)"<<endl;
        }

        void accept_input()
        {
            int index;
            for(index=0; index<this->size; index++)
            {
                cout<<"this->["<<index<<"]=";
                cin>>this->arr[index];
            }
        }
        void dispaly_output()
        {
            int index;
            for(index=0; index<this->size; index++)
            {
                cout<<"this->["<<index<<"] \t"<< this->arr[index] <<"\t ["<<&this->arr[index]<<"]\n";
                
            }
        }
        
        ~Array()
        {
            if(this->arr!=NULL)
            {
                delete []this->arr;
                this->arr=NULL;
            }
            cout<<"inside dtor of Array class"<<endl;

        }

};// end of array class
int main(void)
{
    Array a1; // parameterized  with default arg size=5
    cout<<"enter elements of a1="<<endl;
    a1.accept_input();
    cout<<" elements of a1="<<endl;
    a1.dispaly_output();
    
   
//    if  we assign all readty created object(a1) to newly created object (a2)
//     internally copy ctor gets called



    Array a2=a1;  // copy ctor  deep copy
    // or
    // Array a2(a1);

    cout<<" elements of a2="<<endl;
    a2.dispaly_output();


    return 0;
}