// demo of operator overloading  using member function cpp
#include<iostream>
using namespace std;
    class Compelx
    {
        private:
           //variable/ data member /fields
            int real;
            int imag;
        public:
            // member function / methods

            // 1.1 input 
            //void accept_input(className * const this)
            //void accept_input(Complex * const this)
            void accept_input()
            {
                cout<<"Enter Real=";
                cin>>this->real;
                cout<<"Enter Imag=";
                cin>>this->imag;                
            }
            //1.2 output
            //void display_output(Complex * const this)
            void display_output()
            {
                cout<<"this->Real="<<this->real <<"\t &this->real = ["<< &this->real<<"]\n" ;
                cout<<"this->Imag="<<this->imag <<"\t &this->imag = ["<< &this->imag<<"]\n" ;
                
            }
            
            //2.0  parameterless ctor or no argument ctor
            //Compelx(Complex * const this)
          Compelx()
            {
                this->real=10;
                this->imag=20;

            }
       
            //2.1  parameterzied ctor with 1 argument
            //Compelx(Complex * const this, int value)
            Compelx(int value)
            {
                this->real=value;
                this->imag=value;

            }
            // 2.2  parameterzied ctor with 2 argument
            //Compelx(Complex * const this, int real, int imag )
            Compelx(int real , int imag)
            {
                this->real=real;
                this->imag=imag;

            }

            // 3. dtor
            ~Compelx()
            {
                this->real=0;
                this->imag=0;

            }
                // Compelx c3=c1.Minus(c2); this=&c1;
            //Compelx Minus(Complex * const this,Compelx other1)
        
             Compelx Minus(Compelx other1)
             {
                Compelx temp;
                      //    &c1  pointer c2 object
                temp.real= this->real - other1.real;
                temp.imag= this->imag - other1.imag;
                return temp;
             }
//             Compelx operator-(Complex * const this,Compelx other1)
             Compelx operator-(Compelx other1)
             {
                Compelx temp;
                      //    &c1  pointer c2 object
                temp.real= this->real - other1.real;
                temp.imag= this->imag - other1.imag;
                return temp;
             }

    };// end of class Complex

    
int main()
{
    Compelx c1(30, 40), c2(10, 20);
    cout<<"c1="<<endl;
    c1.display_output(); // real=30 imag=40

    cout<<"c2="<<endl;
    c2.display_output(); //real=10, imag=20

    Compelx c3=c1.Minus(c2);
    cout<<"c3= sum of 2 complex using friend fun ="<<endl;

    c3.display_output(); //real=20, imag=20

    Compelx c4=c1-c2;// Compelx c4=c1.oeprator-(c2);
    cout<<"c4= sub of 2 complex by operator overloading using member fun ="<<endl;

    c4.display_output(); //real=20, imag=20
       return 0;
}




