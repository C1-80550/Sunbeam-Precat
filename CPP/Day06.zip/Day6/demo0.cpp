/*


static data member

friend function

   operator overloading as friend function
   operator overloading as member function 




  */

