#include<stdio.h>
// decl of global variable

extern int no; //undefined reference to `no'
int main(void)
{
    printf("\n no=%d ", no);
    return 0;
}