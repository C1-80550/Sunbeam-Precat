// static data member -- share data between all objects of class
//size of object is size of all non static data members of class
// size of static data member is not consider in size of object
#include<iostream>
using namespace std;
class StaticDemo
{
    private:
    // non static data member
        int id;
        int a;
        int b;
    // static data member
        static int counter;
    public:
        StaticDemo()
        {
            StaticDemo::counter++; 
            this->id=StaticDemo::counter; 
            this->a=10;
            this->b=20;
            cout<<"inside  parameterless  ctor of StaticDemo"<<endl;
        }
        StaticDemo(int a, int b)
        {
            StaticDemo::counter++;//1001
            this->id=StaticDemo::counter;//id ==1001
            this->a=a; //11
            this->b=b;  //22
            cout<<"inside  parameterized  ctor of StaticDemo"<<endl;
        }
        // non static member function can acess non static data member
        // non static member function can acess static data member
   //   void print(StaticDemo * const this)
        void print()
        {
            // non static data members id,a,b
            cout<<"this->id="<<this->id<<" \t ["<<&this->id<<"]"<<endl;
            cout<<"this->a="<<this->a<<" \t ["<<&this->a<<"]"<<endl;
            cout<<"this->b="<<this->b<<" \t ["<<&this->b<<"]"<<endl;
            //static data member
            cout<<"StaticDemo::counter="<<StaticDemo::counter<<" \t ["<<&StaticDemo::counter<<"]"<<endl;
        }
         //  static member function can acess only static data member
        //  static member function can not  acess non static data member
         // static void set_counter(int counter)
        static void set_counter(int counter)
        {
              StaticDemo::counter=counter; //allowed
              //this->a=100; error
             // b=200;   //error
        }
        ~StaticDemo()
        {
            this->id=0;
            this->a=0;
            this->b=0;
            cout<<"inside dtor of StaticDemo"<<endl;
        }
    
};
//int StaticDemo::counter; // default value of static = 0
int StaticDemo::counter=1000; 
// global defination for static data  member
int main(void)
{
    StaticDemo s1(11,22);// parameterzied

    cout<<"s1="<<endl;
    s1.print();  // counter=1001 id=1001 a=11 b=22
    cout<<"sizeof s1="<<sizeof(s1)<<endl;

    StaticDemo s2(33,44);
    cout<<"s2="<<endl;
    s2.print();  // counter=1002 id=1002 a=33 b=44

    cout<<"s1="<<endl;
    s1.print();  // counter=1002 id=1001 a=11 b=22

    StaticDemo s3(55,66), s4(77,88);
    cout<<"s3="<<endl;
    s3.print();  // counter=1004 id=1003 a=55 b=66

    cout<<"s4="<<endl;
    s4.print();  // counter=1004 id=1004 a=77 b=88

    return 0;
}