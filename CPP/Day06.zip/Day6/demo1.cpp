// constant data member
// constant member function
// constant object

#include<iostream>
using namespace std;
class ConstDemo
{
    private:
    // non constant data members
        mutable int a;
        int b;
    // constant data members
        const int c;
        int const d;
    public:
       // ctor init list
        //ConstDemo(ConstDemo * const this):a(10), b(20),c(30), d(40)

        ConstDemo():a(10), b(20),c(30), d(40)
        {
          //   this->a=100;
          //  this->b=200;  // allowed as a and b are non const data members
          //  this->c=30;
          //  this->d=40;  // not allowed as c and d are  const data members
            cout<<"inside paramterless ctor"<<endl;
        }
        //ConstDemo(int n1, int n2, int n3, int n4):a(n1), b(n2),c(n3), d(n4)
        //ConstDemo(ConstDemo * const this, int a, int b, int c, int d):a(a), b(b),c(c), d(d)
        ConstDemo(int a, int b, int c, int d):a(a), b(b),c(c), d(d)
        {
          //  this->a=a;
           // this->b=b;  // allowed as a and b are non const data members
          //  this->c=c;
          //  this->d=d;  // not allowed as c and d are  const data members
            cout<<"inside paramterized ctor"<<endl;
        }

// we can modify the state of the object in non constant member function of class
        //void print(ConstDemo * const this)
        void print()  // non constant member
        {
            this->a=100;
            this->b=200;  // allowed as a and b are non const data members
           // this->c=300;
           // this->d=400;  // not allowed as c and d are  const data members
          
            cout<<"this->a="<<this->a<<endl;
            cout<<"this->b="<<this->b<<endl;
            cout<<"this->c="<<this->c<<endl;
            cout<<"this->d="<<this->d<<endl;
        }
        //return_type member_function_name() const
        // we cannot modify state of the object in constant member function of class
         //void display(const ConstDemo * const this) const
        void display()const  // constant member function
        {
            
            // this->a=999;  // this is allowed as  a is mutable
             // error as display is constant member function
            //this->b=200;  // not allowed as member function constant
           // this->c=300;
           // this->d=400;  // not allowed as c and d are  const data members
            cout<<"this->a="<<this->a<<endl;
            cout<<"this->b="<<this->b<<endl;
            cout<<"this->c="<<this->c<<endl;
            cout<<"this->d="<<this->d<<endl;
        }

        //~ConstDemo(ConstDemo * const this)
        ~ConstDemo()
        {
            this->print();
            this->a=0;
            this->b=0;  // allowed as a and b are non const data members
            //this->c=0;
            //this->d=0;// not allowed as c and d are  const data members
            cout<<"inside ctor"<<endl;
        }

};
int main(void)
{
// non constant object can call constant member function 
// non constant object can call non constant member function 

    // c1 and c2 are non constant object
    ConstDemo c1; //  parameterless ctor
    cout<<"c1= display()"<<endl;
    c1.display();  // a=10 b=20  c=30  d=40
    
    cout<<"c1= print()"<<endl;
    c1.print();  // a=100 b=200  c=30  d=40
    cout<<"size of c1="<<sizeof(c1)<<endl;

   

    ConstDemo c2(111,222,333,444); //  parameterized ctor
    cout<<"c2= display()"<<endl;
    c2.display();  // a=111 b=222  c=333  d=444
    
    cout<<"c2= print()"<<endl;
    c2.print(); //  a=100 b=200  c=333  d=444
    cout<<"size of c2="<<sizeof(c2)<<endl;
    {
       //  constant object can call constant member function 
        // constant object can not  call non constant member function 

        const ConstDemo c3; // constnat object

        cout<<"c3= display()"<<endl;
        c3.display();  // a=10 b=20  c=30  d=40
    
        //cout<<"c3= print()"<<endl;
       // c3.print();  // a=10 b=20  c=30  d=40
        cout<<"size of c1="<<sizeof(c1)<<endl;
}
    return 0;
}
/*a type qualifier is not allowed on a nonmember functionC/C++(1670)
void display()const
{

}
*/
// we can make member function constant in cpp
// we can not make global function constant in c and cpp