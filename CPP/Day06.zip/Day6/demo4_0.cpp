/*
in  c prog

struct emp e1 , e2;
in c we can not compare two structure variables of same data type
if( e1==e2 ) not allowed
if( e1>e2 ) not allowed
if( e1<e2 ) not allowed
if( e1!=e2 ) not allowed


in c we can compare members two structure variables of same data type
if( e1.sal==e2.sal )  allowed
if( e1.empno>e2.empno )  allowed
if( strcmp(e1.name ,e2.name)>0 )  allowed
if( e1.sal !=e2.sal ) allowed

*/
/* 
in cpp we can overload operator by 2 ways
  1. using friend function (global frined) c prog

  2. using member function ( cpp)



*/
// demo of operator overloading  using friend function (global frined) c prog
#include<iostream>
using namespace std;
    class Compelx
    {
        private:
           //variable/ data member /fields
            int real;
            int imag;
        public:
            // member function / methods

            // 1.1 input 
            //void accept_input(className * const this)
            //void accept_input(Complex * const this)
            void accept_input()
            {
                cout<<"Enter Real=";
                cin>>this->real;
                cout<<"Enter Imag=";
                cin>>this->imag;                
            }
            //1.2 output
            //void display_output(Complex * const this)
            void display_output()
            {
                cout<<"this->Real="<<this->real <<"\t &this->real = ["<< &this->real<<"]\n" ;
                cout<<"this->Imag="<<this->imag <<"\t &this->imag = ["<< &this->imag<<"]\n" ;
                
            }
            
            //2.0  parameterless ctor or no argument ctor
            //Compelx(Complex * const this)
          Compelx()
            {
                this->real=10;
                this->imag=20;

            }
       
            //2.1  parameterzied ctor with 1 argument
            //Compelx(Complex * const this, int value)
            Compelx(int value)
            {
                this->real=value;
                this->imag=value;

            }
            // 2.2  parameterzied ctor with 2 argument
            //Compelx(Complex * const this, int real, int imag )
            Compelx(int real , int imag)
            {
                this->real=real;
                this->imag=imag;

            }

            // 3. dtor
            ~Compelx()
            {
                this->real=0;
                this->imag=0;

            }
     friend Compelx sum(Compelx other1, Compelx other2);

   friend  Compelx operator+(Compelx other1, Compelx other2);

    };// end of class Complex

    Compelx sum(Compelx other1, Compelx other2)
    {
        Compelx temp;
        temp.real=other1.real+other2.real;
        temp.imag=other1.imag+other2.imag;
        return temp;
    }

    Compelx operator+(Compelx other1, Compelx other2)
    {
        Compelx temp;
        temp.real=other1.real+other2.real;
        temp.imag=other1.imag+other2.imag;
        return temp;
    }

int main()
{
    Compelx c1(10, 20), c2(30, 40);
    cout<<"c1="<<endl;
    c1.display_output(); // real=10 imag=20

    cout<<"c2="<<endl;
    c2.display_output(); //real=30, imag=40

    Compelx c3=sum(c1,c2);
    cout<<"c3= sum of 2 complex using friend fun ="<<endl;

    c3.display_output(); //real=40, imag=60

    Compelx c4=c1+c2;// Compelx c4=operator+(c1,c2);
    cout<<"c4= sum of 2 complex by operator overloading using friend fun ="<<endl;

    c4.display_output(); //real=40, imag=60
    
    return 0;
}




