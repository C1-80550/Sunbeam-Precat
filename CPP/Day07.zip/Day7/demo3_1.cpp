// demo for shallow copy
#include<iostream>
using namespace std;

class Array
{
    private:
        int size;
        int *arr;
    public:
        Array(int size=5)
        {
            this->size=size;
            this->arr= new int[this->size];
            int index;
            for(index=0; index<this->size; index++)
            {
                this->arr[index]=0;
            }
            cout<<"inside ctor of Array class"<<endl;
        }
        void accept_input()
        {
            int index;
            for(index=0; index<this->size; index++)
            {
                cout<<"this->["<<index<<"]=";
                cin>>this->arr[index];
            }
        }
        void dispaly_output()
        {
            int index;
            for(index=0; index<this->size; index++)
            {
                cout<<"this->["<<index<<"] \t"<< this->arr[index] <<"\t ["<<&this->arr[index]<<"]\n";
                
            }
        }
        
        ~Array()
        {
            if(this->arr!=NULL)
            {
                delete []this->arr;
                this->arr=NULL;
            }
        }

};// end of array class
int main(void)
{
    Array a1; // parameterized  with default arg size=5
    cout<<"enter elements of a1="<<endl;
    a1.accept_input();
    cout<<" elements of a1="<<endl;
    a1.dispaly_output();
    
   
//    if  we assign all readty created object(a1) to newly created object (a2)
//     internally copy ctor gets called
//   if we dont write copy ctor in class we will get default copy ctor
//   default copy ctor creates shallow copy


    Array a2=a1;  
    // or
    // Array a2(a1);

    cout<<" elements of a2="<<endl;
    a2.dispaly_output();


    return 0;
}