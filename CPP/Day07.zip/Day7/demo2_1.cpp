#pragma pack(1)
#include<iostream>

#include<cstring> // #include<string.h> 
using namespace std;
namespace NComposition
{
    class Address
    {
        private:
            char address_info[30];
            char city[20];
            int pincode;
        public:
            Address()
            {
                strcpy(this->address_info,"Sunbeam Market yard");
                strcpy(this->city,"pune");
                this->pincode=411037;
                cout<<"inside parameterless ctor of Address class"<<endl;
            }

            Address(char*address_info, char*city, int pincode)
            {
                strcpy(this->address_info,address_info);
                strcpy(this->city,city);
                this->pincode=pincode;
                cout<<"inside parameterzied ctor of Address class"<<endl;
            }
            void print()
            {
                cout<<"address info ="<<endl;
                cout<<"address_info="<<this->address_info<<endl;
                cout<<"city="<<this->city<<endl;
                cout<<"pincode="<<this->pincode<<endl;
            }

            ~Address()
            {
                strcpy(this->address_info,"");
                strcpy(this->city,"");
                this->pincode=0;
                cout<<"inside dtor of Address class"<<endl;
            }
    }; // end of address class
}
using namespace NComposition;
int main(void)
{
    Address a1;//  NComposition:: Address d1;  parameterless
    cout<<"a1=";
    a1.print();
    cout<<"size of a1="<<sizeof(a1)<<endl; // 30+20+4 ==54

    Address a2("RG IT Park Hijewadi","Mulshi", 411001);//  NComposition:: Address a2;  parameterized
    cout<<"a2=";
    a2.print();
    cout<<"size of a2="<<sizeof(a2)<<endl;
    
    return 0;
}

