
// demo of composition ---> person has birthdate , person has address
#include<iostream>
#pragma pack(1)

#include<cstring>
using namespace std;
namespace NComposition
{
    class Date
    {
        private:
            int dd;
            int mm;
            int yy;
        public:
            Date()
            {
                this->dd=10;
                this->mm=1;
                this->yy=2000;
                cout<<"inside parameterless ctor of Date class"<<endl;
            }

            Date(int dd, int mm, int yy)
            {
                this->dd=dd;
                this->mm=mm;
                this->yy=yy;
                cout<<"inside parameterized ctor of Date class"<<endl;
            }
            void print()
            {
                cout<<"date="<<endl;
                /*cout<<"this->dd="<<this->dd<<endl;
                cout<<"this->mm="<<this->mm<<endl;
                cout<<"this->yy="<<this->yy<<endl;
                */
               cout<<this->dd<<"/"<<this->mm<<"/"<<this->yy<<endl;
            }
            ~Date()
            {
                this->dd=0;
                this->mm=0;
                this->yy=0;
                cout<<"inside dtor of Date class"<<endl;
            }

    };// end of date class


    class Address
    {
        private:
            char address_info[30];
            char city[20];
            int pincode;
        public:
            Address()
            {
                strcpy(this->address_info,"Sunbeam Market yard");
                strcpy(this->city,"pune");
                this->pincode=411037;
                cout<<"inside parameterless ctor of Address class"<<endl;
            }

            Address(char*address_info, char*city, int pincode)
            {
                strcpy(this->address_info,address_info);
                strcpy(this->city,city);
                this->pincode=pincode;
                cout<<"inside parameterzied ctor of Address class"<<endl;
            }
            void print()
            {
                cout<<"address info ="<<endl;
                cout<<"address_info="<<this->address_info<<endl;
                cout<<"city="<<this->city<<endl;
                cout<<"pincode="<<this->pincode<<endl;
            }

            ~Address()
            {
                strcpy(this->address_info,"");
                strcpy(this->city,"");
                this->pincode=0;
                cout<<"inside dtor of Address class"<<endl;
            }
    }; // end of address class

   // ctor date--> Address--> person
   // dtor person---> Address ->Date
    class Person
    {
        private:
            char name[20];
            Date birth_date;  // person has birth_date
            Address per_address;// person has Address

        public:

            Person()
            {
                strcpy(this->name,"abcd");
                cout<<"isnide parameterless ctor of Person class"<<endl;
            }

            //     Person  (1)      Address (3)                                    Date(3)
            //    ===========   ======================================    ====================
            Person(char *name,char*address_info, char*city, int pincode,int dd, int mm, int yy)
            {
                strcpy(this->name,name);
                cout<<"isnide parameterized ctor of Person class"<<endl;
            }
            void print_person_info()
            {
                cout<<"person info="<<endl;
                cout<<" this->name="<<this->name<<endl;
                // objectname.methodname();
                this->per_address.print();
                this->birth_date.print();


            }
            ~Person()
            {
                strcpy(this->name,"");
                cout<<"isnide dtor of Person class"<<endl;
            }

    };// end of person class

}// end of Namespace
using namespace NComposition;
int main(void)
{
    Person p1;//  NComposition:: Person d1;  parameterless
    cout<<"p1=";
    p1.print_person_info();     //        person address date
    cout<<"size of p1="<<sizeof(p1)<<endl; // 20 + 54 +12 =86

    Person p2("xyz","RG IT Park Hijewadi","Mulshi", 411001, 11,2,2011);//  NComposition:: Person a2;  parameterized
    cout<<"p2=";
    p2.print_person_info();
    cout<<"size of p2="<<sizeof(p2)<<endl; // 20 + 54 +12 =86
    
    return 0;
}