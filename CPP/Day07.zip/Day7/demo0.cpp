/*
OPPS concepts
	// composition 
		// demo of person
        	// date class
            	// address class
            	//person class	
 
Copy ctor
	array class
	shallow copy deep copy 
   differeence between =operator and copy ctor


    
   


   
  
	
*/

