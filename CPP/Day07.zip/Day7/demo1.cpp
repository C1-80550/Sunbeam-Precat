#include<iostream>
using namespace std;
class FriendDemo
{
    private:
        int a;
        int b;
    public:
    // member function decl
        FriendDemo();
        FriendDemo(int a, int b);
        void print();
        ~FriendDemo();        
        friend void sum();        
}; //end of class

// syntax of writing menber function defination out of class
//return_type classname::Member_Function(datatype parameters)

        FriendDemo::FriendDemo()
        {
            this->a=10;
            this->b=20;
        }
        FriendDemo::FriendDemo(int a, int b)
        {
            this->a=a;
            this->b=b;
        }
        void FriendDemo::print()
        {
            cout<<"this->a="<<this->a<<endl;
            cout<<"this->b="<<this->b<<endl;
        }
        FriendDemo::~FriendDemo()
        {
            this->a=0;
            this->b=0;
        }
        void sum()
        {
            FriendDemo obj1(111,222);
            //member "FriendDemo::a, b" is inaccessible if sum is not friend of class
            int res=obj1.a+ obj1.b;
            cout<<"res="<<res<<endl;
            return;
        }
int main(void)
{
    cout<<"//return_type classname::Member_Function(datatype parameters)"<<endl;
    sum();
    return 0;
}