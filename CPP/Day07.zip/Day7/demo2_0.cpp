#include<iostream>
using namespace std;
namespace NComposition
{
    class Date
    {
        private:
            int dd;
            int mm;
            int yy;
        public:
            Date()
            {
                this->dd=10;
                this->mm=1;
                this->yy=2000;
                cout<<"inside parameterless ctor of Date class"<<endl;
            }

            Date(int dd, int mm, int yy)
            {
                this->dd=dd;
                this->mm=mm;
                this->yy=yy;
                cout<<"inside parameterized ctor of Date class"<<endl;
            }
            void print()
            {
                cout<<"date="<<endl;
                /*cout<<"this->dd="<<this->dd<<endl;
                cout<<"this->mm="<<this->mm<<endl;
                cout<<"this->yy="<<this->yy<<endl;
                */
               cout<<this->dd<<"/"<<this->mm<<"/"<<this->yy<<endl;
            }
            ~Date()
            {
                this->dd=0;
                this->mm=0;
                this->yy=0;
                cout<<"inside dtor of Date class"<<endl;
            }

    };// end of date class
}// end of Namespace
using namespace NComposition;
int main(void)
{
    Date d1;//  NComposition:: Date d1;  parameterless
    cout<<"d1=";
    d1.print();
    cout<<"size of d1="<<sizeof(d1)<<endl;

    Date d2(11,2,2010);//  NComposition:: Date d2;  parameterized
    cout<<"d2=";
    d2.print();
    cout<<"size of d2="<<sizeof(d2)<<endl;
    
    return 0;
}
