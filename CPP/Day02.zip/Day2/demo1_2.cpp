//nested namespace
#include<stdio.h>
int no1=100;  // global  variable
namespace N1  // outer_namespace
{
    int no1=500;
    int no2=600;
    namespace N2  // inner_namespace
    {
        int no1=1000;
        int no3=1100;
    }
}
int main(void)
{
    int no1=10; // local variable
    printf("\n local variables no1=%d [%u]", no1, &no1); // no1=10
    printf("\n global variables ::no=%d [%u]", ::no1, &::no1); // no1=100

    // we can use :: scope resolution operator to print global variable

    // print variable from namespace
    // namespacename::variablename   N1::no1  , N2::no2
    printf("\n variable from N1 N1::no1=%d %u", N1::no1, &N1::no1); // N1::no1=500
    printf("\n variable from N1 N1::no2=%d %u", N1::no2, &N1::no2); // N1::no2=600

    using namespace N1;
    printf("\n variable from N1 no2=%d %u", no2, &no2); // no2=600
    printf("\n local variable no1=%d %u", no1, &no1); // no1=10
    printf("\n variable from N1 N1::no1=%d %u", N1::no1, &N1::no1); // N1::no1=500


    // to access variable from nested namespace
    // outernamespacename::innernamespacename::variable_name   N1::N2::no1, N1::N2::no3
    printf("\n variable from N1::N2 N1::N2::no1=%d %u", N1::N2::no1, &N1::N2::no1); // N1::N2::no1=1000
    printf("\n variable from N1::N2 N1::N2::no3=%d %u", N1::N2::no3, &N1::N2::no3); // N1::N2::no3=1100

    //using namespace N1;
    //using namespace N2; 
    // or
    //using namespace N1::N2;
    using namespace N2;

    printf("\n variable from N1::N2 N1::N2::no1=%d %u", N1::N2::no1, &N1::N2::no1); // N1::N2::no1=1000
    printf("\n variable from N1::N2 no3=%d %u", no3, &no3); // no3=1100
    printf("\n local variable  no1=%d %u", no1, &no1); // no1=10
    return 0;

}