#include<stdio.h>
int main(void)
{
    //const float pi=3.142;
    //or
    float const pi=3.142;  // warning: initialization discards ‘const’ qualifier from pointer target type [-Wdiscarded-qualifiers]
    //float *ptr=&pi;
//: error: invalid conversion from ‘const float*’ to ‘float*’ [-fpermissive]
    
    const float *ptr=&pi; // allowed
    //or
    // float const *ptr=&pi; // allowed

    // in cpp if we want to store address of constant variable then value of pointer
    // must constant

    printf("\n pi=%.3f *ptr=%.3f ptr=%u", pi, *ptr, ptr);
    //                                 3.142  3.142  980

    /* pi=4.4f;  // we can not use = , ++ , -- amd short hand operator with constants
    pi++;
    ++pi;
    --pi;
    pi--;
    pi+=10;
    pi-=10;
    pi*=10;
    pi/=10;
  */

    //*ptr= 4.4f; // not allowed we can not modify value of constant using pointer
    // because value of pointer is  constant

      printf("\n pi=%.3f *ptr=%.3f ptr=%u", pi, *ptr,  ptr);
    //                                    3.142  3.142  980

    return 0;
}