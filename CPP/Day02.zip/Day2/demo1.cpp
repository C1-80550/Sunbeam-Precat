/*
all the data type of c are presnt in cpp

2 data types are added by cpp
1. bool ->     store true and false  1 byte defualt value
2. wchar_t ->  16 bit char (2 bytes). used unicode (all lang of world hindi , marathi ,french , jap, german)
               char 8 bits ( 1 byte)  0 to 255  used ASCII (all english char)
            
*/
#include<stdio.h>
int no=100;  // global  variable

int main(void)
{
    int no=10; // local variable
    printf("\n local variables no=%d [%u]", no, &no); // no=10
    printf("\n global variables ::no=%d [%u]", ::no, &::no); // no=100
// we can use :: scope resolution operator to print global variable

    return 0;

}