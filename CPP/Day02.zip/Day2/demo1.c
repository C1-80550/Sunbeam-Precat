#include<stdio.h>
int no=100;  // global  variable
int main(void)
{
    int no=10; // local variable
    printf("\n local variables no=%d [%u]", no, &no); // no=10
    return 0;
}