// default arguments are given from right to left in sequence
#include<stdio.h>
int sum(int a=0, int b=0, int c=0, int d=0)
{
    printf("\n\t a=%d b=%d c=%d  d=%d",a,b,c,d);
    return a+b+c+d;
}
int main(void)
{
    int ans=0;
    ans= sum(10,20,30,40); // a=10 b=20 c=30 d=40  ans=100
    printf("\n ans=%d", ans);
 
    ans= sum(10,20,30); // a=10 b=20 c=30 d=0  ans=60
    printf("\n ans=%d", ans);

    ans= sum(10,20); // a=10 b=20 c=0 d=0  ans=30
    printf("\n ans=%d", ans);

    ans= sum(10); // a=10 b=0 c=0 d=0  ans=10
    printf("\n ans=%d", ans);

    ans= sum(); // a=0 b=0 c=0 d=0  ans=0
    printf("\n ans=%d", ans);

    //ans= sum(,10,20,30); // a=? b=10 c=20 d=30  ans=60
    //printf("\n ans=%d", ans);

    return 0;
}