// this pointer in cpp 
#include<stdio.h>
#pragma pack(1) 
struct emp
{
    private:
    //variable(c) / data member(cpp) / field(java)
        int empno;
        char name[10];
        float sal;

    public:
    // member function or methods
        //e2.accept_emp_info();  // this=&e2;
        //e1.accept_emp_info();  // this=&e1;
        //void accept_emp_info(emp * const this)
        void accept_emp_info()
        {
            printf("\n Enter Emp No = ");
            scanf("%d", &this->empno);
            printf("\n Enter Emp Name = ");
            scanf("%s", this->name);
            printf("\n Enter Emp sal = ");
            scanf("%f", &this->sal);
            return; 
        }
        //e1.display_emp_info(); // this=&e1;
        //e2.display_emp_info(); // this=&e2;
        //void display_emp_info(emp * const this)
        void display_emp_info()
        {
            printf("\n Empno  Name  Sal \n");
            printf("%-6d%-10s%-6.2f\n",this->empno, this->name, this->sal);
            return;
        }
    //  void set_salary(emp * const this,float sal)
        void set_salary(float sal)
        {
           this->sal= sal;
           return;
        }

}; 
int main(void)
{
    // struct emp is user defined data type 
    // e1 is (variable c) /(object cpp) of user defined data type struct emp
    emp e1; //struct emp e1;
    printf("\n Enter Emp info :: ");
    //cpp                       c
    e1.accept_emp_info();  //accept_emp_info(&e1);

    printf("\n Emp info :: \n");
    e1.display_emp_info(); // display_emp_info(&e1);

    //e1.sal=-10000;  //error: ‘float emp::sal’ is private within this context

    e1.set_salary(12000);  // update sal

    printf("\n Emp info with new sal :: \n");
    e1.display_emp_info() ;//display_emp_info(&e1);





    return 0;   
}
/*
struct in c prog
struct emp e1, e2;

// to accept data for e1 (input)
accept_emp_info(&e1);
// to print data of e1 (output)
display_emp_info(&e1);

// to accept data for e2 (input)
accept_emp_info(&e2);
// to print data of e2 (output)
display_emp_info(&e2);

struct in cpp
emp e1, e2;
// to accept data for e1 (input)
e1.accept_emp_info(); // e1.accept_emp_info(&e1);
// to print data of e1 (output)
e1.display_emp_info();

/ to accept data for e2 (input)
e2.accept_emp_info();
// to print data of e2 (output)
e2.display_emp_info();



*/