#include<iostream>
using namespace std;
int main(void)
{
    int no1, no2, ans;

    try
    {
        cout<<"Enter No1=";
        cin>>no1;
        cout<<"Enter No2=";
        cin>>no2;
        if(no2==0)
        {
             //throw 1.0F;  // throw float;
            //throw 1.0f;  // throw float;
            //throw 1.0;  // throw double;
            //throw 0;  // throw int;
             throw __LINE__+2;  // throw int; 19
        }
        ans= no1/no2;
        cout<<"ans="<<ans<<endl;
    }   
    
    catch(int no)
    {
        cout<<" inside int1 catch error at = "<<no<< " line " <<endl;  // no=0
        cout<<" can not divide by zero"<<endl;
        cout<<" file name="<<__FILE__<<endl;
        cout<<" date="<<__DATE__<<endl;
        cout<<" time="<<__TIME__<<endl;

    }
    catch(int no)
    {
        cout<<" inside int2 catch no="<<no<<endl;  // no=0
        cout<<" can not divide by zero"<<endl;
    }
    catch(float no)
    {
        cout<<" inside float catch no="<<no<<endl;  // no=0
        cout<<" can not divide by zero"<<endl;
    }
    catch(double no)
    {
        cout<<" inside double catch no="<<no<<endl;  // no=0
        cout<<" can not divide by zero"<<endl;
    }
    catch(...) // ellispe generic catch
    {
        cout<<" inside generic catch "<<endl;  
        cout<<" can not divide by zero"<<endl;
    }  
    
    return 0;    
}