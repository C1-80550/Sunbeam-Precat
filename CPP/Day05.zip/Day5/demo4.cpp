// static member function -- designed to called on class name     class Members
// in cpp we can call static member function on object name also
// non static member function -- designed to called on object name  instance members
// non static member function can not called on class name
#include<iostream>
using namespace std;
class Maths
{
    public:
    // static member function 
        static int sum(int n1, int n2)
        {
            return n1+n2;
        }
        static int minus(int n1, int n2)
        {
            return n1-n2;
        }
        // non static member function 
        int multiply (int n1, int n2)
        {
            return n1*n2;
        }

}; //end of maths class

int main(void)
{   
    int res= Maths::sum(10,20);
    cout<<" addition of 2 numbers  using class name ="   <<res<<endl; // 10+20=30
    
    res= Maths::minus(10,20);
    cout<<" sub of 2 numbers  using class name ="   <<res<<endl;// 10-20=-10

// non static member function can not called on class name but called on object name 
    //int res= Maths::multiply(10,20);
    //cout<<" multiply of 2 numbers  using class name ="   <<res<<endl;
    
    Maths objMaths1;
    res= objMaths1.multiply(10,20);
    cout<<" multiply of 2 numbers  using object name ="   <<res<<endl;
    
    res= objMaths1.sum(10,20);
    cout<<" addition of 2 numbers  using object name ="   <<res<<endl;
    
    res= objMaths1.minus(10,20);
    cout<<" sub of 2 numbers  using object name ="   <<res<<endl;
    
    return 0;   
}

/* which functions dont have this pointers
1. global functions 
2. friend functon
3. static member function 

/* which functions have this pointers
1. all member  function except static member funtion or all non static  member function of clas

*/