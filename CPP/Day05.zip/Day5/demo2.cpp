#include<iostream>
using namespace std;
int main(void)
{
    int *ptr=NULL;
    int no, index;

    try 
    {
        cout<<"Enter how many elements u want ::";
        cin>>no;

        ptr= new int[no];

        cout<<"enter elements of array="<<endl;
        for(index=0; index<no; index++)
        {
            cout<<"ptr["<<index<<"]=";
            cin>>ptr[index];
        }

        cout<<"elements of array="<<endl;
        for(index=0; index<no; index++)
        {
            cout<<"ptr["<<index<<"]=\t"<<ptr[index]<<"\t &ptr["<<index<<"]=["<< &ptr[index]<<"]\n";
        }

        delete[] ptr;

        ptr=NULL;
        cout<<"memory is freed for an array"<<endl;
    }
    catch(bad_alloc)
    {
        cout<<"unable to allocate memory"<<endl;
        cout<<"bad_alloc exception"<<endl;
    }
    catch(...)
    {
        cout<<"inside generic catch"<<endl;
    }


    return 0;
}