/*
  exception handling
  
  const data member, member fun and object


  static data member and member function

  

  


  

*/

