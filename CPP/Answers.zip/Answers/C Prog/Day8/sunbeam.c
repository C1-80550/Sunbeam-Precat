#include<stdio.h>
#define sq(a) a*a  // macro
int square(int a); // function
int main(void)
{
    int x=5, y=0;
    y= square(x);
    printf("\n x=%d y=%d using function", x, y);

    y= sq(x);  // y=x*x;  y=5*5=  25
    printf("\n x=%d y=%d using function", x, y);

    y= sq(x+x);  //y= x+x*x+x;  y=5+5*5+5;  y=5+25+5; = y=35
    printf("\n x=%d y=%d using function", x, y);
    
    y= 25/sq(x);  // y= 25/x*x ;  y=25/5*5;  y=5*5=25
    printf("\n x=%d y=%d using function", x, y);

    y= sq((x+x));  //y= (x+x)*(x+x);  y=(5+5)*(5+5);  y=10*10; = y=100
    printf("\n x=%d y=%d using function", x, y);
    
    return 0;
}
int square(int a)
{
    return a*a;
}
// gcc -E -o sunbeam.i sunbeam.c   create .i file