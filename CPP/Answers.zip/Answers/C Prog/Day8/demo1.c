#include<stdio.h>
void fun()
{
    int a=11, b=12, c=13;
    static int no1=111;
    static int no2=222;
    static int no3=333;    
    a+=3;b+=3;c+=3;
    no1+=3;no2+=3;no3+=3;
    printf("\n a=%d [%u]  b=%d [%u] c=%d [%u]", a, &a, b,&b, c, &c);
    printf("\n no1=%d [%u ]no2=%d [%u] no3=%d [%u]", no1,&no1,no2,&no2,no3, &no3);
    return;
}
int main()
{
    fun(); // a= 14, b=15 c= 16 no1=114 no2=225 no3= 336
    fun(); // a= 14, b=15 c= 16 no1=117 no2=228 no3= 339
    fun(); // a= 14, b=15 c= 16 no1=120 no2=231 no3= 342
    fun(); // a= 14, b=15 c= 16 no1=123 no2=234 no3= 345
    return 0;
}