#include<stdio.h>
#define SIZE 5
int main(void)
{
    //int arr[ 5 ]; or 
     int arr[SIZE], index;

    //int arr[]={11,22,33,44,55}, index;
    //int arr[SIZE]={1,2}, index;

    printf("\n Enter elements of array :: ");
    for(index=0; index<SIZE; index++)
    {
        printf("\n Enter arr[%d] =", index);
        scanf("%d", &arr[index]);
    }
    printf("\n Elememnts of array =\n");
    for(index=0; index<SIZE ; index++)
    {
        printf("\n arr[%d] %d  [%u]", index, arr[index], &arr[index]);
    }
    printf("\n &arr[0]=%u arr=%u &arr=%u", &arr[0], arr, &arr);
                                      // increment by total size of array
    printf("\n &arr[0]+1=%u arr+1=%u &arr+1=%u", &arr[0]+1, arr+1, &arr+1);
  // increment by size of datatype   
    printf("\n no of elements in array =%d", SIZE);
    printf("\n size array in bytes =%d", sizeof(arr)); // 5*4=20 bytes
    printf("\n *arr=%d", *arr); // print 1st element of array

   /* arr++;  // lvalue error requied error
    ++arr;  /// we can not change  base address of array
    --arr;
    arr--;
    */

    return 0;
}