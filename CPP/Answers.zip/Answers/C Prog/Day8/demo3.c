#include<stdio.h>
int no1=10, no2=20;
void swap(void); // func decl 
int main(void)
{
    
    printf("\n before swap in main no1=%d [%u] no2=%d [%u]", no1, &no1, no2, &no2);
    swap() ; // function call  for swap
    printf("\n after swap in main no1=%d [%u] no2=%d [%u]", no1, &no1, no2, &no2);
    return 0;
}
// fun defination 
void swap(void)
{
    int temp;
    printf("\n before swap in swap no1=%d [%u] n2=%d [%u]", no1, &no1, no2, &no2);
    temp=no1;
    no1=no2;
    no2= temp;
    printf("\n after swap in swap no1=%d [%u] no2=%d [%u]", no1, &no1, no2, &no2);
    return;
}