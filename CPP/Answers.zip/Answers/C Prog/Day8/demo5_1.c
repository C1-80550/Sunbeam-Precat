#include<stdio.h>
#define SIZE 5
int main(void)
{
    int arr[SIZE], index;

    printf("\n Enter elements of array :: ");
    for(index=0; index<SIZE; index++)
    {
        printf("\n Enter arr[%d] =", index);
        // array notation
        //scanf("%d", &arr[index]);
        //scanf("%d", &index[arr]);
        // pointer notation
        //scanf("%d", (arr+index));
        scanf("%d", (index+arr));
    }
    printf("\n Elememnts of array =\n");
    for(index=0; index<SIZE ; index++)
    {   // array notation
        //printf("\n arr[%d] %d  [%u]", index, arr[index], &arr[index]);
        //printf("\n [%d]arr %d  [%u]", index, index[arr], &index[arr]);
        // pointer notation
        //printf("\n *(arr+%d) %d  [%u]", index, *(arr+index),(arr+index));
        printf("\n *(%d+arr) %d  [%u]", index, *(index+arr),(index+arr));
    }
    return 0;
}