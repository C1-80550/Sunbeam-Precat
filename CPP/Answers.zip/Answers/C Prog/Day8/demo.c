// sumproddiv
// macro
// array 
// passing array to fun
// array and pointer noatation
// introduction to constants
