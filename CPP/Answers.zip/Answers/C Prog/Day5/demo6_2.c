#include<stdio.h>
int main(void)
{  // print patterns
    int row, col, cnt=0;
    for(row=1; row<=5; row++)
    {
        for(col=1;col<=row; col++)
        {
            cnt++;
          //  printf("%5d", col);
          //   printf("%5d", row);
          //  printf("%5c", col+64);
          // printf("%5c", row+64);
           //printf("%5c", row+96);
           //printf("%5c", col+96);
           //printf("  *  " );
            printf("%5d",cnt);
        }
        printf("\n");
    }
    printf("cnt=%d", cnt);
    return 0;
}
