// sum of digits
/*
  123 == 1+2+3==   6
  -95 == -9+-5==-14 

  1. start
  2. accept no
  3. assign sum=0 rem=0
  4. check no!=0
      if yes
        rem = no%10
        divide no by 10
        add rem into sum
      go to step 4
  5. if no
        print sum
  6. stop

  no     rem   sum
  123%10   0      0
  123/10   3    0+3=3
  12%10    2    3+2=5
  12/10    1    5+1=6
  1%10   
  1/10
  0
*/
#include<stdio.h>
int main(void)
{
    int no, sum, rem;
    printf("\n Enter No = ");
    scanf("%d", &no);

    sum= rem=0;
    while(no!=0)
    {
        rem = no%10;
        printf("%5d", rem);
        no/=10;  // no=no/10;
        sum+= rem;  // sum= sum+rem;
    }
    printf("\nsum of digits= %d", sum);
    return 0;
}

