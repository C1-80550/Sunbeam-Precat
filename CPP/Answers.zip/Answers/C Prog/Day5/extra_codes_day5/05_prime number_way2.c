/* prime number  2ed logic

   every no is divisible by 1 and no itself so we should start counter from 2
   if any no is divisible by counter then it is not a prime no
   if any no is not divisibe by counter then it prime no
*/
#include<stdio.h>
int main()
{
    int no, counter;

    printf("\n Enter No = ");
    scanf("%d", &no);

    counter=2;
    while(counter<no)
    {
        if(no%counter==00)
        {
            printf("\n %d is divisible by %d", no, counter);
            break;
        }
        counter++;
    }
    if(no==counter)
        printf("\n %d is prime number", no);
    else
        printf("\n %d is not a prime number", no);
    return 0;
}
/*
    Enter No = 11

    11 is prime number


     Enter No = 10

        10 is divisible by 2
    10 is not a prime number

*/
