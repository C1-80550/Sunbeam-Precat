/* prime number 
   if number have 2 factors it is called as prime number
   5  ----->  1     5
   7 ------>  1     7
   11 ----->  1     11
*/
#include<stdio.h>
int main()
{
    int no, counter, no_of_factors;

    printf("\n Enter No = ");
    scanf("%d", &no);

    counter=no_of_factors=0;
    while(counter<no)
    {
        counter++;
        if(no%counter==00)
        {
            printf(" %5d ", counter);
            no_of_factors++;
        }
    }
    printf("\n numbers of factors of %d are %d ", no, no_of_factors);
    if(no_of_factors==2)
        printf("\n %d is prime number", no);
    else
        printf("\n %d is not a prime number", no);
    return 0;
}
/*
Enter No = 11
     1     11 
 numbers of factors of 11 are 2 
 11 is prime number

Enter No = 11
     1     11 
 numbers of factors of 11 are 2 
 11 is prime number

*/
