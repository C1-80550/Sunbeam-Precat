// check no is armstrong of not
/*
   sum of cube of digits equal to orignal no
   153=  1*1*1 + 5*5*5 + 3*3*3
          1+125+27 ==153 

    armstrong number between 1 to 500    
    1   153   370  371   407  

*/
#include<stdio.h>
int main()
{
    int no, rem , sum, ono;
    printf("\n Enter No :: ");
    scanf("%d", &no);
    rem= sum=0;
    ono=no;
    while(no!=0)
    {
        rem = no%10;
        printf(" %d * %d * %d +", rem, rem, rem);
        no/=10; // no=no/10;
        sum+=rem*rem*rem; // sum= sum+rem*rem*rem;
    }
    printf("\b= %d", sum);
    if(ono==sum)
        printf("\n %d is armstrong number", ono);
    else
        printf("\n %d is not a armstrong number", ono);

    return 0;
}

/* Enter No :: 153
 3 * 3 * 3 + 5 * 5 * 5 + 1 * 1 * 1 = 153
 153 is armstrong number



 Enter No :: 407
 7 * 7 * 7 + 0 * 0 * 0 + 4 * 4 * 4 = 407
 407 is armstrong number


 Enter No :: 123
 3 * 3 * 3 + 2 * 2 * 2 + 1 * 1 * 1 = 36
 123 is not a armstrong numbe

*/