/* factors of given numbers
   10 --->> 1   2    5   10
   7 -----> 1    7
*/
#include<stdio.h>
int main()
{
    int no, counter;

    printf("\n Enter No = ");
    scanf("%d", &no);

    counter=0;
    while(counter<no)
    {
        counter++;
        if(no%counter==00)
        {
            printf(" %5d ", counter);
        }
    }
    return 0;
}
/* Enter No = 10
     1      2      5     10

   Enter No = 7
     1      7

*/
