// check no is palindrome or not
//  121  ==  121    pal
//  123  ==  321    not
//  333  ==  333   pal

/*
1. start
2. accept no
3. assign rev = rem=0  , ono=no
4. check no!=0
    if yes
        rem = no%10
        divide no by 10
        multiply rev by 10 and add rem
    go to step 4
 5. if no 
      print rev
 6. if ono==rev      
       if yes palindrome
       if no  not palindrome
 7. stop

no     rem   rev            ono
121%10   1   0*10+1=1        121
121/10
12%10    2   1*10+1=12
12/10
1%10     1   12*10+1=121
1/10
0

123%10  3   0*10+3=3      123
123/10
12%10   2  3*10+2= 32
12/10
1%10    1   32*10+1= 321      
1/10
0  

*/
#include<stdio.h>
int main(void)
{
    int no, rev, rem, ono;
    printf("\n Enter No = ");
    scanf("%d", &no);
    ono=no;
    rev= rem=0;
    while(no!=0)
    {
        rem = no%10;
        printf("%5d", rem);
        no/=10;  // no=no/10;
        rev= rev*10+ rem;  
    }
    printf("\nrev of digits= %d", rev);
    if(ono== rev)
        printf("\n %d is palindrome", ono);
    else
        printf("\n %d is not palindrome", ono);

    return 0;
}




