#include<stdio.h>
int main(void)
{  // print hori and vertical table of no
    int row, col, cnt=0;
    for(row=1; row<=10; row++)
    {
        for(col=1;col<=10; col++)
        {
            cnt++;
            //printf("\n row=%d col=%d", row, col);
            printf("%5d", row*col);
        }
        printf("\n");
    }
    printf("cnt=%d", cnt);
    return 0;
}
