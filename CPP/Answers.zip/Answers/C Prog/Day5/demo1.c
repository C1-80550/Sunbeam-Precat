/* factorial of no

1. start
2. accept no
3. assign fact=1 and counter=0
4. check counter<no
     if yes
        increment counter by 1
         multiply fact by counter
     go to step 4
5. if no
    print fact
6. stop

no   counter   fact
5       0+1=1   1*1=1
        1+1=2   1*2=2
        2+1=3   2*3=6
        3+1=4   6*4=24
        4+1=5   24*5=120 
*/



#include<stdio.h>
int main(void)
{
    int no, counter, fact;
    printf("\n Enter No =");
    scanf("%d", &no);
    fact=1;  
    counter=0; 
    while(counter<no)    
    {
        counter++; // counter= counter+1;
        printf("%5d *", counter);
        fact*=counter; // fact=fact * counter;
    }
    printf("\b= %d", fact);

    return 0;
}