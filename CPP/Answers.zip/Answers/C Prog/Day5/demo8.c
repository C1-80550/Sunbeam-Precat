#include <stdio.h>
void print(int arr[])
{
	int n = sizeof(arr)/sizeof(arr[0]);
	int i;
	for (i = 0; i < n; i++)
		printf("%d ", arr[i]);
	return;
}
int main( void )
{
	int arr[] = {11, 22, 33, 44, 55, 66, 77, 88};
	print(arr);

	return 0;
}