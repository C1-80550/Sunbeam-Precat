#include<stdio.h>
// 1 . function decl or prototype  of fun
//  1       2           2
//output function_name(input);
//return_type function_name(data_type parameter1);
int addition (int n1, int n2);
int main(void)
{
    int no1=10, no2= 20 , ans=0;
    ans= addition(no1, no2) ;// 3. function call 
    // no1 , n2 are actual arguments
    printf("\n %d + %d = %d", no1, no2, ans);
    return 0;
}
// 2 function defination (implemention of logic)
 // n1 , n2 formal arguments
int addition (int n1, int n2)
{
    int result=0;
    result=n1+n2;
    return n1, n2, result;   // it will return last value
    //return (n1, n2, result);  // in both cases
}
/*     
window                          linux / mac
            text file
.c          source code           .c
 
.i                                .i 

.asm    assembly file            .s 

            binary files
.obj    object code               .o
        
.exe    executable               .out
*/