// sum of digits
// factorial
// count no of digits
// rev digits
// function call by value
// nested loops
// bit wise operators
// sum of 1st n numbers
// 5 --> 1 +2+3+4+5=15

/*
1. start
2. accept no
3. assign sum=0 and counter=0
4. check counter<no
     if yes
        increment counter by 1
        add counter into sum
     go to step 4
5. if no
    print sum
6. stop

no   counter   sum
5       0+1=1   0+1=1
        1+1=2   1+2=3
        2+1=3   3+3=6
        3+1=4   6+4=10
        4+1=5   10+5=15 
*/
#include<stdio.h>
int main(void)
{
    int no, counter, sum;
    printf("\n Enter No =");
    scanf("%d", &no);
    sum=counter=0;  //sum=0; counter=0; 
    while(counter<no)    
    {
        counter++; // counter= counter+1;
        printf("%5d +", counter);
        sum+=counter; // sum= sum+ counter;
    }
    printf("\b= %d", sum);

    return 0;
}
