// table of no
// 5 ==  5 10 15      50

#include<stdio.h>
int main(void)
{
    int no, counter;

    printf("\n Enter No =");
    scanf("%d", &no);
    printf("\n table of %d  \n", no);
    for(counter=1; counter<=10; counter++)
    {
        printf("\n%-4d*%-4d=%-4d", no, counter, no*counter);
    }
    return 0;
}
/* armstrong 
 sum of cube of digits equal to no
 153  == 1*1*1+5*5*5+3*3*3
      ==  1+125+27
      ==  153

1   153  370  371 407


prime no

divide by 1 and itself
if no have 2 factors we can say no is prime


 */

