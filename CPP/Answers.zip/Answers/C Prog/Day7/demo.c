/*
print 1 to 100 no using rec
rec decimal to binary
pre increment decrement in rec
static in functions
swap by call by value
pointers
swap by call by address
pointer to pointers
*/