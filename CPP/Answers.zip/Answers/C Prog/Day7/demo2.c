#include<stdio.h>
int binary(int n);
int main(void)
{
    int no, ans;
    printf("\n Enter No = ");
    scanf("%d", &no);
    ans= binary(no);
    printf("\n binary of %d is %d", no, ans);
    return 0;
}
int binary(int n)
{
    int res=0;
    if(n==1)
    {
        printf("\n binary(%d) res = 1 ", n);
        return 1;
    }
    else
    {
        //res= binary(n/2)*10+n%2;    
        //res= n%2 + binary(n/2)*10;
        res= n%2 + 10*binary(n/2);
        printf("\n binary(%d)  res = %d ", n, res);

        return res;
    }
}



/*           11001
2 25  1
2 12  0
2 6   0 
2 3   1
  1   1
*/

// fibo series  // 1 loop  2 recursion
// no1  no2 no3
// 0   1    1     2    3       5     8    13  21   34
//     no1  no2
