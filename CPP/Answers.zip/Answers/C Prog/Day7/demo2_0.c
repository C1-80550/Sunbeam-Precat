#include<stdio.h>
int binary(int n);
int main(void)
{
    int no, ans;
    printf("\n Enter No = ");
    scanf("%d", &no);
    ans= binary(no);
    printf("\n binary of %d is %d", no, ans);
    return 0;
}
int binary(int n)
{
     if(n==1)
        return 1;
    else
        return n%2 + 10*binary(n/2);
}



/*           11001
2 25  1
2 12  0
2 6   0 
2 3   1
  1   1
*/