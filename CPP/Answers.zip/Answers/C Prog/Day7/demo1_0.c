#include<stdio.h>

void display();  // fun decl
int main(void)
{
    display();  // function call
    return 0;
}
// fun defination
void display()
{
    static int no=1;
    //  getchar();
    if(no>10)
        return;
    else
    {
        printf("\n%d [%u] ", no, &no);
        no++;
        display();  // function calling itself
    }
    return;
}