/*
swap 2 numbers
1. using temp variable

temp=n1;
n1=n2;
n2=temp;

n1   n2    temp
10   20    10
20   10

2. swap using addition and substraction
n1=n1+n2;
n2=n1-n2;
n1=n1-n2;

n1        n2
10        20
10+20=30  30-20=10
30-10=20
20       10

3. swap using miltiplication and div
n1=n1*n2;
n2=n1/n2;
n1=n1/n2;

n1        n2
10        20
10*20=200  200/20=10
200/10=20
20       10

4. swap using xor bit wise operator

https://www.youtube.com/watch?v=Rrw7gtSUphQ
https://www.youtube.com/watch?v=GobD8fE7dDM&t=3s

*/
#include<stdio.h>
// swap using call by value
void swap(int n1, int n2); // func decl 
int main(void)
{
    int no1=10, no2=20;
    printf("\n before swap in main no1=%d [%u] no2=%d [%u]", no1, &no1, no2, &no2);
    swap(no1, no2) ; // function call  for swap
    // no1, no2 are actual arguments
    printf("\n after swap in main no1=%d [%u] no2=%d [%u]", no1, &no1, no2, &no2);
    return 0;
}
// fun defination  n1, n2 is formal arguments
void swap(int n1, int n2)
{
    int temp;
    printf("\n before swap in swap n1=%d [%u] n2=%d [%u]", n1, &n1, n2, &n2);
    temp=n1;
    n1=n2;
    n2= temp;
    printf("\n after swap in swap n1=%d [%u] n2=%d [%u]", n1, &n1, n2, &n2);
    return;
}
