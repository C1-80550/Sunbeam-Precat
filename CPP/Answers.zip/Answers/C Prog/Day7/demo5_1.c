#include<stdio.h>
int main(void)
{
    {
        int z=3;  // z variable of int type
        //int *z_ptr=&z;  // init of pointer at of decl
        // or
        int *z_ptr=NULL;  // decl of pointer
        // int *z_ptr=0;
        z_ptr=&z;  // storing address of z into pointer z_ptr

        printf("\n z=%d", z) ; //z=3
        printf("\n *(&z)=%d", *(&z)) ; // *(1000) == 3
        printf("\n *z_ptr=%d", *z_ptr); // *(1000)=3
        printf("\n &z=%u  z_ptr=%u  &z_ptr=%u", &z, z_ptr, &z_ptr);
        printf("\n size of zptr=%d", sizeof(z_ptr));  //8 bytes
       //%p which display address in hex
       printf("\n &z=%p z_ptr=%p  &z_ptr=%p", &z, z_ptr, &z_ptr);

        *z_ptr= 10;   // *(1000)=10
        printf("\n z=%d", z) ; //z=10
        printf("\n *(&z)=%d", *(&z)) ; // *(1000) == 10
        printf("\n *z_ptr=%d", *z_ptr); // *(1000)== 10
    
        printf("\n z_ptr=%u z_ptr+1=%u", z_ptr,z_ptr+1);// 1000  1000+1==1004 int
        printf("\n z_ptr=%u z_ptr-1=%u", z_ptr,z_ptr-1);// 1000  1000-1==996  int
        
        printf("\n z_ptr=%u z_ptr+5=%u", z_ptr,z_ptr+5);// 1000  1000+5==1020 int
        printf("\n z_ptr=%u z_ptr-5=%u", z_ptr,z_ptr-5);// 1000  1000-5==980 int
        
        //printf("\n z_ptr=%u z_ptr*5=%u", z_ptr,z_ptr*5);// error
        //printf("\n z_ptr=%u z_ptr/5=%u", z_ptr,z_ptr/5);// error
// invalid operands to binary *  // invalid operands to binary /
        /*
            z_ptr + 5  allowed 
            z_ptr - 5  allowed
            z_ptr * 5  not allowed
            z_ptr / 5  not allowed

            *z_ptr + 5  allowed 
            *z_ptr - 5  allowed
            *z_ptr * 5  allowed
            *z_ptr / 5  allowed

            z_ptr + y_ptr  not allowed
            z_ptr * y_ptr  not allowed
            z_ptr / y_ptr  not allowed

            *z_ptr + *y_ptr  allowed
            *z_ptr * *y_ptr  allowed
            *z_ptr / *y_ptr  allowed

        */
        
    }

        {
            char z='A';  // z variable of char type
        //char *z_ptr=&z;  // init of pointer at of decl
        // or
        char *z_ptr=NULL;  // decl of pointer
        // int *z_ptr=0;
        z_ptr=&z;  // storing address of z into pointer z_ptr

        printf("\n z=%c", z) ; //z=A
        printf("\n *(&z)=%c", *(&z)) ; // *(1000) == A
        printf("\n *z_ptr=%c", *z_ptr); // *(1000)=A
        printf("\n &z=%u  z_ptr=%u  &z_ptr=%u", &z, z_ptr, &z_ptr);
        printf("\n size of zptr=%d", sizeof(z_ptr));  //8 bytes
       //%p which display address in hex
       printf("\n &z=%p z_ptr=%p  &z_ptr=%p", &z, z_ptr, &z_ptr);

        *z_ptr= 'B';   // *(1000)='B'
        printf("\n z=%c", z) ; //z='B'
        printf("\n *(&z)=%c", *(&z)) ; // *(1000) == 'B'
        printf("\n *z_ptr=%c", *z_ptr); // *(1000)== 'B'
    
        printf("\n z_ptr=%u z_ptr+1=%u", z_ptr,z_ptr+1);// 1000  1000+1==1001 char
        printf("\n z_ptr=%u z_ptr-1=%u", z_ptr,z_ptr-1);// 1000  1000-1==999  char

         printf("\n z_ptr=%u z_ptr+5=%u", z_ptr,z_ptr+5);// 1000  1000+5==1005 char
         printf("\n z_ptr=%u z_ptr-5=%u", z_ptr,z_ptr-5);// 1000  1000-5==995 char
        
    }

    {
        short int z=3;  // z variable of short int type
        //short int *z_ptr=&z;  // init of pointer at of decl
        // or
        short *z_ptr=NULL;  // decl of pointer
        // int *z_ptr=0;
        z_ptr=&z;  // storing address of z into pointer z_ptr

        printf("\n z=%hd", z) ; //z=3
        printf("\n *(&z)=%hd", *(&z)) ; // *(1000) == 3
        printf("\n *z_ptr=%hd", *z_ptr); // *(1000)=3
        printf("\n &z=%u  z_ptr=%u  &z_ptr=%u", &z, z_ptr, &z_ptr);
        printf("\n size of zptr=%d", sizeof(z_ptr));  //8 bytes
       //%p which display address in hex
       printf("\n &z=%p z_ptr=%p  &z_ptr=%p", &z, z_ptr, &z_ptr);

        *z_ptr= 10;   // *(1000)=10
        printf("\n z=%hd", z) ; //z=10
        printf("\n *(&z)=%hd", *(&z)) ; // *(1000) == 10
        printf("\n *z_ptr=%hd", *z_ptr); // *(1000)== 10
    
        printf("\n z_ptr=%u z_ptr+1=%u", z_ptr,z_ptr+1);// 1000  1000+1==1002 short int
        printf("\n z_ptr=%u z_ptr-1=%u", z_ptr,z_ptr-1);// 1000  1000-1==998  short int

        printf("\n z_ptr=%u z_ptr+5=%u", z_ptr,z_ptr+5);// 1000  1000+5==1010 short int
        printf("\n z_ptr=%u z_ptr-5=%u", z_ptr,z_ptr-5);// 1000  1000-5==990 short int
       
    }

    return 0;
}