#include<stdio.h>
int sumrec(int n);
int main(void)
{
    int no, ans;
    printf("\n Enter No ::");
    scanf("%d", &no);

    ans= sumrec(no);
    printf("\n sum of %d =%d", no, ans);

    return 0;
}
int sumrec(int n)
{
    int add;
    printf("\n n=%d [%u]", n, &n);
    if(n==1)  // term condition
    {
        printf("\n n=%d add=1", n);
        return 1;
    }
    else
    {
           add= n+ sumrec(n-1);  // correct output 15 if input is 5
     //   add= n+ sumrec(n--);  // stack overflow
     //   add= n+ sumrec(--n);  // different ouput 11 if input is 5
        printf("\n n=%d add=%d", n, add);
    }
    return add;   
}