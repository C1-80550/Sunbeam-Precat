#include<stdio.h>
int main(void)
{
    int z=3;  // z variable of int type
    //int *z_ptr=&z;  // init of pointer at of decl
    // or
    int *z_ptr=NULL;  // decl of pointer
    // int *z_ptr=0;
    z_ptr=&z;  // storing address of z into pointer z_ptr

    printf("\n z=%d", z) ; //z=3
    printf("\n *(&z)=%d", *(&z)) ; // *(1000) == 3
    printf("\n *z_ptr=%d", *z_ptr); // *(1000)=3
    printf("\n &z=%u  z_ptr=%u  &z_ptr=%u", &z, z_ptr, &z_ptr);
    printf("\n size of zptr=%d", sizeof(z_ptr));  //8 bytes

    *z_ptr= 10;   // *(1000)=10
    printf("\n z=%d", z) ; //z=10
    printf("\n *(&z)=%d", *(&z)) ; // *(1000) == 10
    printf("\n *z_ptr=%d", *z_ptr); // *(1000)== 10
    

    return 0;
}
// gcc -m32 demo1.c     32 bit complication
// gcc -m64 demo1.c     32 bit complication

// pointer size on 32 bit os == 4 bytes
// pointer size on 64 bit os == 8 bytes
// pointer size on 16 bit os == 2 bytes (turboc ) dos 16 bit
