#include<stdio.h>
//int no=1;
int main(void)
{
    static int no=1;
    if(no==1)
        printf("\n calling main rec\n");
    if(no>10)
        return 0;
    else
    {
        printf("\n%d [%u] ", no, &no);
        no++;
        main();
    }
 
    return 0;
}

