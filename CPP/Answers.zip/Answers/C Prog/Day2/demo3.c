#include<stdio.h>
int main(void)
{
    int  no1=999, no2=55555;
    printf("\n no1=%10d no2=%10d", no1, no2); // right
    printf("\n no1=%-10d no2=%-10d", no1, no2);// left
    printf("\n no2=%-10d no1=%-10d", no2, no1);// left
    return 0;

}