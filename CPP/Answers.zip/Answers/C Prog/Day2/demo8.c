

int main()
{
    printf("sunbeam\rcdac");
    return 0;
} // cdaceam online c compiler
