#include<stdio.h>
int main(void)
{
    int no1=10, no2=3, ans=0;
    ans= no1/no2;
    printf("\n ans=%d", ans); // ans=3
    float ans1=0.0f;
    ans1= no1/no2;
    printf("\n ans1=%f", ans1); // ans=3.000000
    ans1=(float) no1/no2; // type casting
    printf("\n ans1=%f", ans1); // ans=3.333333

    float ans1=0.0f;
    ans1= no1/3.0f;
    printf("\n ans1=%f", ans1); // ans=3.333333
    printf("\n ans1=%.2f", ans1); // ans=3.33
    

    return 0;
}