#include<stdio.h>
int main(void)
{
    int no;
    no=printf("SunBeam");
    printf("\n no=%d", no);
    no=printf("\nSunBeam\tPune\tKarad");
    printf("\n no=%d\n", no);
    
    printf("\n no=%d", printf("SunBeam"));
// printf return no of char printed on screen
    return 0;
}