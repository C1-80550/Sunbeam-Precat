//*1.
/*
#include<stdio.h>
int main(void)
{
	int x = 1, y = 2, z = 0;
// T 1	
//      T	   3
//      2      T
//      1      2
	z =++x && y++;
                             //    2  3  1
    printf("\n x=%d, y=%d,  z=%d", x, y, z);

	return 0;
}
*/
/*
  logical and &&
	T   T    T
	T   F    F
	F   T    F
	F   F    F

*/


// 2.
/*
#include<stdio.h>
int  main(void)
{
	int x = -1, y = 2, z = 0;
	//   0       3
//  T    T       T 
//  1    -1      2
	z = x++ && y++;
//                                   0  3  1                         
	printf("\n x=%d, y=%d,  z=%d\n", x, y, z);
  // return 0;

    x = -1, y = 2, z = 0;
//      F      	
//	0    0
//  F   -1     not check 2ed condition
    z = ++x && y++;                //0  2  0   
    printf("\n x=%d, y=%d,  z=%d\n", x, y, z);

	return 0;
}
*/


//3.
/*
#include<stdio.h>
int main(void)
{
	int x = 0, y = 0, z = 0;
	//F   F      F
	//0   0      0 
 	z = x++ || y++;
  //                               1  1  0
	printf("\n x=%d, y=%d,  z=%d", x, y, z);

	return 0;
}
*/
/*  logical or  ||
     T   T  T
	 T   F  T
	 F   T  T
	 F   F  F

*/

// 4.
/*
#include<stdio.h>
int main(void)
{
	int x = -1, y = -1, z = 0;
//  T    F	      0
//  1    0	      T
//      -1        -1
	z = ++x   || y++;             // 0  0  1 
	printf("\n x=%d, y=%d,  z=%d\n", x, y, z);
	//return 0;
    x = -1, y = -1, z = 0;
//  F    F	
//	     0
//  0    -1       not check 2ed part
    z = ++x   && y++;   
 //                                 0  -1  0
	printf("\n x=%d, y=%d,  z=%d\n", x, y, z);
	return 0;
}
*/


//5.

/*
#include<stdio.h>
int main(void)
{
	int i, j, k, l;
	i = j = k =1;
//  T   T	
//  1    1       not checked 2ed part
	l = i++ || j++ && k++;
//    =====	   ==========
//  left to right                 2  1  1  1
	printf("i=%d j=%d k=%d l=%d", i, j, k, l);

	return 0;
}
*/


//6.
/*
#include<stdio.h>
int main(void)
{
	int i, j, k, l;
	i = j = k = 1;
//        T             not checked	
//      T	   T
//      2      2
//  1   1       1
	l = ++i && ++j || ++k;
//      =========     ====     2   2  1  1
  printf("i=%d j=%d k=%d l=%d", i, j, k, l);

	return 0;
}
*/


//7.
/*
#include<stdio.h>
int main()
{
	int i=1, j=1, k=1, l;
//       2	
/// T     T
//  1     1     not checked
	l = i++ || j++ || k++;
//      ==========    ===         2  1  1  1
	printf("i=%d j=%d k=%d l=%d", i, j, k, l);

	return 0;
}
*/

//8.
/*
#include<stdio.h>
int main(void)
{
	int i, j, k, l;
	i = j = k = -1;
//                      F  	
//                    0	
//          f        -1	
//       f	
//       0
 //     -1     not check
	l = ++i  && ++j || ++k;
//      ==========     =====  //  0  -1 0  0  
	printf("i=%d j=%d k=%d l=%d", i, j, k, l);

	return 0;
}
*/
//9
/*
#include<stdio.h>
int main(void)
{  // compiler depending
	int i=3, j;
	// GCC 
	//  4      5 =25*6=150
	//  3   *  4    5
	j = ++i * ++i * ++i;

	printf("i=%d j=%d\n", i,j);
	i=3;   // 4   5*5=25*6  150*7 1050
	//       3    4      5     6
		j = ++i * ++i * ++i * ++i;

	printf("i=%d j=%d\n", i,j);

	i=3;
 // tcc / vs
 //    4      5     6
  //    3     4     5     6*6*6=216 
	j = ++i * ++i * ++i ;

	printf("i=%d j=%d\n", i,j);
	
	return 0;
}
*/

//10.


#include<stdio.h>
int main(void)
{ //                        6    6    7   9     10
   // 5                     5    6    7   8     9                  
	int i = (3, 4, 5), j = (++i, i++, i++, ++i, ++i);
                        // 10 10
	printf("i=%d j=%d\n ", i, j);

           //               6     6    7    9   10
  {     //5                 5     6    7    8   9       
	int i = (3, 4, 5), j = (++i, i++, i++, ++i, i++);
            //             10  9
	printf("i=%d j=%d\n ", i, j);
    }
	return 0;
}


//11
/*
#include<stdio.h>
int main(void)
{
	int i, j;

	i=3,4,5; 
   
   j=(++i,  ++i, ++i);
  
	printf("i=%d j=%d\n ", i, j);

	return 0;

}

*/
//12
/*
#include<stdio.h>
int main(void)
{
	int i = (3, 4, 5);
	int j =( ++i, i++, i++, ++i, ++i);
   
	printf("\n i=%d j=%d", i, j);

	return 0;
}
*/