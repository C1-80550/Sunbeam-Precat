#include<stdio.h>
int main(void)
{  // -128 -127  -126 -125      0   126 127
  //   128  129  130  131
    {   // -128 to 127
        signed char ch1='A', ch2='B', ans=0;
        ans= ch1+ch2; // 65+66=131
        printf("ans=%d", ans); // -125
    }
    {   // 0 to 255
        unsigned char ch1='A', ch2='B', ans=0;
        ans= ch1+ch2; // 65+66=131
        printf("ans=%d", ans); //131
    }
    {
        int no1=300, no2=300, ans=0;
        ans=no1*no2; // 90000
        printf("\n ans= %d", ans);
    }
    {
         // -32768 -32767         0            32766 32767
        short int no1=300, no2=300, ans=0;
        ans=32767;
        printf("\n ans= %d", ans);
        ans=32768;
        printf("\n ans= %d", ans); // -32768
        ans=32769;
        printf("\n ans= %d", ans); // -32767
        ans= 65535;
        printf("\n ans= %d", ans); // -1
        ans= 65536;
        printf("\n ans= %d", ans); // 0
        
        //return 0;

        ans=no1*no2; // 90000
        printf("\n ans= %hd", ans); //24464
    }

    return 0;
}