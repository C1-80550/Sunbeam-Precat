#include<stdio.h>
int main(void)
{
    int no1, no2, no3, ans;
    printf("\n enter no1, no2 and no3 ::");
    ans= scanf("%d%d%d", &no1, &no2,&no3);
    printf("\n ans=%d", ans); //ans=3

   printf("\n enter no1and no3 ::");
    ans= scanf("%d%d", &no1, &no3);
    printf("\n ans=%d", ans); // ans=2


    printf("\n enter no1 ::");
    ans= scanf("%d", &no1);
    printf("\n ans=%d", ans); // ans=1

// scanf return no of input scan 
    return 0;
}