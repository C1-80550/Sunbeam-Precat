#include<stdio.h>
int main(void)
{
    int no1, no2;
    char ch;
    printf("\n Enter ch=");
    scanf("%c", &ch);  // getchar ingores one char
    
    

    printf("\n Enter no1=");
    scanf("%d", &no1);
    printf("\n Enter no2=");
    scanf("%d", &no2);
    
     
    printf("\n no1=%d no2=%d ch=%c ch=%d", no1, no2, ch, ch);
    return 0;
}