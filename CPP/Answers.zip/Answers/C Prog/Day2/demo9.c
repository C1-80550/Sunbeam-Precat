// pre increment // pre decrement
// post increment // post decrement
#include<stdio.h>
int main(void)
{
    {
        int x=4, y=0;
        //  5 
        //  4
        y= ++x; // pre incrment
        // increment value of x by 1 and assigned to y
        printf("\n x=%d y=%d", x, y); // x=5, y=5
    }
    {
        int x=4, y=0;
        //  5
        //  4
        y= x++; // post increment
        // assigned value of x to y then increment value of x by 1 
        printf("\n x=%d y=%d", x, y); // x=5, y=4
    }
     {
        int x=4, y=0;
        //  3
        //  4
        y= x--; // post decrement
        // assigned value of x to y then decrement value of x by 1 
        printf("\n x=%d y=%d", x, y); // x=3, y=4
    }
    {
        int x=4, y=0;
        //  3
        //  4
        y= --x; // pre decrement
        // decrement value of x by 1 then assigned value of x to y 
        printf("\n x=%d y=%d", x, y); // x=3, y=3
    }
    {  // error: lvalue required as increment operand
        //printf("5=%d", 5++); // lvalue requried error
        //printf("5=%d", 5--); // lvalue requried error
        //printf("5=%d", --5); // lvalue requried error
        //printf("5=%d", ++5); // lvalue requried error
    }
    {
        int x=4, y=5;
        //printf("%d", ++(x+y)); // lvalue requried error
        printf("%d", (x+y)--); // lvalue requried error
        // we can not use ++ -- operators with expressions
    }
    return 0;

}
