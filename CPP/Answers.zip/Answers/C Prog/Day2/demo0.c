// printf scanf returns
// left and right allignments
// type casting
// range of data types (add of char and multiply of short int)
// alogo flowchart
// scanf of char and int 
// pre post increment / decrement
// and or not (twisters)
// octal hex decimal

