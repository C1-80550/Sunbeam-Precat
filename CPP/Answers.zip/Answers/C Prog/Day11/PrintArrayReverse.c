
#include<stdio.h>
#define SIZE 5
//void AcceptArray(int a[], int size);
//void AcceptArray(int a[SIZE], int size);
void AcceptArray(int *a, int size);
void PrintArray(int a[], int size);
void PrintArrayReverse(int a[], int size);
int main(void)
{
    int arr[ SIZE ];  // int arr[ 5 ];
   

    printf("\n enter elements of array ::\n");
    AcceptArray(arr, SIZE);

    printf("\n elements of array ::\n");
    PrintArray(arr, SIZE);

    printf("\n  print rev array \n");
    PrintArrayReverse(arr, SIZE);

    return 0;

}
void AcceptArray(int *a, int size)
{
    int index;
    
    for(index=0; index<size; index++)
    {
        printf("\n a[%d] = ", index);
        // array notation
        //scanf("%d", &a[index]);
       // scanf("%d", &index[a]);
        // pointer notation
        //scanf("%d", (a+index));
        scanf("%d", (index+a));       
    }
  
    return;
}
void PrintArray(int a[], int size)
{
    int index;
  
    for(index=0; index<size; ++index)
    {
        // array notation
        //printf("\n a[%d] %d [%u]", index, a[index], &a[index]);
       // printf("\n [%d]a %d [%u]", index, indSIZEex[a], &index[a]);
           // pointer notation
        //printf("\n *(a+%d) %d [%u]", index, *(a+index), (arr+index));
        printf("\n *(%d+a) %d [%u]", index, *(index+a), (index+a));
    
    }
    return;
}


//  print rev array
void PrintArrayReverse(int a[], int size)
{
    int index;
    for(index=size-1; index>=0; index--)
    {
       // array notation
        //printf("\n a[%d] %d [%u]", index, a[index], &a[index]);
       // printf("\n [%d]a %d [%u]", index, indSIZEex[a], &index[a]);
           // pointer notation
        //printf("\n *(a+%d) %d [%u]", index, *(a+index), (arr+index));
        printf("\n *(%d+a) %d [%u]", index, *(index+a), (index+a));
    }
    return;
}
/*

enter elements of array ::

 a[0] = 11

 a[1] = 22

 a[2] = 33

 a[3] = 44

 a[4] = 55

 elements of array ::

 *(0+a) 11 [140831104]
 *(1+a) 22 [140831108]
 *(2+a) 33 [140831112]
 *(3+a) 44 [140831116]
 *(4+a) 55 [140831120]
  print rev array 

 *(4+a) 55 [140831120]
 *(3+a) 44 [140831116]
 *(2+a) 33 [140831112]
 *(1+a) 22 [140831108]
 *(0+a) 11 [140831104]
*/