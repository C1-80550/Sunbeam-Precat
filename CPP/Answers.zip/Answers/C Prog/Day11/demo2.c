#include<stdio.h>
#define ROW 2
#define COL 2
//void accept_matrix(int m[ROW][COL], int row, int col);
void accept_matrix(int m[][COL], int row, int col);
void print_matrix(int m[][COL], int row, int col);
void matrix_addition(int m1[][COL], int m2[][COL], int res[][COL], int row, int col);
void matrix_sub(int m1[][COL], int m2[][COL], int res[][COL], int row, int col);

int main()

{

    int mat1[ROW][COL],mat2[ROW][COL],ans[ROW][COL],r,c;

    printf("\n Enter elements of Mat1 ::\n");
    accept_matrix(mat1, ROW, COL);

    printf("\n elements of mat1 ::\n");
    print_matrix(mat1, ROW, COL);

    printf("\n Enter elements of Mat2 ::\n");
    accept_matrix(mat2, ROW, COL);

    printf("\n elements of mat2 ::\n");
    print_matrix(mat2, ROW, COL);

    printf("\n addition of matrix ::\n");
    matrix_addition(mat1, mat2, ans, ROW, COL);
    print_matrix(ans, ROW, COL);
  
    printf("\n sub of matrix ::\n");
    matrix_sub(mat1, mat2, ans, ROW, COL);
    print_matrix(ans, ROW, COL);

    return 0;
}
void accept_matrix(int m[][COL], int row, int col)
{
    int r,c;
    for(r=0; r<row; r++)
    {
        for(c=0; c<col;c++)
        {
            printf("\n m[%d][%d]=",r,c);
            //scanf("%d", &m[r][c]);  // array notation
            scanf("%d", (*(m+r)+c));  // pointer notation
        }
    }
    return;
}
void print_matrix(int m[][COL], int row, int col)
{
    int r ,c;
    for(r=0; r<row; r++)
    {
        for(c=0; c<col;c++)
        {
            //printf(" %d [%u] \t ",m[r][c], &m[r][c]);// array notation
            printf(" %d [%u] \t ",*(*(m+r)+c), (*(m+r)+c));// pointer notation
        }
        printf("\n");
    }
    return;
}

void matrix_addition(int m1[][COL], int m2[][COL], int res[][COL], int row, int col)
{
    int r,c;
    for(r=0; r<row; r++)
    {
        for(c=0; c<col ; c++)
        {
            //res[r][c]= m1[r][c]+m2[r][c];
            *(*(res+r)+c)= *(*(m1+r)+c)+ *(*(m2+r)+c);
        }
    }   
    return;
}
void matrix_sub(int m1[][COL], int m2[][COL], int res[][COL], int row, int col)
{
    int r,c;
    for(r=0; r<row; r++)
    {
        for(c=0; c<col ; c++)
        {
            //res[r][c]= m1[r][c]-m2[r][c];
            *(*(res+r)+c)= *(*(m1+r)+c)- *(*(m2+r)+c);
        }
    }   
    return;
}