#include<stdio.h>
int main(void)
{
    char i='A';   // variable   1 bytes
    char *pi=&i;  // pointer   pi= 4 bytes on 32 bit or 8 bytes on 64 bit 
    char **ppi=&pi; // pointer to pointer ppi= 4 bytes on 32 bit or 8 bytes on 64 bit 
    printf("\n sizeof i = %d ", sizeof(i));
    printf("\n sizeof pi = %d ", sizeof(pi));
    printf("\n sizeof ppi = %d ", sizeof(ppi));  
    printf("\n i=%c *(&i)=%c *pi=%c **ppi=%c", i, *(&i), *pi, **ppi);
    printf("\n i=%d *(&i)=%d *pi=%d **ppi=%d", i, *(&i), *pi, **ppi);
    printf("\n &i=%u pi=%u &pi=%u ppi=%u &ppi=%u", &i, pi, &pi, ppi, &ppi);
    *pi='B';
    printf("\n i=%d *(&i)=%d *pi=%d **ppi=%d", i, *(&i), *pi, **ppi);
    printf("\n i=%c *(&i)=%c *pi=%c **ppi=%c", i, *(&i), *pi, **ppi);
    printf("\n &i=%u pi=%u &pi=%u ppi=%u &ppi=%u", &i, pi, &pi, ppi, &ppi);
    
    **ppi='C';
    printf("\n i=%c *(&i)=%c *pi=%c **ppi=%c", i, *(&i), *pi, **ppi);
    printf("\n i=%d *(&i)=%d *pi=%d **ppi=%d", i, *(&i), *pi, **ppi);
    printf("\n &i=%u pi=%u &pi=%u ppi=%u &ppi=%u", &i, pi, &pi, ppi, &ppi);
    
    return 0;
}
// types of array
// 2 types of array
   // 1D Array
   // MD Array
         // 1. 2D Array  int arr[5]={1,2,3,4,5};
         // 2. 3D Array  int mat[2][2]= {1,2,3,4};
                       //  int mat[2][2]= {{1,2},{3,4}};
         // 3. 4D Array 



