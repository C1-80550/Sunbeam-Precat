#include <stdio.h>
#include <stdlib.h>
#define LEN 40
int MenuChoice();
int main(void)
{

	char src[LEN], dest[LEN], *ptr=NULL, find;
	int choice;
	unsigned int ans;
	signed int ans1;

	do
	{
		choice=MenuChoice();
		if(choice>=1 && choice<=2)
		{
			printf("\n Enter src :: ");
			getchar();  // or //scanf("%s", src);
			gets(src);

		}
		else if(choice>=3 && choice<=7)
		{
			printf("\n Enter src :: ");
			scanf("%s", src);
			printf("\n Enter dest :: ");
			scanf("%s",dest);
		}

		switch(choice)
		{
			case 1://strlen

				ans= strlen(src);
				printf("\n length of %s is %u", src, ans);
				break;

			case 2://search a char in string
					printf("\n Enter char to search :: ");
					scanf("%c", &find);
					ptr=strchr(src,find);
					if(ptr==NULL)
						printf("\n %c is not found in %s", find, src);
					else
						printf("\n %c is found in %s at %d location", find, src, ptr-src);
					break;
			case 3://string copy
					ptr= strcpy(dest, src);
					//strcpy(dest, src);
					printf("\n ptr=%s using pointer ", ptr);
					printf("\n dest=%s using dest ", dest);


					break;
			case 4://string concate
					ptr= strcat(dest, src);
					//strcat(dest, src);
					printf("\n ptr=%s using pointer ", ptr);
					printf("\n dest=%s using dest ", dest);

					break;
			case 5://string compare
					//ans= strcmp(src, dest);
					ans1= strcmp( dest, src);
					if(ans1==0)
						printf("\n %s  is equal to %s", dest, src);
					else if(ans1>0)
						printf("\n %s  is bigger than to %s", dest, src);
					else
						printf("\n %s  is smaller than to %s", dest, src);

					break;
			case 6://string compare by ingoring cases
					ans1= strcasecmp( dest, src);
					if(ans1==0)
						printf("\n %s  is equal to %s", dest, src);
					else if(ans1>0)
						printf("\n %s  is bigger than to %s", dest, src);
					else
						printf("\n %s  is smaller than to %s", dest, src);

					break;
			case 7://find sub string in string
					ptr= strstr(src,dest);
					if(ptr==NULL)
						printf("\n %s is not found in %s", dest, src);
					else
						printf("\n %s is found in %s at %d position", dest, src, ptr- src);
					break;

		}

		printf("\n enter 1 to continue or 0 to exit ");
		scanf("%d", &choice);

	}while(choice!=0);

	printf("\n src=%s dest =%s", src, dest);
	if (strcmp(src,dest)==0) // ( !strcmp(src,dest)) //0
		printf("\n equal");
	else
		printf("\n not equal");

	return EXIT_SUCCESS;
}
int MenuChoice()
{
	int choice;
	printf("\n 1. strlen \n 2. strchr \n 3. strcpy \n 4. strcat");
	printf("\n 5. strcmp \n 6. strcasecmp/strcmpi \n 7. strstr \n 0. Exit");

	printf("\n Enter Your choice :: ");
	scanf("%d", &choice);

	return choice;
}
