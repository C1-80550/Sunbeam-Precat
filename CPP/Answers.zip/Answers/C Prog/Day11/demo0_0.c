/* 
   pointer to pointers
   2D Array of int
   2D Array of char
   array of integer pointer
   array of char pointer or Array of pointers to string
   command line arguments    
*/
#include<stdio.h>
int main(void)
{
    int i=10;   // variable   4 bytes
    int *pi=&i;  // pointer   pi= 4 bytes on 32 bit or 8 bytes on 64 bit 
    int **ppi=&pi; // pointer to pointer ppi= 4 bytes on 32 bit or 8 bytes on 64 bit 
    printf("\n sizeof i = %d ", sizeof(i));
    printf("\n sizeof pi = %d ", sizeof(pi));
    printf("\n sizeof ppi = %d ", sizeof(ppi));  
    printf("\n i=%d *(&i)=%d *pi=%d **ppi=%d", i, *(&i), *pi, **ppi);
    printf("\n &i=%u pi=%u &pi=%u ppi=%u &ppi=%u", &i, pi, &pi, ppi, &ppi);
    *pi= 20;
    printf("\n i=%d *(&i)=%d *pi=%d **ppi=%d", i, *(&i), *pi, **ppi);
    printf("\n &i=%u pi=%u &pi=%u ppi=%u &ppi=%u", &i, pi, &pi, ppi, &ppi);
    
    **ppi=30;
    printf("\n i=%d *(&i)=%d *pi=%d **ppi=%d", i, *(&i), *pi, **ppi);
    printf("\n &i=%u pi=%u &pi=%u ppi=%u &ppi=%u", &i, pi, &pi, ppi, &ppi);
    
    return 0;
}




