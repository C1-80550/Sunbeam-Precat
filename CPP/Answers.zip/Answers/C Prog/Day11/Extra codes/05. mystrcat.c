 #include<stdio.h>
 #include<string.h>
 char *mystrcat(char*d, const char*s);
 int main(void)
 {
    char src[20],dest[20], *ptr=NULL;
     
    printf("\n Enter src::");
    scanf("%s",src);  //beam

    printf("\n Enter dest::");
    scanf("%s",dest); // sun


    /*ptr=strcat(dest, src);  // string.h   sunbeam

    printf("\n dest=%s", dest);
    printf("\n ptr=%s", ptr);*/
 
    ptr=mystrcat(dest, src);  // my fun    sunbeam

    printf("\n dest=%s", dest);
    printf("\n ptr=%s", ptr);


    return 0;
 }
char *mystrcat(char*d, const char*s)
{
   int i,j;
   for(i=0; *(d+i)!='\0'; i++) ; //go to end of dest
   for(j=0; *(s+j)!='\0' ; j++)
   {
      *(d+i+j)= *(s+j); // append src at end of dest
   }
   *(d+i+j)='\0';
   return d;
}
