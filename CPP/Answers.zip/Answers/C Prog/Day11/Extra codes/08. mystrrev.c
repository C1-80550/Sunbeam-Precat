 #include<stdio.h>
 #include<string.h>
 char *mystrrev(char*s);
 int main(void)
 {
    char src[20], *ptr=NULL;
     
    printf("\n Enter src::");
    scanf("%s",src);  //sunbeam
    printf("\n src=%s", src);

     //maebnus output after rev string


    
 
    ptr=mystrrev(src);  // mystrrev fun  

    printf("\n rev using src=%s", src);
    printf("\n rev using ptr=%s", ptr);


    return 0;
 }
char *mystrrev(char*s)
{
   int i, j, len;
   char temp;
   len=strlen(s);
   for(i=0, j=len-1;i<len/2; i++, j-- )
   {
       temp=*(s+i);
       *(s+i)=*(s+j);
       *(s+j)=temp;
   }
   return s;
}
