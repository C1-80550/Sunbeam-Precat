#include<stdio.h>
#include<string.h>
char *mystrupr(char*s);
char *mystrlwr(char*s);

 int main(void)
 {
    char src[20], *ptr=NULL;
     
    printf("\n Enter src::");
    scanf("%s",src);  //sunbeam
    printf("\n src=%s", src);

     //SUNBEAM output after converting upper case string
     //sunbeam output after converting lower case string


    
 
    ptr=mystrupr(src);  // mystrupr fun  

    printf("\n uppercase using src=%s", src);
    printf("\n uppercase using ptr=%s", ptr);

 ptr=mystrlwr(src);  // mystrupr fun  

    printf("\n lowercase using src=%s", src);
    printf("\n lowercase using ptr=%s", ptr);

    return 0;
 }
char *mystrupr(char*s)
{
   int index;
   for(index=0;*(s+index)!='\0'; index++ )
   {
      if(*(s+index)>=97 && *(s+index)<=122)
         *(s+index)-=32;
   }
   return s;
}
char *mystrlwr(char*s)
{
   int index;
   for(index=0;*(s+index)!='\0'; index++ )
   {
      if(*(s+index)>=65 && *(s+index)<=90)
         *(s+index)+=32;
   }
   return s;
}
