 #include<stdio.h>
 #include<string.h>
 int mystrcmp(const char *s1,const char *s2);
 int main(void)
 {
    char src[20],dest[20];
    int ans;
     
    printf("\n Enter src::");
    scanf("%s",src);  //s1

    printf("\n Enter dest::");
    scanf("%s",dest); // s2


    ans=mystrcmp( src, dest);  // mystrcmp function

    if(ans>0)
        printf("\n %s is bigger than %s", src, dest);
    else if(ans<0)
        printf("\n %s is smaller than %s", src, dest);
     else if(ans==0)
        printf("\n %s is equal to %s", src, dest);
        


    return 0;
 }

 int mystrcmp(const char *s1,const char *s2)
 {
     int index;
     for(index=0; *(s1+index)!='\0' || *(s2+index)!='\0'; index++)
     {
         if( *(s1+index)!= *(s2+index))
            return *(s1+index)- *(s2+index);
     }
     return 0;
 }
