/*
char name[10]="rahul";
//char name[10]={'r','a','h', 'u' ,'l','\0'};

#define LEN 10
char name[LEN]="rahul";
 //or
char name[LEN]={'r','a','h', 'u' ,'l','\0'};

*/
#include<stdio.h>
#define NO  5
#define LEN 10  
int main(void)
{
    // no*len*sizeof(char)
    char names[NO][LEN];  // 5*10*1=50 bytes
    int index;
    printf("\n Enter names :: \n");
    for(index=0; index<NO; index++)
    {
        printf("\n enter name of student [%d] ", index);
        gets(&names[index]);
    }
    printf("\n  names ares :: \n");
    for(index=0; index<NO; index++)
    {
        //puts(&names[index]);
        printf("\n %d ] %-10s [%u] %c", index, names[index], &names[index], names[index][0]);
    }

    return 0;
}