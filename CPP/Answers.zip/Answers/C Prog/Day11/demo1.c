#include<stdio.h>
#define ROW 3
#define COL 3
int main()
{
    //int arr[ 5 ];  int arr[ SIZE ];
    // int arr[]={1,2,3,4,5};
    //int mat1[2][2]={1,2,3,4};    // allowed
    //int mat2[ROW][COL]={{1,2},{3,4}}; // allowed
    //int mat3[][]={1,2,3,4};// not allowed
    //int mat4[][COL]={1,2,3,4} ;// allowed
      //int mat4[][COL]={ {1},{4}} ;// allowed
    //int mat5[ROW][]={1,2,3,4} ;// not allowed

    int mat[ROW][COL],r,c;

    printf("\n Enter elements of array :: \n");
    for(r=0; r<ROW; r++)
    {
        for(c=0; c<COL;c++)
        {
            printf("\n mat[%d][%d]=",r,c);
            //scanf("%d", &mat[r][c]);  // array notation
            scanf("%d", (*(mat+r)+c));  // pointer notation
        }
    }
    printf("\n elements of array ::\n ");
    for(r=0; r<ROW; r++)
    {
        for(c=0; c<COL;c++)
        {
            //printf(" %d [%u] \t ",mat[r][c], &mat[r][c]);// array notation
            printf(" %d [%u] \t ",*(*(mat+r)+c), (*(mat+r)+c));// pointer notation
        }
        printf("\n");
    }

    return 0;
}
// arr[index]= *(arr+index)
// mat[r][c] == *(*(mat+r)+c)
// m[i][j][k] == *(*(*(m+i)+j)+k)