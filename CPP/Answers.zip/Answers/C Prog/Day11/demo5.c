/*Array of pointers to string 
or
Array of char pointer 
*/

#include<stdio.h>
#include<stdlib.h>
#define NO 5
#define LEN 40
int main()
{
	char *arr[5], name[LEN]; /*Array of char pointer */
    int index;

    for(index=0; index<NO;index++)
    {
        printf("\n Enter name[%d] :: ", index);
        gets(name);
        arr[index]=(char*) malloc((strlen(name)+1)*sizeof(char));
        strcpy(arr[index], name);
    }
    printf("\n names of students \n");
    for(index=0; index<NO; index++)
    {
        printf("\n &name[%d] [%u]", index, &arr[index]);
        printf("name[%d]  [%u]", index, arr[index]);
        printf(" name[%d] %-10s", index, arr[index]);
        printf(" name[%d] %c", index, *arr[index]);

    }
   for(index=0; index<NO;index++)
    {
      free(arr[index]);
      arr[index]=NULL;
    }
    printf("\n memory is freed");
    return 0;
}