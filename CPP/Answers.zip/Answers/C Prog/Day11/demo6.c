#include<stdio.h>
int main(void)
{
               // 0  1   2  3  4
    int arr[5]={11,22,33,44,55};
    printf("%d %d %d", ++arr[1], ++arr[1], ++arr[1]);
                      //  24            23         22
                      //   25          24        23  
    /*arr++;
    ++arr;
    --arr;
    arr--;*/
      printf("\n%d %d %d", arr[1]++, arr[1]++, arr[1]++);
      //                   27            26       25 
    return 0;
}