
#include<stdio.h>
#define SIZE 5
//void AcceptArray(int a[], int size);
//void AcceptArray(int a[SIZE], int size);
void AcceptArray(int *a, int size);
void PrintArray(int a[], int size);
void ArrayReverse(int a[], int size);
int main(void)
{
    int arr[ SIZE ];  // int arr[ 5 ];
   

    printf("\n enter elements of array ::\n");
    AcceptArray(arr, SIZE);

    printf("\n elements of array ::\n");
    PrintArray(arr, SIZE);

    printf("\n  rev array \n");
    ArrayReverse(arr, SIZE);
    PrintArray(arr, SIZE);

    return 0;

}
void AcceptArray(int *a, int size)
{
    int index;
    
    for(index=0; index<size; index++)
    {
        printf("\n a[%d] = ", index);
        // array notation
        //scanf("%d", &a[index]);
       // scanf("%d", &index[a]);
        // pointer notation
        //scanf("%d", (a+index));
        scanf("%d", (index+a));       
    }
  
    return;
}
void PrintArray(int a[], int size)
{
    int index;
  
    for(index=0; index<size; ++index)
    {
        // array notation
        //printf("\n a[%d] %d [%u]", index, a[index], &a[index]);
       // printf("\n [%d]a %d [%u]", index, indSIZEex[a], &index[a]);
           // pointer notation
        //printf("\n *(a+%d) %d [%u]", index, *(a+index), (arr+index));
        printf("\n *(%d+a) %d [%u]", index, *(index+a), (index+a));
    
    }
    return;
}


//  rev array
void ArrayReverse(int a[], int size)
{
    int i, j, temp;
    for(i=0, j=size-1; i<size/2; i++, j--)
    {
       temp=a[i];
       a[i]=a[j];
       a[j]=temp;
    }
    return;
}


/*
 enter elements of array ::

 a[0] = 11

 a[1] = 22

 a[2] = 33

 a[3] = 44

 a[4] = 55

 elements of array ::

 *(0+a) 11 [17028288]
 *(1+a) 22 [17028292]
 *(2+a) 33 [17028296]
 *(3+a) 44 [17028300]
 *(4+a) 55 [17028304]
  rev array 

 *(0+a) 55 [17028288]
 *(1+a) 44 [17028292]
 *(2+a) 33 [17028296]
 *(3+a) 22 [17028300]
 *(4+a) 11 [17028304]
*/