#include<stdio.h>
int main(void)
{
    int no1=5, no2=0;
    //if(  0 , 5)   5  true
    if(no2, no1)
    {
        printf("\n yes");  // print
    }
    else;
        printf("\n no");  // print
    return 0;
}