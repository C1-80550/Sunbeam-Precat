#include<stdio.h>
int main(void)
{
    int age;
    start:
    printf("\n Enter age :: ");
    scanf("%d", &age);

    if(age>=18)
        printf("\n welcome u can vote");
    else
        goto start;
    return 0;
}// goto can be used in same function