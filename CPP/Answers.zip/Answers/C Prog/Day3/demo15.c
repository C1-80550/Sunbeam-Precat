#include<stdio.h>
int main()
{
    int no=100;
    printf("\n no=%d demimal", no);
    printf("\n no=%o octal", no);
    printf("\n no=%x hex", no);
    printf("\n no=%o", 0100);
    printf("\n no=%d", 0100);
    return 0;
} // no into words

//https://www.rapidtables.com/convert/number/octal-to-decimal.html