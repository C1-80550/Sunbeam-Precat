#include <stdio.h>
int main()
{
    int a = 3, b = 6;  // init at time decl
    // a=5;  assignement
                     //a=6
                    //a=b  
    printf("%d, %d", a = b, b);   // assigment  
                   // 6      6
                    
                    // 6==6   true 1
    printf("\n%d, ", a == b);   // comapare (equal to)
                  
	                  //6 != 6  false 0
    printf("\n %d, ", a != b);  // not equal to
        
                         // !6   !true  false 0
    printf("\n %d, ", a = !b); 
                     //a=0
     a=6, b=3;
    int c= a>b;   // true c=1
	printf("\n c=%d, ",c);  //1

     c= a<b;  // 6<3  false 0
    printf("\n c=%d, ",c); // 0

    return 0;
}

