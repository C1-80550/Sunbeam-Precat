// no is %ve or -ve or zero
/* 1. start
   2. accept no
   3. check no>0
        if yes 
             no is %ve
        if no check no==0
             if yes
                 print zero
              if no check no<0
                   if yes
                       print -ve
    4. stop
    no  5  +ve
        -2 -ve
        0  zero
*/

#include<stdio.h>
int main(void)
{
    int no;
    printf("\n Enter No :: ");
    scanf("%d", &no);
    if(no>0)
        printf("\n %d is +ve", no);
    else if(no==0)
        printf("\n %d is zero", no);
    else if(no<0)
        printf("\n %d is -ve", no);
    
    return 0;
}
