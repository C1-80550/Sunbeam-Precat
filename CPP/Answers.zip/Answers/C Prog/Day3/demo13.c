// conidtion operator ? :
/*
   conidtion ? true part : false part;
*/

#include<stdio.h>
int main(void)
{
    int no1;

    printf("\n enter no:: ");
    scanf("%d", &no1);
  //6%2==0  0==0  true
    no1%2==0 ? printf("\n %d is even", no1) :  printf("\n %d is odd", no1);
    //6%2== 0   flase
    // 5%2== 1  true
    no1%2 ? printf("\n %d is odd", no1) :  printf("\n %d is even", no1);
 
 // nested if
  // condition ? true part : condition ? true part : false part;
    no1>0 ? printf("\n %d is +ve", no1 ): no1==0 ? printf("\n %d is zero", no1): printf("\n %d is -ve", no1);
    
    return 0;
}