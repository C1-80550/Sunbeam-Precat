#include<stdio.h>
int main(void)
{
    int no1=50;
    
  // we can not give ; in if else and nested if
    // error: ‘else’ without a previous ‘if’
    if(no1);
         printf("\n yes");  
     else
            printf("\n 2yes");  
    no1=0;
    //error: ‘else’ without a previous ‘if’
    if(no1);
         printf("\n yes");  // print
    else if(no1);
        printf("\n yes");  // print
    return 0;
}