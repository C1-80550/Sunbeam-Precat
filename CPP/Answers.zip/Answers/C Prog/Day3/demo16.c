#include<stdio.h>
#include<limits.h>
#include<float.h>
int main(void)
{
    printf("Display Range of Data Types Using limits.h header file\n");
    printf("\n Data Type \t\t Size Format Specifier Lower Limit Upper Limit\n");
    printf("\n int \t\t\t %-10d %%d\t\t %-12d to %-12d\n",sizeof(int), INT_MIN, INT_MAX);
    printf("\n unsigned char \t\t %-10d %%c\t\t 0 to %-12d\n",sizeof(unsigned char), UCHAR_MAX);
    printf("\n signed char \t\t %-10d %%c\t\t %d to %-12d\n",sizeof(char),SCHAR_MIN, SCHAR_MAX);
    printf("\n short int\t\t %-10hd %%hd\t\t %d to %-12d\n",sizeof(short int),SHRT_MIN, SHRT_MAX);
    printf("\n unsigned short int\t %-10u %%u\t\t 0 to %-12u\n",sizeof(unsigned short int), USHRT_MAX);
       printf("\n\nDisplay Range of Data Types Using float.h header file\n");

    printf("\n float\t\t\t %-10d %%f\t\t %-12.6e to %-12.6e\n",sizeof(float), FLT_MIN, FLT_MAX);
    printf("\n double\t\t\t %-10d %%lf\t\t %-12.6e to %-12.6e\n",sizeof(double), DBL_MIN, DBL_MAX);

    return 0;
}