#include<stdio.h>
int main()
{
    char ch;

    printf("\n Enter ch=");
    scanf("%c", &ch);

    printf("\n ch=%d ch=%c", ch, ch);

    if(ch>=97 && ch<=122) // convert to capital from small letter
          ch-=32;   //ch=ch-32;
        
    printf("\n ch=%d ch=%c", ch, ch);
    
    return 0;
}
// +=  -=  /=  *=  %=  short hand operators