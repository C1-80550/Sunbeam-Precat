#include<stdio.h>
int main(void)
{
    int no1=50;
    
    if(no1)
         printf("\n 1yes");  // print
  // we can give ; in simple if
    if(no1);
         printf("\n 2yes");  // print

    no1=0;
    if(no1);
         printf("\n 3yes");  // print

    return 0;
}