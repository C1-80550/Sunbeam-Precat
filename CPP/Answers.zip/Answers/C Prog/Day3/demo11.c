#include<stdio.h>
int main(void)
{
    int no1=5, no2=0;
    //if(  5 , 0)   0  false
    if(no1, no2)
    {
        printf("\n yes");
    }
    else
        printf("\n no"); // print
    return 0;
}