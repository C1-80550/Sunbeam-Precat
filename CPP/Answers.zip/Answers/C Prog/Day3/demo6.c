// check no is evan or odd
/* 1. start
   2. accept no
   3. check no mod 2== 0
       if yes 
           print no is evan
       if no
          print no is odd
   4. stop
*/
#include<stdio.h>
int main(void)
{
    int no;

    printf("\n Enter no ::");
    scanf("%d", &no);

    if(no%2==0)
        printf("\n %d is even", no);
    else
        printf("\n %d is odd", no);
        
    return 0;
}
