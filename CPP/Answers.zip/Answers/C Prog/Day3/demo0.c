
// alogo flowchart
// jump statements
// if
// switch
// ternary oprator
// bit wise operators
// octal hex decimal
