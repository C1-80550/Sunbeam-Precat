#include <stdio.h>
#include <stdlib.h>
int main()
{
    int a = (1, 2, 3);  // a=3
  //          4    5    6
    //        3    4    5       
    int b = (++a, ++a, ++a);   // a=6, b=6

    printf("\n%d, %d", a, b);
    //return 0;
  //  exit(0);  // function stdlib.h
    //       6    7    8    
    //       6    7    8    9 
    int c = (b++, b++, b++);  // c=8  b=9
    printf("\n%d, %d, %d", a, b, c);
   //                      6  9  8include
    return 0;
}

