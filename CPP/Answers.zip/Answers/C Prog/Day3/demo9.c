// simple calculator
/* 1. strat
   2. accept no1, no2, and op
   3. ans=0
   4. check op=='+'
           if yes
              add no1 into no2 and store in ans
     check op=='-'
           if yes
              sub no2 from no1 and store in ans
     check op=='*'
           if yes
              multiply no1 by no2 and store in ans
     check op=='/'
           if yes
              divide no2 by no1 and store in ans
5.  print ans
6.  stop
no1  no2 op   ans
5     7   *    0 
              35

10   3   -    7
*/

#include<stdio.h>
int main(void)
{
    int no1, no2, ans;
    char op;

    printf("\n Enter no1=");
    scanf("%d",&no1);

    printf("\n Enter op=");
    scanf("%*c%c",&op);

    printf("\n Enter no2=");
    scanf("%d",&no2);

    ans=0;
    if(op=='+')   
        ans= no1+no2;
    if(op=='-')   
        ans= no1-no2;
    if(op=='*')   
        ans= no1*no2;
    if(op=='/')   
    { 
        if(no2==0) 
        {
          printf("\n can not divide by zero");
          return 0;
        }
        else
            ans= no1/no2;
    }
    printf("\n %d %c %d = %d", no1, op, no2, ans);
    return 0;
}