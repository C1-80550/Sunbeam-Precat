#include<stdio.h>
int main(void)
{
    int no;
    printf("\n Enter No :: ");
    scanf("%d", &no);
    if(no>0)
    {
        printf("\n %d is +ve", no);
        break;  // error
    }//error: break statement not within loop or switch
   // we can not use break in if statement only

    return 0;
}