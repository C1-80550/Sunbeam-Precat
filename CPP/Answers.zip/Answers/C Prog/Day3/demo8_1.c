#include<stdio.h>
int main()
{
    char ch;

    printf("\n Enter ch=");
    scanf("%c", &ch);

    printf("\n ch=%d ch=%c", ch, ch);

    if(ch>=97 && ch<=122) // convert to capital from small letter
          ch-=32;   //ch=ch-32;
        
    printf("\n ch=%d ch=%c", ch, ch);
    
     //if( ch=='A' || 'E' ||  'I' || 'O' || 'U')
     if( ch=='A' || ch=='E' ||  ch=='I' || ch=='O' || ch=='U')
         printf("\n %c is vov", ch);
    else if(ch>=65 && ch<=90)  // capital
         printf("\n %c is con", ch);
    else if(ch>=48 && ch<=57)  // digits
         printf("\n %c is digit", ch);
    else 
        printf("\n %c is other char", ch);
    
    return 0;
}
// +=  -=  /=  *=  %=  short hand operators