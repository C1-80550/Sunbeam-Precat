#include <stdio.h>
int main(void)
{
	int a = -10, b = 3, c = 0, d;
 // 1    True   
//  T     -10    not checked
	d = a++ || ++b && c++;
 //     ===     =========             -9  3  0  1
	printf("a=%d, b=%d, c=%d, d=%d, ", a, b, c, d);

	//return 0;

	a = -10, b = 3, c = 0;
     //          T
    //     F       
    //  F              T
	//  0 not check   -10
    d = c++ && ++b || a++;
//      ==========    ===               -9  3  1  1 
	printf("\na=%d, b=%d, c=%d, d=%d, ", a, b, c, d);

	return 0;
}

// jump statements
// break
// continue
//  return
// goto

// ?:  conditional operator

// control flow statements
// 1. if
// 2. switch
// 3. loops  ->  while , for and do while


