#include <stdio.h>
int main()
{
   // int a = 1, 2, 3,b,c; // error as variable name cant start with digits
    int a = (1, 2, 3),b,c; 
    //    4   5    6
    //    3   4    5     
    b = ++a, ++a, ++a;    // 6 4
    printf("\n%d, %d", a, b); 
    //  4     5   6
    //  4     5   6   7
    c = b++, b++, b++;  
                      //   6  7  4
    printf("\n%d, %d, %d", a, b, c);
    return 0;
}

