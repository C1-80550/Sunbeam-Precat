// if statements
/* 1.  simple if
   if(condition)
   {
      statement1;
      statement2;      
   }
   eg. if (per>=40)
            printf("pass");

  2. if else
     if(condition)
     {    
        statement1;
        statement2;      
      }
      else
      {    
        statement1;
        statement2;      
      }
      
   eg. if (per>=40)
          printf("pass");
      else
          printf("fail");
 
    3. nested if
       if(condition)
           statement1;      
       else if(condition)
         statement1;
       else if(condition)
         statement1;
       else if(condition)
         statement1;
        else
          statement1;

    eg. if (per>=70)
          printf("dist");
      elseif (per>=60)
          printf("1st");
    else if (per>=50)
          printf("2ed class");
     else if (per>=40)
          printf("pass");
    else
          printf("fail");
  

*/
