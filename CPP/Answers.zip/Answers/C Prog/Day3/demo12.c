// switch case
/*
    switch(expession)
    {
        default: statement; break;
        case 1: statements; break;
        case 2: statements; break;
        case 3: statements; break;
    }
    case should be unique (duplicate case not allowed)
    if we dont write break it will execute next case
    int ,char, enum can be pass to switch case
    float , double and string can not be pass to switch case
    case 1,2,3 : error

    case 1:
    case 2:
    case 3: statements;

    case 1+1:  expression are allowed with constants
    case a+b:  expression are  not allowed with variables

    default can be any where in switch
    if any case is not match default case will execute
*/// simple calculator
/* 1. strat
   2. accept no1, no2, and op
   3. ans=0
   4. check op=='+'
           if yes
              add no1 into no2 and store in ans
     check op=='-'
           if yes
              sub no2 from no1 and store in ans
     check op=='*'
           if yes
              multiply no1 by no2 and store in ans
     check op=='/'
           if yes
              divide no2 by no1 and store in ans
5.  print ans
6.  stop
no1  no2 op   ans
5     7   *    0 
              35

10   3   -    7
*/

#include<stdio.h>
#include<stdlib.h>
int main(void)
{
    int no1, no2, ans;
    char op;

    printf("\n Enter no1=");
    scanf("%d",&no1);

    printf("\n Enter op=");
    scanf("%*c%c",&op);

    printf("\n Enter no2=");
    scanf("%d",&no2);

    ans=0;
  /*  if(op=='+')   
        ans= no1+no2;
    else if(op=='-')   
        ans= no1-no2;
    else if(op=='*')   
        ans= no1*no2;
    else if(op=='/')   
    { 
        if(no2==0) 
        {
          printf("\n can not divide by zero");
          return 0;  // exit(0);
        }
        else
            ans= no1/no2;
    }
    else
    {
        printf("\n invalid oprator");
        exit(0); // return 0;
    }
    printf("\n %d %c %d = %d", no1, op, no2, ans);
    */
   printf("\n + = %d   - = %d", '+', '-');
   switch (op)
   {
       default : printf("\n invalid op"); return 0;
       //case '+':  ans= no1+no2; break;
       //case 43:  ans= no1+no2; break;

       case 10*4+3:  ans= no1+no2; break;
       //case '-':  ans= no1-no2; break;
       //case 45:  ans= no1-no2; break;
       case 9*5:  ans= no1-no2; break;
       case '*':  ans= no1*no2; break;
       case '/':  
                if(no2==0) 
                {
                    printf("\n can not divide by zero");
                    return 0;  // exit(0);
                }
                else
                    ans= no1/no2; break;
   }
    printf("\n ans=%d", ans);
    return 0;
}