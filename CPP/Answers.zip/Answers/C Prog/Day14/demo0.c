/*
Self-Referencial Structure
Array of structure 
uniom
bit field
file handling 
*/
#include<stdio.h>
/*
struct emp
{
    int empno;
    char name[10];
    float sal;
    struct emp *next;  // pointer of its own type
}; // uses --->  1. linked list  2. tree
*/
/*
struct emp
{
    int empno;
    char name[10];
    float sal;
    struct emp next; // error  
}; // error: field ‘next’ has incomplete type
*/
typedef  struct emp
{
    int empno;
    char name[10];
    float sal;
    //struct emp e[10];
    struct emp *next; // allowed
    //EMP *next; // error
    //EMP next; // error  
}EMP; 



int main(void)
{
    struct emp e1;
    
    
    return 0;
}