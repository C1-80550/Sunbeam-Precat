#include<stdio.h>
struct Demo
{
    signed num1:4;   //  -8  to 7
    unsigned int num2:3; //0  to 7
    signed num3:2; // -2  -1  0   1
};
int main(void)
{
    struct Demo d1;
    d1.num1=5;  //  -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7
                //                                    5     prints 5    
    d1.num2=6;  // 0 1 2 3 4 5 6 7
                //             6                            prints 6
    d1.num3=-1;     
                //  -2 -1 0 1
                //     -1                                   prints -1
    printf("%d %d %d",d1.num1,d1.num2,d1.num3);
                   //     5      6    -1
    printf("\n");
    d1.num1=10; //  -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7
                //   8  9  10               prints -6                                
    d1.num2=9;  // 0 1 2 3 4 5 6 7
                // 8 9                       prints 1           
    d1.num3=3;  // -2 -1 0 1
                //  2  3                     prints -1        
    printf("%d %d %d",d1.num1,d1.num2,d1.num3);
    return 0;        //-6       1      -1  
} //out put 5  6 -1  -6 1 -1
