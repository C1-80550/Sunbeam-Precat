// uinon
#include<stdio.h>
#pragma pack(1)
union result
{
    float per;
    char grade[4];
};
struct student
{
    int rollno;
    int std;
    char name[10];
    union result res;
};
int main(void)
{
    struct student s1;

    printf("\n Enter student info :: \n");
    printf("\n Enter RollNo :: ");
    scanf("%d", &s1.rollno);
    printf("\n Enter std :: ");
    scanf("%d", &s1.std);
    printf("\n Enter Name :: ");
    scanf("%s", s1.name);
    printf("\n Enter result :: ");
    if(s1.std>=1 && s1.std<=4)
    {
        printf("\n Enter grade [A++, A, B++, B, C, F]==");
        scanf("%s", &s1.res.grade);
    }
    else if(s1.std>=5 && s1.std<=10)
    {
        printf("\n Enter per =");
        scanf("%f", &s1.res.per);
    }
    
    printf("\n Student info :: \n");
    printf("\n Rollno=%d", s1.rollno);
    printf("\n Std=%d", s1.std);
    printf("\n Name=%s", s1.name); 
    s1.std>=1 && s1.std<=4 ? printf("\n grade= %s", s1.res.grade): printf("\n Per=%.2f", s1.res.per);
    
    printf("\n size of s1=%d", sizeof(s1));
    return 0;
}