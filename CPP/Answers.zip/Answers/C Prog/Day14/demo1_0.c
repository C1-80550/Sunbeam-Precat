// array of emp structure
#include<stdio.h>
#pragma pack(1)
#define SIZE 3
struct emp 
{
    int empno;
    char name[10];
    float sal;
};
int main(void)
{
    struct emp e[SIZE]; // struct emp e1,e2, e3;
    int index;

    printf("\n Enter Emp infomation :: ");
    for(index=0; index<SIZE; index++)
    {
        printf("\n Enter emp infomation[%d] :: ", index);
        printf("\n Enter emp no=");
        scanf("%d",  &e[index].empno);
        printf("\n Enter emp name=");
        scanf("%s",  &e[index].name);
        printf("\n Enter emp sal=");
        scanf("%f",  &e[index].sal);        
    }
    printf("\n Emp info :: \n");
    printf("\n EmpNo   Name   Sal \n");
    for(index=0; index<SIZE; index++)
    {
        printf("\n%-8d%-10s%6.2f", e[index].empno, e[index].name, e[index].sal);
    }

    return 0;
}