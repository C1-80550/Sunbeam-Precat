/*
seq file handling
text files
    1. char by char  fgetc fputc
    2. string by string (array of char) fgets fputs
    3. record by record structure  fprintf and fscanf
binary files
    1  char by char/ string by string/ record by record
       fread and fwrite ( void pointer)

 random file access
      fseek
*/