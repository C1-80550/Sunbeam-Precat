// array of emp structure
#include<stdio.h>
#pragma pack(1)
#define SIZE 3
struct emp 
{
    int empno;
    char name[10];
    float sal;
};
//void accept_emp_info(struct emp e1[SIZE], int size);
void accept_emp_info(struct emp e1[], int size);
void display_emp_info(struct emp e1[], int size);
int main(void)
{
    struct emp e[SIZE]; // struct emp e1,e2, e3;

    printf("\n Enter Emp infomation :: ");
    accept_emp_info(e, SIZE);
    printf("\n Emp info :: \n");
    display_emp_info(e, SIZE);

    return 0;
}

void accept_emp_info(struct emp e1[], int size)
{
    int index;
    for(index=0; index<size; index++)
    {
        printf("\n Enter emp infomation[%d] :: ", index);
        printf("\n Enter emp no=");
        scanf("%d",  &e1[index].empno);
        printf("\n Enter emp name=");
        scanf("%s",  &e1[index].name);
        printf("\n Enter emp sal=");
        scanf("%f",  &e1[index].sal);        
    }
    return;
}
void display_emp_info(struct emp e1[], int size)
{
    int index;
    printf("\n EmpNo   Name   Sal \n");
    for(index=0; index<size; index++)
    {
        printf("\n%-8d%-10s%6.2f", e1[index].empno, e1[index].name, e1[index].sal);
    }
    return;
}
