#include<stdio.h>
#pragma pack(1)
struct date1
{
    int dd; // 1 to 31
    int mm; // 1 to 12
    int yy; // 100 to 2047
};
struct date2
{
    short int dd; // 1 to 31
    short int mm; // 1 to 12
    short int yy; // 100 to 2047
};
struct date3
{
    unsigned dd:5; // 0 to 31
    unsigned mm:4; // 0 to 15
    unsigned yy:11; // 0 to 2047
};  // 20 bits== 3 bytes
struct date4
{
    signed dd:6; // -32 to 31
    signed mm:5; // -16 to 15
    signed yy:12; // -2048 to 2047
}; // 23 bits == 3 bytes


int main(void)
{
    printf("\n size of date1=%d", sizeof(struct date1));//12 byets
    printf("\n size of date2=%d", sizeof(struct date2));//6 byets
    printf("\n size of date3=%d", sizeof(struct date3));//3 byets (20 bits)
    printf("\n size of date4=%d", sizeof(struct date4));//3 byets (23 bits)
    struct date3 d3;

    struct date4 d4;
    int no;
/*

    printf("\n Enter day for d3.dd=");
   // scanf("%d", &d3.dd);  // error we can not scan bit field
    scanf("%d", &no);
    d3.dd=no;

    printf("\n d3.dd=%d", d3.dd);
*/
    {
         printf("\n Enter day for d3.dd=");
       // scanf("%d", &d4.dd);  // error we can not scan bit field
        scanf("%d", &no);
        d4.dd=no;

        printf("\n d4.dd=%d", d4.dd);

    }
    return 0;
}   