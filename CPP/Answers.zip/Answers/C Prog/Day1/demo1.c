#include<stdio.h>
int main(void)
{
    printf("\n welcome to sunbeam\n");
    return 0;
} // gcc demo1.c --->>> a.exe (windows)
 // gcc demo1.c --->>> a.out (linux/ mac)
 // gcc filename.c---> a.exe/ a.out 

 // to run -->./a.out  (linux)
 // to run --> .\a.exe (windows)

