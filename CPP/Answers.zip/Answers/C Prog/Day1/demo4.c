#include<stdio.h>
#include<limits.h>
int main(void)
{
    printf("\n int %%d  %d    %d to %d", sizeof(int), INT_MIN, INT_MAX);
    printf("\n signed char %%c  %d    %d to %d", sizeof(char), SCHAR_MIN	, SCHAR_MAX	);
    
    return 0;
}

// int          %d
// char         %c
// float        %f   6 decimal   (%.3f  3 deicmal)
// unsigned int %u