#include<stdio.h>
int main(void)
{
    int no1;
    printf("\n Enter No1:: ");
    scanf("%d", &no1);

    printf("\n no1=%d  [%u]", no1, &no1);
    return 0;
}