#include<stdio.h>
int main(void)
{
    char ch='A';
    printf("\n sizeof(11)=%d", sizeof(11));  // 4 bytes
    printf("\n sizeof(11L)=%d", sizeof(11));  // 4 bytes
    printf("\n sizeof(11l)=%d", sizeof(11));  // 4 bytes

    printf("\n sizeof(11.2)=%d", sizeof(11.2));  // 8 Bytes

    printf("\n sizeof(11.2f)=%d", sizeof(11.2f));  // 4 Bytes
    printf("\n sizeof(11.2F)=%d", sizeof(11.2F));  // 4 Bytes
    printf("\nsizeof(char)=%d", sizeof(char)); // 1 bytes
    printf("\nsizeof('A')=%d", sizeof('A')); // 4 bytes
                      // sizeif(65)==4
    // sizeof is a operator which gives number  of bytes requried




    return 0;
}
/*
11 int constant
3.142f  float constant
'A'  char constant
"SUNBEAM" string constant
++a , --a
a+b
?:

= assgnemnt   a=b;
== equal to  a==b
!= not equal to   a!=b
logical and &&
logical or  ||

sizeof
*/