#include<stdio.h>
int main(void)
{
    char  ch;
    printf("\n Enter ch:: ");
    scanf("%c", &ch);

    printf("\n ch=%c ch=%d  [%u]", ch,ch, &ch);
    return 0;
}  // A = 65  Z =90  a= 97  b= 122  0 = 48   9 = 57