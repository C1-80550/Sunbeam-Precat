#include<stdio.h>
int main(void)
{
    float  f1;
    printf("\n Enter f1:: ");
    scanf("%f", &f1);

    printf("\n f1=%f  [%u]", f1,&f1);
    printf("\n f1=%.2f  [%u]", f1,&f1);
    printf("\n f1=%.3f  [%u]", f1,&f1);
    return 0;
} 