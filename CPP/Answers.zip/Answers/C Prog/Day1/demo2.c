#include<stdio.h>
int main(void)
{
    printf("\n welcome \n Sunbeam");;;;;;
    printf("\n welcome \t Sunbeam");
    printf("\n SunBeam1\b2");
    printf("\n SunBeam12\b\b3");
    //printf(" "sunbeam" "); // error
    printf("\n \"sunbeam\" "); 
    printf("\n \'sunbeam\' \n\n"); 
    return 0;
} // escaspe seq
// \n new line
// \t tab
// \b  back space