#include<stdio.h>
int fact(int n);
int main(void)
{
    int no, ans;
    printf("\n Enter No ::");
    scanf("%d", &no);

    ans= fact(no);
    printf("\n %d! =%d", no, ans);

    return 0;
}
int fact(int n)
{
    int f=1;
    if(n==1)  // term condition
    {
        printf("\n n=%d f=1", n);
        return 1;
    }
    else
    {
        f= n * fact(n-1);  // rec formula
        printf("\n n=%d f=%d", n, f);
    }
    return f;   
}

