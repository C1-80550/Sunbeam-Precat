#include<stdio.h>
// 1. fun decl
int factorial(int n);  // call by value
int IsStrongNo(int n);
void StrongNoInRange(int lowerLim, int upperLim);
// 2, function defination  (n is formal argument)
int main(void)  // defination of  main
{
    int lower, upper;
    
    printf("\n Enter lower limit :: ");
    scanf("%d", &lower);

    printf("\n Enter upper limit :: ");
    scanf("%d", &upper);

    printf("\n string no between %d to %d \n", lower, upper);
    StrongNoInRange(lower, upper);
    
  
    
    return 0;
}
void StrongNoInRange(int lowerLim, int upperLim)
{
    int no;
    for(no= lowerLim ; no<=upperLim; no++)
    {
        if(no== IsStrongNo(no))
            printf("%5d", no);
    }
    return ;
}
int factorial(int n)
{
    int counter, fact;
    for( counter=fact=1;counter <= n; counter++)
    {
        fact*= counter;  // fact= fact*counter;
    }
    
    return fact;
}
int IsStrongNo(int n)
{
    int rem, sum;
    for(rem=sum=0; n!=0; n/=10)
    {
        rem= n%10;
        sum+= factorial(rem);
    }
    return sum;
}