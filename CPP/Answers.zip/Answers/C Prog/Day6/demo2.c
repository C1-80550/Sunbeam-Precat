#include<stdio.h>
void table(int n); // void not retuening anything
int table_no(int n, int c);
int main(void)
{
    int no, index;
    printf("\n Enter No = ");
    scanf("%d", &no);
    printf("\n table of %d printed in main function \n");
    for(index=1; index<=10; index++)
        printf("\n %d * %d = %d ", no, index, table_no(no, index));
    
    table(no);
    return 0;
}
int table_no(int n, int c) // ok
{
    return n*c;
}
void table(int n)  // better
{  
    int counter;
    printf("\n table of %d printed in table function \n", n);
    for(counter=1; counter<=10; ++counter)
    {
        printf("\n %5d*%5d=%5d", n, counter, n*counter);
    }
    return;
}

// os---> main()--- table()   2
// os--->  main()--> table(5,1)--> table(5.2)