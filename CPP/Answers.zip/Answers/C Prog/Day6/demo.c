 // function factorial
 // function table
 // strong
 // 1 to 500 strong no
 // rec sum, factorial power
 // storage class
 //