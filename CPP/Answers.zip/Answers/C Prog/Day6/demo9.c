#include<stdio.h>
int main(void)
{
    int no1=100;  // local variable (stack)
    //static int no=no1; // error   // static variable (data segment)
   
    static int no=5;    // static variable (data segment)

    static int no2;   // default value 0
    no2; // 0
    no2= no1;  // 100   assigment is allowed
    no1=110;
    no2=no1;  // 110   assigment is allowed

    return 0;
}