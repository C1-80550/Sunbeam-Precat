/* factorial of no
   5!= 5*4!
         4= 4*3!
              3= 3*2!
                   2=2*1!

    n!=  n* (n-1)   (rec formula)
    till n==1   (term condition)                 
*/

/*  sum of 1st n numbers
    5= 5+4
         4+3
           3+2
             2+1
     sum=  n+ (n-1)    (rec formula)    
     till n==1      treminating condition

*/

/*  2^5
      == 2* 2^4
            2* 2^3
               2*2^2
                 2*2^1
                   2*2^0

    power=  base * (base,index-1)
    till index==0                   
*/
#include<stdio.h>
int sum(int n);
int main(void)
{
    int no, ans;
    printf("\n Enter No ::");
    scanf("%d", &no);

    ans= sum(no);
    printf("\n sum of %d =%d", no, ans);

    return 0;
}
int sum(int n)
{
    int add;
    if(n==1)  // term condition
    {
        printf("\n n=%d add=1", n);
        return 1;
    }
    else
    {
        add= n+ sum(n-1);  // rec formula
        printf("\n n=%d add=%d", n, add);
    }
    return add;   
}


