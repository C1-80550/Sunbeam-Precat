#include<stdio.h>
//register int no;
int main(void)
{
    register int no;
    printf("\n Enter No =");
    //scanf("%d", &no);
    //error: address of register variable ‘no’ requested
    printf("\n no=%d", no)  ;

    register int no1=5;
    
    return 0;
}