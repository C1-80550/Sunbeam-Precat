#include<stdio.h>
int no=10;  // global variable
int main()
{
    int no=100;  // local variable
    printf("\n local variable no=%d [%u]", no, &no); // no=100
    return 0;
}