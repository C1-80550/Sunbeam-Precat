#include<stdio.h>
int no=10;  // defination of global variable
int main()
{
    printf("\n global variable no=%d [%u]", no, &no);
    return 0;
}
extern int no; // decl of global variable
