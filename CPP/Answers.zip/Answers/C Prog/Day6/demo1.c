#include<stdio.h>
// 1. fun decl
int factorial(int n);
// 2, function defination  (n is formal argument)
int main(void)  // defination of  main
{
    int no, ans;
    //int factorial(int n);

    printf("\n Enter No :: ");
    scanf("%d", &no);
    
    ans=0;
    ans=factorial(no); //3. function call
    // no is actual arg
    printf("\b \n %d!=%d", no, ans) ;
  
    return 0;
}
int factorial(int n)
{
    int counter, fact;
    for( counter=fact=1;counter <= n; counter++)
    {
        printf("%5d *", counter);
        fact*= counter;  // fact= fact*counter;
    }
    return fact;
}
// LAMP
// MEAN
// MERN