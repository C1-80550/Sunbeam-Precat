#include<stdio.h>
int main()
{
    int main=100; 
    printf("\n main=%d", main); // main=100
    return 0;
}