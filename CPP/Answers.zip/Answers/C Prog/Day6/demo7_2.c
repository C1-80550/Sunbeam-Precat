#include<stdio.h>
extern int no; // decl of global variable
int main()
{
    printf("\n global variable no=%d [%u]", no, &no);
    return 0;
}
int no=10;  // defination of global variable