#include<stdio.h>
int main=100; // error 
int main()
{
    
    return 0;
}