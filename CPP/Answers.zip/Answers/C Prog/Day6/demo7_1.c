#include<stdio.h>
extern int no; // decl of global variable
int main()
{
    // decl and defination is same for local variable
    int no=100;  // local variable
    printf("\n local variable no=%d [%u]", no, &no); // no=100
    {  // block 1
        int no=50;
        printf("\n local variable in block 1 no=%d [%u]", no, &no); // no=50
        {  // block 2
            int no=25;
            printf("\n local variable in block 2 no=%d [%u]", no, &no); // no=25
        }
    }
    return 0;
}
int no=10;  // defination of global variable