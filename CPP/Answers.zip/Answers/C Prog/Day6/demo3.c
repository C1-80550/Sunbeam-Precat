// sum of the facatorial of digits equal to orignal mo
// 145 == 1! +4! +5! 
//     ==  1+24+120 ==145
// string no beteen 1 to 500
//  1    2      145 
#include<stdio.h>
// 1. fun decl
int factorial(int n);
int IsStrongNo(int n);
// 2, function defination  (n is formal argument)
int main(void)  // defination of  main
{
    int no, ans;
    
    printf("\n Enter No :: ");
    scanf("%d", &no);
    
    ans=0;
    ans=IsStrongNo(no);
    if(ans==no)
        printf("\n %d is strong no", no) ;
    else
        printf("\n %d is not a strong no", no) ;
  
    return 0;
}
int factorial(int n)
{
    int counter, fact;
    for( counter=fact=1;counter <= n; counter++)
    {
        fact*= counter;  // fact= fact*counter;
    }
    return fact;
}
int IsStrongNo(int n)
{
    int rem, sum;
    for(rem=sum=0; n!=0; n/=10)
    {
        rem= n%10;
        sum+= factorial(rem);
    }
    return sum;
}