#include<stdio.h>
int main(void)
{
    char ch;
    FILE *fp=NULL;
    fp=fopen("/home/sunbeam/PM16/Day15/abc.txt","r");
    if(fp==NULL)
        printf("\n File is not present");
    else
    {
        fseek(fp, -10L, SEEK_END);
        ch= fgetc(fp);
        printf("\n ch=%c",ch );
        fseek(fp, -1L, SEEK_CUR);
        fseek(fp, -3L, SEEK_CUR);
        ch= fgetc(fp);
        printf("\n ch=%c",ch );
       // fseek(fp, -1L, SEEK_CUR);
        fseek(fp,4, SEEK_CUR);
          ch= fgetc(fp);
        printf("\n ch=%c",ch );
        
        fclose(fp);
    }
    return 0;
}