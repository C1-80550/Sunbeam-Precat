#include<stdio.h>
int main()
{
    int n1=2, n2=4;
    int sum(int no1, int no2);
    int (*funptr)(int num1, int num2);
    /* funptr is pointer to function which recives
    2 parameters & return integer */
    //
    funptr=sum;
    printf("\n%d uisng sum", sum(n1,n2));
    printf("\n%d old way", (*funptr)(n1,n2));
    printf("\n%d new way", funptr(n1,n2));
return 0;
}
int sum(int no1, int no2)
{
return no1+no2;
}