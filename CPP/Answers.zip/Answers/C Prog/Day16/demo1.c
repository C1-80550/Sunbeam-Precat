// write emp info (structure) into binary file using fwrite
#include<stdio.h>
#pragma pack(1)
struct emp
{
    int empno;
    char name[10];
    float sal;
};
void accept_emp_info(struct emp * e);
int main(void)
{
    FILE *fpEmpWrite=NULL;
    struct emp e1;
    //fpEmpWrite= fopen("emp.dat","wb");
    if ((fpEmpWrite=fopen("emp.dat","ab"))==NULL)
        printf("\n unable to append in to file");
    else
    {
        printf("\n Enter Employee infomation :: ");
        accept_emp_info(&e1);
        fwrite(&e1, sizeof(struct emp),1, fpEmpWrite);
        printf("\n record added into file");
        fclose(fpEmpWrite); //fcloseall();
        //fclose(fp1, fp2);  //error
    }
    return 0;
}
void accept_emp_info(struct emp * e)
{

    printf("\n Enter empno :: ");
    scanf("%d", &e->empno);
    printf("\n Enter Name :: ");
    scanf("%s", e->name);
    do
    {
        printf("\n Enter Sal :: ");
        scanf("%f", &e->sal);
    }while(e->sal<=0);

}

/*
text      binary
w          wb
r          rb
a          ab
w+         wb+ 
r+         rb+
a+         ab+
*/