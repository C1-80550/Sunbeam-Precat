#include<stdio.h>
int main(void)
{
    char ch;
    FILE *fp=NULL;
    fp=fopen("/home/sunbeam/PM16/Day15/abc.txt","r");
    if(fp==NULL)
        printf("\n File is not present");
    else
    {
        //fseek(fp,-1l,2); /* Postion to the last chararter */
        fseek(fp,-1l,SEEK_END); // E
        do
        {
            ch=fgetc(fp);
            //if(ch=='\n')  // in windows uncomment line 17 and 18
              //  fseek(fp, -1L, SEEK_CUR);
            printf("%c", ch);
        }while(!fseek(fp,-2L,SEEK_CUR));
        //while(!fseek(fp,-2L,1));
    }
    return 0;
}