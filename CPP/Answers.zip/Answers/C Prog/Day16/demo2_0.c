// read emp info (structure) from binary file using fread
#include<stdio.h>
#pragma pack(1)
struct emp
{
    int empno;
    char name[10];
    float sal;
};
void display_emp_info(const struct emp * e);
int main(void)
{
    FILE *fpEmpRead=NULL;
    struct emp e1;
    if ((fpEmpRead=fopen("emp.dat","rb"))==NULL)
        printf("\n unable to read in to file");
    else
    {
        // read 1st record for emp.dat

        fread(&e1, sizeof(struct emp),1, fpEmpRead);
        printf("\n 1 record record into file");
        display_emp_info(&e1);
        fclose(fpEmpRead); //fcloseall();
        //fclose(fp1, fp2);  //error
    }
    return 0;
}
void display_emp_info(const struct emp * e)
{
    printf("\n EmpNo  Name  sal  ");
    printf("\n %-8d%-10s%-6.2f ", e->empno, e->name, e->sal);
    return;
}
