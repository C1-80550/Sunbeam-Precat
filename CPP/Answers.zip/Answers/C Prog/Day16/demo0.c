/*
read write in binary file
fseek
function pointer
sorting
searching
file copy using command line argruments
*/

/*
to scan single line from console for string
char name[40];
gets(name);

imput india is our country
output india is our country

scanf("%[^\n]s",city);
imput india is our country
output india is our country

*/