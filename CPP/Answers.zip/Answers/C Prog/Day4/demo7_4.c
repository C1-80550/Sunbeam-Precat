#include<stdio.h>
// decl of enum
// way1
typedef enum months
{ 
    // 0    1    2   3    4
     Exit, Jan, Feb, Mar, Apr,    
}MONTHS;


int main(void)
{
    // enum is internally int constant
    // enum month is user defined data type
    // mon is varible of user defined data type enum months
    MONTHS mon;//enum months mon;
    int no;
    int  year;
    // int is data type and year is variable of int data type

    printf("\n size of mon=%d", sizeof(mon)); // 4
    printf("\n size of enum months=%d", sizeof(enum months));
    printf("Enter Month ::");
    scanf("%d", &no); // way3 scan int assign using switch casew

    switch(no) 
    {
        default: mon=-1; break;
        case 1: mon=Jan; break;
        case 2: mon=Feb; break;
        case 3: mon=Mar; break;
        case 4: mon=Apr; break;
        case 0: mon=Exit; break;
    }
 

    switch (mon)
    {
        default : printf("\n invalid month"); return 0;
        case Jan: printf("\n Jan has 31 days"); break;
        case Feb:
                {
                    printf("\n Enter Year ::");
                    scanf("%d", &year);
                    if(year%4==0)
                        printf("\n Feb has 29 days [ due to leap year] \n");
                    else 
                        printf("\n Feb has 28 days [ due to not a leap year] \n");

                }
                break;
        case Mar:  printf("\n March has 31 days");break;
        case Apr:  printf("\n April has 30 days");break;
        case Exit: return 0;
    }
 
    return 0;
}