#include<stdio.h>
int main(void)
{
    int no, counter;
    printf("\n Enter No = ");
    scanf("%d", &no);
    // print 1 to no
    
    for(counter=1; counter<=no;) ;  // infinite loop
    { 
        printf("%5d", counter);
    }
    printf("\n end");
    return 0;
}