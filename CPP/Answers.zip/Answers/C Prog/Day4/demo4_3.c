#include<stdio.h>
int main(void)
{
    int no, counter;

    printf("\n Enter No = ");
    scanf("%d", &no);
    counter=0;
    while(counter<no); // infinite loop
    {
        counter++; //counter=counter+1;
        printf("%5d", counter);
    }
    printf("end");
    
    return 0; 
}
