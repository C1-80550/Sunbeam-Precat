#include<stdio.h>
int main(void)
{
    int no, counter;

    printf("\n Enter No = ");
    scanf("%d", &no);
    counter=no;
    while(counter>0)
    {
        printf("%5d", counter);
        --counter; //counter=counter-1;
    }
    return 0; 
}