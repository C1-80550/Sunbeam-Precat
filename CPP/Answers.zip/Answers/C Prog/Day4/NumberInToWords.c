#include<stdio.h>
int main()
{
    int no, tenth, unit;
    printf("\n enter no ::");
    scanf("%d", &no);  // enter 23
   
    tenth=no/10;  //  23/10== 2
    unit=no%10;   // 23%10 == 3

    switch(tenth)  // switch(2)
    {   
        case 1: printf(" ten "); break;
        case 2: printf(" twenty "); break;   // prints twenty
        case 3: printf(" thirty "); break;
    }   
       
    switch(unit)  // switch(3)
    {   
        case 1: printf(" one "); break;
        case 2: printf(" two "); break;
        case 3: printf(" three "); break;  // prints three
    }   
    return 0;
}  // output =  twenty three  when input 23