#include<stdio.h>
int main(void)
{
    int month, year;

    printf("Enter Month ::");
    scanf("%d", &month);

    if(month==1)
        printf("\n Jan has 31 days");
    else if(month==2)
    {
        printf("\n Enter Year ::");
        scanf("%d", &year);
        if(year%4==0)
            printf("\n Feb has 29 days [ due to leap year] \n");
        else 
            printf("\n Feb has 28 days [ due to not a leap year] \n");

    }
    else if(month==3)
        printf("\n March has 31 days");
    else if(month==4)
        printf("\n April has 30 days");
    else 
         printf("\n invalid months") ;
        
    return 0;
}
