// unsigned int checked with if
// if swicth with months
// loops - while , for, do while
// enum
// typedef

