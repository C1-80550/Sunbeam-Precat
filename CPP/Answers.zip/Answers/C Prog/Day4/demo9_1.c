#include<stdio.h>
int main(void)
{
    int no;

    for(no=65; no<=122; no++)
    {
        if(no>=91 && no<=96)
            break; // go out of loop
        printf("\n %d - %c", no, no);
    } // print upto 90
    return 0;
}