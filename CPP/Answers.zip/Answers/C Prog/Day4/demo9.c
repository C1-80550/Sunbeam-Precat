#include<stdio.h>
int main(void)
{
    int no;

    for(no=65; no<=122; no++)
    {
        printf("\n %d - %c", no, no);
    }
    return 0;
}