#include<stdio.h>
int main(void)
{
    int no, counter;
    printf("\n Enter No = ");
    scanf("%d", &no);
    // print 1 to no
    
    for(counter=1; counter<=no; counter++);
    {  // print last value of counter
        printf("%5d", counter);
    }
    return 0;
}