 /*
 // 2. for

     //  1     2            5
    for(init;condition;incre/decrement) 
    {
        statement1;
        statement2;//3    
    }//4
    // 6

    1 2 if condition true then 3 4 5
      2 if condition true then 3 4 5
      2 if condition true then 3 4 5
      2 if condition false then 6

      for() // error
      {}
      for(;;) // work
      {
          condition
            break;
      }
   */ 
#include<stdio.h>
int main(void)
{
    int no, counter;
    printf("\n Enter No = ");
    scanf("%d", &no);
    // print 1 to no
    for(counter=1; counter<=no; counter++)
    {
        printf("%5d", counter);
    }
    return 0;
}
