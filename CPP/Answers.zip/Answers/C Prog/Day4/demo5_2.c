#include<stdio.h>
int main(void)
{
    int no, counter;
    printf("\n Enter No = ");
    scanf("%d", &no);
    // print 1 to no
    counter=1;
    for(;;)
    {
        printf("%5d", counter);
        if(counter>=no)
            break; // go out of loop
        counter++;
    }
    printf("\n");
    return 0;
}
