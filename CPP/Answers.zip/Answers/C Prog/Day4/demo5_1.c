#include<stdio.h>
int main(void)
{
    int no, counter;
    printf("\n Enter No = ");
    scanf("%d", &no);
    // print no to 1
    for(counter=no; counter>=1; counter--)
    {
        printf("%5d", counter);
    }
    return 0;
}
