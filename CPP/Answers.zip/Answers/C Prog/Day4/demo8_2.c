#include<stdio.h>
typedef enum menuchoice
{ //  0    1        2      3       4
    Exit, Additon, Minus,Multiplty,Divide
}MENUCHOICE;
int main(void)
{
    int no1, no2, ans;
    MENUCHOICE choice;//enum menuchoice choice;
    do
    {
        printf("\n Enter No1 = ");
        scanf("%d", &no1);
        printf("\n Enter No2 = ");
        scanf("%d", &no2);
        printf("\n 1. Addition \n 2. Minus \n 3. Multiplty \n 4. Divide \n 0. Exit ::");
        printf("\n Enter choice = ");
        scanf("%d", &choice);

        ans=0;
        switch(choice) 
        {
            default: printf("\n invalid choice:: ");
            case Additon: ans= no1+no2; break;
            case Minus: ans= no1-no2; break;
            case Multiplty: ans= no1*no2; break;
            case Divide: ans= no1/no2; break;
        } // end of switch case
        printf("\n ans=%d", ans);
        
        printf("\n enter 1 to continue or 0 to exit  = ");
        scanf("%d", &choice);

    }while(choice!=0);
    return 0;
}

