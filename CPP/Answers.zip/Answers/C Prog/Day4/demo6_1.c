/*
    init; //1
    do
    {//2
        statement1;
        statement2;//3
        incre/decrement; //4
    } while(condition); //5
    //6


    1 2  3 4 5 if condition true then
      2  3 4 5  if condition true then
      2  3 4 5 if condition false then
      6

do while loop is used from menu driven prog
do while loop will execute atleast once
*/
// simple calculator using menu driven prog

#include<stdio.h>
int main(void)
{
    int no1, no2, ans , choice;

    do
    {
        printf("\n Enter No1 = ");
        scanf("%d", &no1);
        printf("\n Enter No2 = ");
        scanf("%d", &no2);
        printf("\n 1. Addition \n 2. Minus \n 3. Multiplty \n 4. Divide \n 0. Exit ::");
        printf("\n Enter choice = ");
        scanf("%d", &choice);

        ans=0;
        switch(choice) 
        {
            default: printf("\n invalid choice:: ");
            case 1: ans= no1+no2; break;
            case 2: ans= no1-no2; break;
            case 3: ans= no1*no2; break;
            case 4: ans= no1/no2; break;
        } // end of switch case
        printf("\n ans=%d", ans);
        
        printf("\n enter 1 to continue or 0 to exit  = ");
        scanf("%d", &choice);

    }while(choice!=0);
    return 0;
}

