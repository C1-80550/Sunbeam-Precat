#include<stdio.h>
// decl of enum
enum months
{ 
    // 0    1    2   3    4
     Exit, Jan, Feb, Mar, Apr,
    //Exit=0, Jan=1, Feb=2, Mar=3, Apr=4
};

int main(void)
{
    // enum is internally int constant
    // enum month is user defined data type
    // mon is varible of user defined data type enum months
    enum months mon;
    int  year;
    // int is data type and year is variable of int data type

    printf("\n size of mon=%d", sizeof(mon)); // 4
    printf("\n size of enum months=%d", sizeof(enum months));
    printf("Enter Month ::");
    scanf("%d", &mon); // way1 scan enum variable

    switch (mon)
    {
        default : printf("\n invalid month"); return 0;
        case Jan: printf("\n Jan has 31 days"); break;
        case Feb:
                {
                    printf("\n Enter Year ::");
                    scanf("%d", &year);
                    if(year%4==0)
                        printf("\n Feb has 29 days [ due to leap year] \n");
                    else 
                        printf("\n Feb has 28 days [ due to not a leap year] \n");

                }
                break;
        case Mar:  printf("\n March has 31 days");break;
        case Apr:  printf("\n April has 30 days");break;
        case Exit: return 0;
    }

    return 0;
}