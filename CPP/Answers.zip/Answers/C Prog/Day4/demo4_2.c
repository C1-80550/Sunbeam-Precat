#include<stdio.h>
int main(void)
{
    int no, counter;

    printf("\n Enter No = ");
    scanf("%d", &no);
    counter=0;
    while(1) // while(counter<no)
    {
        counter++; //counter=counter+1;
        printf("%5d", counter);
        if(counter>=no)
            break;  // go out of loop
    }
    printf("\n");
    return 0; 
}