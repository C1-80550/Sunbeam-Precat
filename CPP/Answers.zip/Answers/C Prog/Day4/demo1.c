#include<stdio.h>
int main(void)
{
    unsigned int no=10;
    printf("\n -2= %u", -2);
    if(no>-2)
        printf("\n yes");
    else
        printf("\n no");
    {
        signed int no=10;
        printf("\n -2= %d", -2);
        if(no>-2)
            printf("\n yes");
        else
            printf("\n no");
    }
    
    
    return 0;
}