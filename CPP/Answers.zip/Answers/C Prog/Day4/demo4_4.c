#include<stdio.h>
int main(void)
{
    int no, counter;

    printf("\n Enter No = ");
    scanf("%d", &no);
    counter=0;
    while(++counter<no); // print last value of counter
    {
        printf("%5d", counter);
        counter++; //counter=counter+1;
    }
    printf("end");
    
    return 0; 
}