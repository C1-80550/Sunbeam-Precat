#include<stdio.h>
int main(void)
{
    int no;

    for(no=65; no<=122; no++)
    {
        if(no>=91 && no<=96)
            continue; // go to next itrations
        printf("\n %d - %c", no, no);
    } // print upto 65 to 90  then 97 to 122
    return 0;
}