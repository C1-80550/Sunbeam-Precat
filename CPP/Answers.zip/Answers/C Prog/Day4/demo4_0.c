/* loops
1. while 

    init; //1
    while(condition) //2
    {
        statement1;
        statement2;//3
        incre/decrement; //4
    }//5
    // 6

    1 2 if condition true then 3 4 5
      2 if condition true then 3 4 5
      2 if condition true then 3 4 5
      2 if condition false then 6

    print 1st n numbers
    5   --->   1 2 3 4 5
    100 ----> 1 2  3   100


    1. start
    2. accept no
    3. assign counter = 0
    4. check counter<no
        if yes
           increment counter by 1
           print counter
        goto step 4
    5. stop

    no counter    1    2   3  4  5
    5    0+1=1
         1+1=2
         2+1=3
         3+1=4
         4+1=5

    while (1) true
    {
        infinite loop
    }

    while(0)  false  dont go inside loop
    {

    }

    while(conidition);  // genrally infinite loop
    {
        statements;
        incre/decre
    }
     while()  // error
     {

     }
*/
#include<stdio.h>
int main(void)
{
    int no, counter;

    printf("\n Enter No = ");
    scanf("%d", &no);
    counter=0;
    while(counter<no)
    {
        counter++; //counter=counter+1;
        printf("%5d", counter);
    }

    
    return 0; 
}