#include<stdio.h>
int main(void)
{
    if (sizeof(2)>-1)
        printf("yes");
    else
        printf("no");
    return 0;
}
