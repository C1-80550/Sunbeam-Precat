#include<stdio.h>
#define SIZE 5
int main(void)
{
    printf("%d ] hellow ", SIZE);  // prints hellow
    return 0;
}

// w  write - delete old data and new data into file
// a  append -add at end
// a+ append amd read

// r read contents of file
// r+ read write into file
// w+ delete old data and write and read data