/*
struct emp 
{
    int empno;
    char name[10];
    float sal;
};

 can we compare 2 sturucture varibale of same data type?
   struct emp e1;
   struct emp e2; 
  ans no
  reason  structure is user define data type so compiler dont know
  data members of structure so cant compare then
    if( e1>e2 ) // error
    if( e1==e2 ) // error
    if( e1!=e2 ) // error
    if( e1<e2 ) // error


 if you have to compare struture variable u have to compare members of the structures

   if( e1.empno>e2.empno) // allowed
   if( e1.sal<e2.sal)     // allowed
   if( strcmp(e1.name, e2.name)==0) // allowed
   if( e1.sal== e2.sal ) // allowed
   if( e1.sal!= e2.sal ) // allowed



   can we compare 2 sturucture varibale of different data types?
   struct emp e1;
   struct student s1;

   anwser = no

   if(s1==e1) // error
   if(s1>e1) //  error
   if(s1!=e1) // error 
  ans no
  https://stackoverflow.com/questions/4358728/end-of-file-eof-in-c
*/
