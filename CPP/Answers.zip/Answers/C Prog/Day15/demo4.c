//1 read no of char (string) from text file using fgets and
// print on console
#include<stdio.h>
#define SIZE 10
int main(void)
{
    FILE *fpRead=NULL;
    char arr[SIZE];     // file_path, file_mode
                 // curr Dir
    fpRead= fopen("file2.txt", "r"); // read mode
      
    if(fpRead==NULL)
        printf("\n unable to read file");
    else
    {
        printf("\n  data read from file ::\n ");
         while( fgets(arr, SIZE, fpRead)!=NULL)
         {                          
             fputs(arr,stdout); // print on consode
             getchar(); // wait to press key from keybpard
         }
         fclose(fpRead);  // fcloseall();
         printf("\n data read from file");
    }
    return 0;

}
// eof ctrl+z   linux ctr+d