//1 write no of char (string) into text file using fputs
#include<stdio.h>
#define SIZE 40
int main(void)
{
    FILE *fpWrite=NULL;
    char arr[SIZE];     // file_path, file_mode
                 // curr Dir
    fpWrite= fopen("file2.txt", "a"); // append mode
      //fpWrite= fopen("file2.txt", "w"); // write mode
    if(fpWrite==NULL)
        printf("\n unable to create file");
    else
    {
        printf("\n enter data to store into file :: ");
         while( fgets(arr, SIZE, stdin)!=NULL)
         {                          
             fputs(arr,fpWrite);
         }
         fclose(fpWrite);  // fcloseall();
         printf("\n data added into file");
    }
    return 0;

}
// eof ctrl+z   linux ctr+d