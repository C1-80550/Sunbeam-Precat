//6. read student info(structure) from text file using fscanf
#include<stdio.h>
struct student
{
    int rollno;
    char name[10];
    float per;
};
void display_stud_input(const struct student *s);
int main()
{
    struct student s;
    int cnt=0;
    //FILE *fpStudWrite=fopen("d:\\PM16\\Day15\\stud.txt","r") ; // for winodow
    FILE *fpStudRead=fopen("/home/sunbeam/PM16/Day15/stud.txt","r") ; // linux
    if(fpStudRead==NULL)
        printf("\n unbale to open file for reading");
    else
    {
        // read all records  from file
        cnt=0;
        fprintf(stdout,"\n rollno  name per");
        while(fscanf(fpStudRead,"%d\t%s\t%f\n", &s.rollno, s.name, &s.per)!=EOF)
        {
            cnt++;
            display_stud_input(&s);
        }
        
        fclose(fpStudRead);
        printf("\n%d records read from file", cnt);
    }
    
}
void display_stud_input(const struct student *s)
{
    //printf("\n rollno  name per \n");
    //printf("%-8d%-10s%-6.2f", s->rollno, s->name, s->per);
   
    fprintf(stdout,"\n%-8d%-10s%-6.2f", s->rollno, s->name, s->per);
    return;
    
}