// count no of words from file
#include<stdio.h>
#define LEN 40
int main(void)
{
    FILE *fpRead=NULL;
    char word[LEN];
    int cnt;
     
    fpRead= fopen("file1.txt", "r"); // read mode
    if(fpRead==NULL)
        printf("\n unable to read file");
    else
    {

        printf("\n  data from store into file :: ");
         while( fscanf(fpRead,"%s", word)!=EOF)  //read data from file
         {
            cnt++;    
             printf("\n %d] %s", cnt, word);
             

         }
         fclose(fpRead);  // fcloseall();
         printf("\n no of words = %d", cnt);
    }
    return 0;

}

/*
Meeting ID: 540 342 2999
Passcode: sunbeam
*/
