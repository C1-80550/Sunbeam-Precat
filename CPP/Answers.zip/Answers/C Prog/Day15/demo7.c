//1 read data char by char from text file using fgetc and 
// display on conolse
#include<stdio.h>
int main(void)
{
    FILE *fpRead=NULL;
    char ch;
    int cnt, lines, tabs, spaces, digits, alphabets;
     
    fpRead= fopen("file1.txt", "r"); // read mode
    if(fpRead==NULL)
        printf("\n unable to read file");
    else
    {
         cnt= lines= tabs= spaces= digits= alphabets=0;
        printf("\n  data from store into file :: ");
         while( (ch= fgetc(fpRead))!=EOF)  //read data from file
         {
             cnt++;
             if(ch=='\n')
                lines++;
             if(ch=='\t')
                tabs++;
             if(ch==' ')
                spaces++;
            if(ch>=48 &&  ch<=57)
                digits++;
            if((ch>=65 &&  ch<=90) || (ch>=97 &&  ch<=122))
                alphabets++;
            
             
                
             fputc(ch,stdout); // print on screen
            // getchar(); // wait accept key from keyboard
         }
         fclose(fpRead);  // fcloseall();
         printf("\n no of char = %d", cnt);
         printf("\n no of lines = %d", lines);
         printf("\n no of tabs = %d", tabs);
         printf("\n no of spaces = %d", spaces);
         printf("\n no of digits = %d", digits);
         printf("\n no of alphabets = %d", alphabets);
    }
    return 0;

}
// eof ctrl+z   linux ctr+d