//5. write student sturucture into text file using fprintf
#include<stdio.h>
struct student
{
    int rollno;
    char name[10];
    float per;
};
void accept_stud_input(struct student *s);
int main()
{
    struct student s;
    //FILE *fpStudWrite=fopen("d:\\PM16\\Day15\\stud.txt","a") ; // for winodow
    FILE *fpStudWrite=fopen("/home/sunbeam/PM16/Day15/stud.txt","a") ; // linux
    if(fpStudWrite==NULL)
        printf("\n unbale to open file for writing");
    else
    {
        printf("\n Enter student infomation ::");
        accept_stud_input(&s);
        fprintf(fpStudWrite,"%d\t%s\t%f\n", s.rollno, s.name, s.per);
        printf("\n student added to file");
        fclose(fpStudWrite);
    }
    
}
void accept_stud_input(struct student *s)
{
    //fscanf(filepointer,"%d", &s->rollno);
    //fprintf(filepointer,"%d", s->rollno);

    fprintf(stdout,"\n enter rollno ::");
    fscanf(stdin,"%d", &s->rollno);
    fprintf(stdout,"\n enter name ::");
    fscanf(stdin,"%s", s->name);
    fprintf(stdout,"\n enter per ::");
    fscanf(stdin,"%f", &s->per);
    return;
    
}