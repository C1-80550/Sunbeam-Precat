//1 read data char by char from text file using fgetc and 
// display on conolse
#include<stdio.h>
int main(void)
{
    FILE *fpRead=NULL;
    int cnt;
    char ch;  // file_path, file_mode
    fpRead= fopen("file1.txt", "r"); // read mode
    if(fpRead==NULL)
        printf("\n unable to read file");
    else
    {
        cnt=0;
        printf("\n enter data to store into file :: ");
         while( (ch= fgetc(fpRead))!=EOF)  //read data from file
         {
             cnt++;
             fputc(ch,stdout); // print on screen
             getchar(); // wait accept key from keyboard
         }
         fclose(fpRead);  // fcloseall();
         printf("\n %d data read from file", cnt);
    }
    return 0;

}
// eof ctrl+z   linux ctr+d