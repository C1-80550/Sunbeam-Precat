//1 write char by char data into text file using fputc
#include<stdio.h>
int main(void)
{
    FILE *fpWrite=NULL;
    char ch;     // file_path, file_mode
                 // curr Dir
    fpWrite= fopen("file1.txt", "a"); // append mode
      //fpWrite= fopen("file1.txt", "w"); // write mode
    if(fpWrite==NULL)
        printf("\n unable to create file");
    else
    {
        printf("\n enter data to store into file :: ");
         while( (ch= fgetc(stdin))!=EOF)
         {                          //-1
             fputc(ch,fpWrite);
         }
         fclose(fpWrite);  // fcloseall();
         printf("\n data added into file");
    }
    return 0;

}
// eof ctrl+z   linux ctr+d