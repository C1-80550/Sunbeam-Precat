//6. read student info(structure) from text file using fscanf
#include<stdio.h>
struct student
{
    int rollno;
    char name[10];
    float per;
};
void display_stud_input(const struct student *s);
int main()
{
    struct student s;
    //FILE *fpStudWrite=fopen("d:\\PM16\\Day15\\stud.txt","r") ; // for winodow
    FILE *fpStudRead=fopen("/home/sunbeam/PM16/Day15/stud.txt","r") ; // linux
    if(fpStudRead==NULL)
        printf("\n unbale to open file for reading");
    else
    {
        // this print 1 record of file
        fscanf(fpStudRead,"%d\t%s\t%f\n", &s.rollno, s.name, &s.per);
        display_stud_input(&s);
        printf("\n student read from file");
        fclose(fpStudRead);
    }
    
}
void display_stud_input(const struct student *s)
{
    //printf("\n rollno  name per \n");
    //printf("%-8d%-10s%-6.2f", s->rollno, s->name, s->per);
    fprintf(stdout,"\n rollno  name per \n");
    fprintf(stdout,"%-8d%-10s%-6.2f", s->rollno, s->name, s->per);
    return;
    
}