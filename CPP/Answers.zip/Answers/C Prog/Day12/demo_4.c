#include <stdio.h>
#define INCREMENT(x) --x
#define DECREMENT(x) ++x
int main()
{
    char *ptr = "SunbeamKarad";
    int x = 10;
    printf("%s",DECREMENT(ptr));  // unbeamKarad
    printf("%3d\n",DECREMENT(x)); // 11
    printf("%s",INCREMENT(ptr));  // SunbeamKarad
    printf("%3d", INCREMENT(x));  // 10
    return 0;
}
