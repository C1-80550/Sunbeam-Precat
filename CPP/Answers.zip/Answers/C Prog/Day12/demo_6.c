#include <stdio.h>
int main(void)
{
	printf("\n%d", __LINE__);  // prints current line no 4
	printf("\n%d", __LINE__+5);  // prints current line no 4  5+5 ==10

	#line 1  // next line no will be 1
	// #line 0 allowed with warning
	//#line -5 // error
	printf("\n%d", __LINE__);  // print 1
	printf("\n file name =%s", __FILE__);  // prints demo_6.c
	printf("\n time =%s", __TIME__);       // prints current time
	printf("\n Date =%s", __DATE__);       // prints current date  
	
	
	
	return 0;
}
