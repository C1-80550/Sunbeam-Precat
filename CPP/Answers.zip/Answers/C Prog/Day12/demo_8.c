#include<stdio.h>
#define a 10
int main()
{
    #ifndef a
        #define a 15
    #else
        #undef a
        #define a 20
    #endif
    printf("a : %d",a);
    
    return 0;
} // output = 20
