#include<stdio.h>
#include<stdlib.h>
int main(int argc, char *argv[])
{
    int no1, no2, ans;
    no1= atoi(argv[1]);
    no2= atoi(argv[2]);
    ans=no1+no2;
    printf("\n %d + %d =%d", no1, no2, ans);

    return 0;
}
// atoi  function converts string to integer
// if fails to converts it rentuns zero
// if we enters on command line ./a.out 12 15
                              //  0      1  2
                              // no1=12  no2=15  ans=27

// if we enters on command line ./a.out xyz abc  
                              //  0      1  2
                              // no1=0  no2=0  ans=0
