	/*The conditional compilation directives are
 #if, 
 #else, 
 #elif, 
 #ifdef, 
 #ifndef, 
 #endif, 
 #undef.
 */
#include <stdio.h>
int main()
{
	#ifdef __cplusplus
		/*C++ specific code*/
	#else
	   /*C code*/
		#ifdef __STDC__
   	 		/*standard C code*/
    	#else
			/*non-standard C code*/
		#endif
	#endif
	return 0;
}
