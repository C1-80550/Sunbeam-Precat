#include <stdio.h>
#define area(x) (x * x)
#define area1(x) (x) * (x)

int main(void)

{
	printf("\n ans=%d ",area(6 + 3)); // 6+3*6+3  6+18+3==27
	printf("\n ans1=%d ",area((6 + 3))); // (6+3)*(6+3)== 9*9=81
	printf("\n ans1=%d ",area1(6 + 3)); // (6+3)*(6+3)== 9*9=81
	return 0;
}
