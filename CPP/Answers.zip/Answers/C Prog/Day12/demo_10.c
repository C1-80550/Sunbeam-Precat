#include<stdio.h>
#define print(arg) printf(#arg)
int main(void)
{
    print(sunbeam);  // printf("sumbeam");
    return 0;
}