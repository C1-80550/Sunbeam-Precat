// simple calculator using command line argruments
//    0      1   2    3   
// ./a.out  12   +   15
// progname no1  op  no2
#include<stdio.h>
#include<stdlib.h>
int main(int argc, char* argv[], char *envp[])
{
    int no1, no2 , ans;
    char op;

    if(argc!=4)
    {
        printf("\n invalid argruments");
        printf("ProgName No1  Operator No2");
        //          0      1   2         3
    }
    else
    {
        no1= atoi(argv[1]);
        op= argv[2][0];  // array
        //or
        //op=*argv[2];  // pointer
        no2= atoi(argv[3]);
        switch(op) 
        {
            case '+': ans= no1+no2; break;
            case '-': ans= no1-no2; break;
            case '*': ans= no1*no2; break;
            case '/': ans= no1/no2; break;
        }
        printf("\n %d %c %d =%d", no1,op, no2, ans);

    }
    return 0;
}