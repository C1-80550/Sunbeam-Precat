// twisters on array , pointer and strings
// command line arguments
// preprocessor directives
// structure
// accept input for command line and print it

#include<stdio.h>
int main(int argc, char *argv[])
{
    int index;
    printf("\n Number of arguemnts=%d", argc);
    for(index=0; index<argc; index++)
    {
        printf("\n %d] %s", index, argv[index]);
    }

  

    return 0;
}
// what will be output if  ./a.out DAC DMC DBDA DESD
//                            0     1   2   3    4