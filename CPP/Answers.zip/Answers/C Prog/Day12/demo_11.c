#include<stdio.h>
#define print1(a,b) printf("\n%d", a##b)
#define print2(a,b) printf("\n%d", b##a)

int main(void)
{
    int basicsalary=5000;
    int salarybasic=10000;
    print1(basic, salary); // basicsalary=5000
    print2(basic, salary); //salarybasic=10000
    print2( salary, basic); // basicsalary=5000
    print1(salary, basic); //
    return 0;
}