#include <stdio.h>
#define greater(a, b) (a > b)? a : b
int main(void)
{
	int x = 0, y = -2;
                      
	if(greater(x, y))  // if(0 >-2 ? 0 : -2) if(0) if(false)
		printf("sun");
	else
		printf("beam");  // print beam

	return 0;

}

