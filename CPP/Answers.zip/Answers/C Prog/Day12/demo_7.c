#include <stdio.h>
#define PRINT(i, limit) while (i < limit) \
                            { \
                                printf("\n Sunbeam @"); \
                                printf("Hinjawadi phase");\
                                printf(" %d ", ++i); \
                                i++; \
                            } 
int main()
{
    int i = 1;
    PRINT(i, 3);
    return 0;   
} // demo for multiline macro
