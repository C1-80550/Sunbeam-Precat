#include<stdio.h>
int main(int argc, char *argv[])
{
    int index;
    printf("\n Number of arguemnts=%d", argc);
      for(index=argc-1; index>=0; index--)
    {
        printf("\n %d] %s", index, argv[index]);
    }


    return 0;
}
// what will be output if  ./a.out DAC DMC DBDA DESD
//                            0     1   2   3    4