#include<stdio.h>
#include<string.h>
int main(void)
{
	char str1[] ="Sunbeam";  // local variables stack
	char str2[]= "Sunbeam";

        // strcmp returns 0 if both strings are same

	printf("\n src=%s dest =%s", str1, str2);
   // if both string are same strcmp return 0
   // if(0==0)  if ( true ) 
	if (strcmp(str1,str2)==0)
		printf(" \t both are equal \n");   // prints both are equal
	else
		printf(" \t both are not equal \n");

	printf("\n src=%s dest =%s", str1, str2);
	if (strcmp(str1,str2)) // if(0)  if(false)
		printf(" \t both are equal \n");
	else
		printf(" \t both are not equal \n");  // print both are not equal


	printf("\n src=%s dest =%s", str1, str2);
	if (!strcmp(str1,str2)) // if (!0)  if(1) if(true)
		printf(" \t both are equal \n");  // prints both are equal
	else
		printf(" \t both are not equal \n");

	return 0;
}
