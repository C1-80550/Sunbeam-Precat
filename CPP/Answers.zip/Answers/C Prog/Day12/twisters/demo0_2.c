#include<stdio.h>
#include<string.h>
int main(void)
{
		char name[]="sunbeam";
		char *p1=name;
  	    int no1=15;
		char *str1 ="Sunbeam";
		char *str2= "Karad";
		char *str3= NULL;

    	str3=strcat(str1, str2); // error exit value -1

    	printf("%s %s",str3);

	return 0;
} // run time error we cant modify data from ro section read only
