#include<stdio.h>
#include<string.h>
int main(void)
{  // local variables are created on stack
	char str1[] ="Sunbeam";  
	char str2[]= "Karad";
	char str3[30];
                                 //   dest    src
                                 //Sunbeam  Karad  
 	printf("\n%s",strcpy(str3,strcat(str1, &str2)));
	    //               dest         src=SunbeamKarad
    // strcat function appends src string  at end of dest string
	            // so out put SunbeamKarad
	// strcpy function copy src string on dest string
 	
	 strcpy(str1,"sunbeam");
	 //           0123456 
 	strcpy(str2, "karad");
	 //           01345
                         // beam     rad   
    printf("\n%s",strcat(&str1[3],&str2[2]));
	                  //  dest       src
    // strcat function appends src string  at end of dest string
	            // so out put beamrad
	return 0;
}

