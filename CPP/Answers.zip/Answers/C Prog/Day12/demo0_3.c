#include<stdio.h>
int main(int argc, char *argv[])
{
    printf("%c", **++argv);
    return 0;
} // a.out friday saturday sunday monday
//    0      1      2       3     4 

// argv[1][0]   *(*(argv+1)+0)