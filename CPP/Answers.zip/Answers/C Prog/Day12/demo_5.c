#include<stdio.h>
#include<string.h>
int main( void )
{
    #define SUNBEAM "SUNBEAM IT PARK \n"
    #define Sunbeam "SUNBEAM MARKETYARD\n"
    
    #ifdef SUNBEAM
        printf(SUNBEAM);   // printf("SUNBEAM IT PARK \n");
                           // prints  SUNBEAM IT PARK
    #endif
    #ifdef SUNBEAM         
        printf(Sunbeam);   // printf("SUNBEAM MARKETYARD\n")
                           // printf "SUNBEAM MARKETYARD\n"
    #endif
    printf("\'Sunbeam\'\n");  // prints 'Sunbeam'
    printf("\"SUNBEAM\" \n"); // prints "SUNBEAM"
    // macros dont find and replace in '' and ""
    return 0;
}
