#include<stdio.h>
int main(int argc, char *argv[])
{
    printf("%s", *++argv);
    return 0;
} // a.out friday saturday sunday monday
//    0      1      2       3     4 
