/*
struture
pass structure to function using pointer
return structure variable from function
nested stucture
typedef
array of emp structure
allocate memory for structure dyanamically
union 
*/

#include<stdio.h>
int main(void)
{
    int empno;
    char name[10];
    float sal;

    printf("\n Enter Emp No=");
    scanf("%d", &empno);
    printf("\n Enter Emp Name=");
    scanf("%s", name);
    printf("\n Enter Emp sal=");
    scanf("%f", &sal);

    printf("\n EmpNo  Name  Sal \n");
    printf("%-8d%-10s%-6.2f", empno, name, sal);
    
    return 0;
}
