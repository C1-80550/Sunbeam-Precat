// sol no 2  using return statement
#include<stdio.h>
#pragma pack(1)
struct emp
{
    int empno;
    char name[10];
    float sal;
};  
struct emp accept_emp_info(void);
void display_emp_info(struct emp e);
int main(void)
{
    struct emp e1;
  
    printf("\n Enter employee infomation = \n");
    e1=accept_emp_info();  

    printf("\n emp info  from main  \n");
    display_emp_info(e1);  // this will display correct answer
    
    return 0;
    
}
struct emp accept_emp_info()
{
    struct emp e;
    printf("\n Enter Emp No=");
    scanf("%d", &e.empno);
    printf("\n Enter Emp Name=");
    scanf("%s", e.name);
    printf("\n Enter Emp sal=");
    scanf("%f", &e.sal);
    return e;
}
void display_emp_info(struct emp e)
{
    printf("\n EmpNo  Name  Sal using structure variable e \n");
    printf("%-8d%-10s%-6.2f", e.empno, e.name, e.sal);
    return;   
}