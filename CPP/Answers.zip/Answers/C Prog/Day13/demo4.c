// call by value -- will give wrong output
#include<stdio.h>
#pragma pack(1)
struct emp
{
    int empno;
    char name[10];
    float sal;
};  
void accept_emp_info(struct emp e);
void display_emp_info(struct emp e);
int main(void)
{
    struct emp e1;
  
    printf("\n Enter employee infomation = \n");
    accept_emp_info(e1);  // e1 actul argrument

    printf("\n emp info  from main  \n");
    display_emp_info(e1);  // this will display wrong answer
    
    return 0;
    
} // e is formal argrument
void accept_emp_info(struct emp e)
{
    printf("\n Enter Emp No=");
    scanf("%d", &e.empno);
    printf("\n Enter Emp Name=");
    scanf("%s", e.name);
    printf("\n Enter Emp sal=");
    scanf("%f", &e.sal);
    //printf("\n display from accept ");
    //display_emp_info(e);
    return ;
}
void display_emp_info(struct emp e)
{
    printf("\n EmpNo  Name  Sal using structure variable e \n");
    printf("%-8d%-10s%-6.2f", e.empno, e.name, e.sal);
    return;   
}