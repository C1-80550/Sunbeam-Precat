// sol no1 using pointers /call by address// call by ref -- will give correct output
#include<stdio.h>
#pragma pack(1)
struct emp
{
    int empno;
    char name[10];
    float sal;
};  
void accept_emp_info(struct emp *e);// e is pointer 4 or 8
void display_emp_info(const struct emp *e); // e is pointer 4 or 8
int main(void)
{
    struct emp e1;
  
    printf("\n Enter employee infomation = \n");
    accept_emp_info(&e1); // e1 is actual argument

    printf("\n emp info  from main  \n");
    display_emp_info(&e1);  // this will display wrong answer
    
    return 0;
    
} // e is formal argument of pointer type
void accept_emp_info(struct emp *e)
{
    printf("\n Enter Emp No=");
    scanf("%d", &e->empno);
    printf("\n Enter Emp Name=");
    scanf("%s", e->name);
    printf("\n Enter Emp sal=");
    scanf("%f", &e->sal);    
    return ;
}
void display_emp_info(const struct emp *e)
{
    //e->sal=-10000; can not modify e as it is constant
    printf("\n EmpNo  Name  Sal using structure variable e \n");
    printf("%-8d%-10s%-6.2f", e->empno, e->name, e->sal);
    return;   
}