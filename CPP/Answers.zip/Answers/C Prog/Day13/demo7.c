// sol no 3 using global variables
#include<stdio.h>
#pragma pack(1)
struct emp
{
    int empno;
    char name[10];
    float sal;
};  
struct emp e;
void accept_emp_info(void);
void display_emp_info(void);
int main(void)
{
    
  
    printf("\n Enter employee infomation = \n");
    accept_emp_info(); 

    printf("\n emp info  from main  \n");
    display_emp_info();  // this will correcr output
    
    return 0;
    
} // e is formal argrument
void accept_emp_info(void)
{
    printf("\n Enter Emp No=");
    scanf("%d", &e.empno);
    printf("\n Enter Emp Name=");
    scanf("%s", e.name);
    printf("\n Enter Emp sal=");
    scanf("%f", &e.sal);
    
    return ;
}
void display_emp_info(void)
{
    printf("\n EmpNo  Name  Sal using structure variable e \n");
    printf("%-8d%-10s%-6.2f", e.empno, e.name, e.sal);
    return;   
}