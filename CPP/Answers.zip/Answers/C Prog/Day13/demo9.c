#include<stdio.h>
#include<stdlib.h>
#pragma pack(1)
struct emp
{
    int empno;
    char name[10];
    float sal;
};  
int main(void)
{
    struct emp *ptr=NULL;
//  ptr= (struct emp*)malloc(1*sizeof(struct emp));
     ptr= (struct emp*)calloc(1,sizeof(struct emp));

    if(ptr==NULL)
        printf("\n unable to allocate memory");
    {
        printf("\n enter emp info::\n");
        printf("\n enter emp no::");
        scanf("%d", &ptr->empno);
        printf("\n enter emp name::");
        scanf("%s", ptr->name);
        printf("\n enter emp sal::");
        scanf("%f", &ptr->sal);

        printf("\n emp infomation \n");
        printf("\n empno name sal ");
        printf("\n%-5d%-10s%-6.2f", ptr->empno, ptr->name, ptr->sal );

        free(ptr);
        ptr=NULL;
        printf("\n memory freed");
        
    }
    return 0;
}
