#include<stdio.h>
#pragma pack(1)
// using typedef way1
typedef struct emp
{
    int empno;
    char name[10];
    float sal;
    struct date
    {
        int dd, mm, yy;
    }doj;
 }EMP;  
int main(void)
{
    
    EMP e1;//struct emp e1;


    printf("\n Enter Emp No using type def way1 =");
    scanf("%d", &e1.empno);
    printf("\n Enter Emp Name=");
    scanf("%s", e1.name);
    printf("\n Enter Emp sal=");
    scanf("%f", &e1.sal);
    printf("\n Enter doj in DD-MM-YYYY format \n");
    scanf("%d%*c%d%*c%d", &e1.doj.dd, &e1.doj.mm, &e1.doj.yy);
    
    printf("\n EmpNo  Name  Sal  DOj using structure variable e1 \n");
    printf("%-8d%-10s%-6.2f\t%d-%d-%d", e1.empno, e1.name, e1.sal, e1.doj.dd, e1.doj.mm, e1.doj.yy);
    
    
    return 0;
    
}