#include<stdio.h>
#pragma pack(1)//  structure member alligement is 1 byte
// decl of struture (logical entity) 
struct emp
{
    // variable or data member
    int empno;
    char name[10];
    float sal;
 };  
// structure decl can be done with in any functions
// but generally done globally to use in all the functions of your program
int main(void)
{
    
    // struct emp is user define data type 
    // e1 is variable of user define data type struct emp
    //struct emp e1;// 18 bytes 
    struct emp e1={100};
    struct emp *ptr=&e1;
    // int is data type 
    // no1 is variable of int data type
    int no1;


    printf("\n Enter Emp No=");
    scanf("%d", &e1.empno);
    printf("\n Enter Emp Name=");
    scanf("%s", e1.name);
    printf("\n Enter Emp sal=");
    scanf("%f", &e1.sal);

    printf("\n EmpNo  Name  Sal using structure variable e1 \n");
    printf("%-8d%-10s%-6.2f", e1.empno, e1.name, e1.sal);
    
    printf("\n Size of e1=%d", sizeof(e1)); // 20 bytes
    printf("\n Size of struct emp=%d", sizeof(struct emp)); // 18 bytes
    printf("\n Size of struct emp=%d", sizeof(struct emp)); // 18 bytes
    printf("\n Size of ptr=%d", sizeof(ptr)); // 8 bytes ( 64 bit comp)
                                              // 4 bytes ( 32 bit operating system)
    
    printf("\n &e1=%u &e1+1=%u", &e1, &e1+1); // &e1 = 100   &e1+1=118 
    printf("\n ptr=%u ptr+1=%u", ptr, ptr+1); // ptr = 100   ptr+1=118

    printf("\n EmpNo  Name  Sal using pointer ptr by -> operator \n");
    printf("%-8d%-10s%-6.2f", ptr->empno, ptr->name, ptr->sal);
    
    printf("\n EmpNo  Name  Sal using pointer ptr by . operator \n");
    printf("%-8d%-10s%-6.2f", (*ptr).empno, (*ptr).name, (*ptr).sal);
    
    return 0;
    
} // gcc -m32 demo3.c   32 bit
// gcc -m64 demo3.c     64 bit