#include<stdio.h>

int main(void)
{
    // by defualt  structure member alligement is 4 bytes
    // decl of struture (logical entity) 
    struct emp
    {
        // variable or data member
        int empno;
        char name[10];
        float sal;
    };  // 18 bytes + 2 bytes(slack bytes)= 20 bytes
    // struct emp is user define data type 
    // e1 is variable of user define data type struct emp
    struct emp e1;
    // int is data type 
    // no1 is variable of int data type
    int no1;


    printf("\n Enter Emp No=");
    scanf("%d", &e1.empno);
    printf("\n Enter Emp Name=");
    scanf("%s", e1.name);
    printf("\n Enter Emp sal=");
    scanf("%f", &e1.sal);

    printf("\n EmpNo  Name  Sal \n");
    printf("%-8d%-10s%-6.2f", e1.empno, e1.name, e1.sal);
    
    printf("\n Size of e1=%d", sizeof(e1)); // 20 bytes
    printf("\n Size of struct emp=%d", sizeof(struct emp)); // 20 bytes

    //sizeof (no1); // 4 byets
    //sizeof( int); // 4 byets

    return 0;
    
}