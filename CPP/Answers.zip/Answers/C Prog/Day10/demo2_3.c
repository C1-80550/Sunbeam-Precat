#include <stdio.h>
#include<stdlib.h>
int main(void)
{
    float *ptr=NULL;
    int no , index;

    printf("\n Enter how many numbers u want :: ");
    scanf("%d", &no);

    ptr= (float*)malloc(no*sizeof(float));
    if(ptr==NULL)
        printf("\n Unable to allocate memory");
    else
    {
        printf("\n Enter value for array = \n");
        for(index=0; index<no; index++)
        {
            printf("\n ptr[%d]", index);
            scanf("%f", &ptr[index]);
        }

        printf("\n Elements of array  = \n");

        for(index=0; index<no; index++)
        {
            printf("\n ptr[%d] %f [%u]", index, *(ptr+index), (ptr+index));
        }

         free(ptr);
            ptr=NULL;
          printf("\n memrory is freed");
      //  printf("\n *ptr=%d", *ptr); // error
    }
    return 0;
}