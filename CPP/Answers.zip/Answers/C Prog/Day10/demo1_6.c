// strstr find the 1st occurance of substring in  string 
// if not found return NULL;
#include<stdio.h>
#include<string.h>
#define SIZE 40
char* mystrstr(const char *string, const char  substring);
int main()
{
    char  src[SIZE], *ptr=NULL,dest[SIZE] ;
    
    
    printf("\n Enter string :: ");
    scanf("%s", src);  // scanf("%s", &name);  
    //gets(name);

    printf("\n Enter sub string to search :: ");
    scanf("%*c%s", &dest);

    ptr= strstr(src, dest);
    if(ptr!=NULL)
        printf("\n %s is found in %s at %d location", dest, src, ptr-src);
    else    
        printf("\n %s is not found in %s ", dest, src);

    return 0;
}