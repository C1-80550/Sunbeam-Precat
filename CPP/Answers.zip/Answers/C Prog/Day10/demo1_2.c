// strcpy copies src at dest and return dest;
#include<stdio.h>
#include<string.h>
#define LEN 40
char* mystrcpy(char *d, const char * s );
int main()
{
    char src[LEN], *ptr=NULL,dest[LEN] ;
    int index;
    
    printf("\n Enter src :: ");
    scanf("%s", src);  // scanf("%s", &name);  

    printf("\n Enter dest :: ");
    scanf("%*c%s", dest);  // scanf("%s", &name);  
    
   //  src= dest;  lvalue req error
    
    ptr= strcpy(dest, src);

    printf("\n dest=%s", dest) ;// using return statement
    printf("\n dest=%s", ptr) ;// using pointer

    ptr= mystrcpy(dest, src);

    printf("\n dest=%s using my fun", dest) ;// using return statement
    printf("\n dest=%s using my fun", ptr) ;// using pointer


    return 0;
}
char* mystrcpy(char *d, const char * s )
{
   int index ;
    for(index=0; *(s+index)!='\0'; index++)
    {
        *(d+index)= *(s+index);  // copy src on dest
    }
    *(d+index)='\0'; // copy '\0' at end
    return d;

}  // s[index] == *(s+ index) == *(index+s) == index[s]