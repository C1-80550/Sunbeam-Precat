#include <stdio.h>
int main(void)
{
	{
		char *s1="SUNBEAM";
		printf("\n s1=%s", s1); // SUNBEAM
		printf("\n s1=%s", *&*&*&*&s1); // SUNBEAM
	}
	{
		char name[]="SUNBEAM";
		char *s1=name;
		printf("\n s1=%s", s1);// SUNBEAM
		printf("\n s1=%s", *&*&*&*&s1);// SUNBEAM
	}
	printf("\n============================================\n");
	{
		char name[]={'X','Y','Z','P','Q', '\0'};
               //    10  11  12  13   14  15
		{
			char *s1=(int*)name+1;
			// scale factor of int 4 so 10+4=14  
			// so Q is output 81 acsii value of Q
			printf("\n *s1=%c  %d", *s1, *s1);
			printf("\n *s1=%c  %d", *(char*)s1, *(char*)s1);
		}
		printf("\n============================================\n");
		{
			char *s1=(short int*)name+1;
				// scale factor of short int 2 so 10+2=12  
			    // so Z is output 90 acsii value of Z
			printf("\n *s1=%c  %d", *s1, *s1);
			printf("\n *s1=%c  %d", *(char*)s1, *(char*)s1);
		}
		printf("\n============================================\n");
		{
			char *s1=(char*)name+1;
				// scale factor of char 1 so 10+1=11  
			// so Y is output 89 acsii value of Y
			printf("\n *s1=%c  %d", *s1, *s1);
			printf("\n *s1=%c  %d", *(char*)s1, *(char*)s1);
		}
		printf("\n============================================\n");
	}

	return 0;
}
