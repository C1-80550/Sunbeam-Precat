 #include <stdio.h>
int main(void)
{
    int arr[] = {111, 222,333,444,555};
    int *ptr = arr;
    *++ptr;
    printf("arr[0] = %d, arr[1] = %d, *ptr = %d", arr[0], arr[1], *ptr);
    return 0;
}

/*The expression *++ptr has two operators of same precedence, 
so compiler looks for assoiativity. 
Associativity of operators is right to left. 
Therefore the expression is treated as *(++ptr). 
Therefore the output of second program is “arr[0] = 111, arr[1] = 222, *ptr = 222“.
*/
