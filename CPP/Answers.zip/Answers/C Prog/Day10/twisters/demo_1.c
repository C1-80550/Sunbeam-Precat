#include <stdio.h>
int main(void)
{
    int arr[] = {111, 222};
    int *ptr = arr;
    ++*ptr; //++(*ptr).
    printf("arr[0] = %d, arr[1] = %d, *ptr = %d", arr[0], arr[1], *ptr);
    //      112           222                                      112    
    return 0;
}
//Precedence of prefix ++ and * is same.
//Associativity of both is right to left.
//The expression ++*ptr has two operators of same precedence,
//so compiler looks for assoiativity.
//Associativity of operators is right to left.
//Therefore the expression is treated as ++(*ptr).
//Therefore the output of first program is " arr[0] = 112, arr[1] = 222, *ptr = 112"

