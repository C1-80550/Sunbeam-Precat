#include <stdio.h>
int main(void)
{
    int arr[] = {111, 222};
    int *ptr = arr;
    *ptr++; // *(ptr++)
    printf("arr[0] = %d, arr[1] = %d, *ptr = %d", arr[0], arr[1], *ptr);
    return 0;
}
//the expression *ptr++ is treated as *(ptr++)
//as the precedence of postfix ++ is higher than *.
//Therefore the output of second program is “arr[0] = 111, arr[1] = 222, *ptr = 222“.
