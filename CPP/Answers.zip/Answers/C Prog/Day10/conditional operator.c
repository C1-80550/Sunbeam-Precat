
/* a ? b ? c : d : e 
=> Below is the expansion of expression using ternary operator 
and if else statement. Expression using ternary operator: 
 

 a ?
      b ? c
    : d
: e

Expression using if else statement: 
 

if ( a )
    if ( b )
        c execute
    else 
        d execute
else 
    e execute
*/
#include <stdio.h>
int main(void)
{
    int a =3, b = 6, c=10, d=20, e=30;
    printf("\n%d ", a!=b?0?c:d:e);  // prints d so ans 20
    printf("\n%d ", a!=b?1?c:d:e);  // prints c so ans 10
    printf("\n%d ", a==b?1?c:d:e);  // prints 6 so ans 30

    {
        int a =3, b = 6;
        printf("\n%d ", a!=b?0?b:a:b); //prints a print 3
        //            3!=6 true so 0 is false so it will print a that is 3
        printf("\n%d ", a==b?0?b:a:b); //prints b print 6
        //               3==6 false so it will print last b
    }
    return 0;
}
