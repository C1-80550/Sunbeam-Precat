// malloc, calloc and realloc stdlib.h
// we allocate memory on extra segment/ heap.
// we should use free function

#include <stdio.h>
#include<stdlib.h>
int main(void)
{
    int *ptr=NULL;

    ptr= (int*)malloc(1*sizeof(int));
    if(ptr==NULL)
        printf("\n Unable to allocate memory");
    else
    {
        printf("\n Enter value for ptr :;");
        scanf("%d", ptr); // correct   //scanf("%d", &ptr); // wrong

        printf("\n *ptr=%d", *ptr);

        free(ptr);
        ptr=NULL;
        printf("\n memrory is freed");
      //  printf("\n *ptr=%d", *ptr); // error
    }
    return 0;
}
// valgrind is tool to check memory leakage.
// it is present on linux/max not on windows

// valgrind ./a.out

/*
       void *malloc(size_t size);
       void free(void *ptr);
       void *calloc(size_t nmemb, size_t size);
       void *realloc(void *ptr, size_t size);

*/