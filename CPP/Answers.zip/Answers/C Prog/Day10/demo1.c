/*
string functions
dynamic memory allocation
pointer to pointers
2D Array
twisters on array
*/
#include<stdio.h>
#include<string.h>
// unsigned int mystrlen(const char s[]);
 size_t mystrlen(const char *s);
int main()
{
    char name[40];
    unsigned int ans=0;  // size_t ans;
    printf("\n Enter Name :: ");
    scanf("%s", name);  // scanf("%s", &name);  

    printf("\n name=%s", name);

    ans= strlen(name);
    printf("\n length of %s is %u using build in function", name, ans);

    ans= mystrlen(name);
    printf("\n length of %s is %u using my function", name, ans);
    return 0;
}
 size_t mystrlen(const char *s)
 {
    /* 
        size_t index;
        index=0;
        while(*(s+index)!='\0')   // while(s[index]!='\0')
        {
            index++;
        }
        return index;
    */
     size_t index;

     for( index=0; *(s+index)!='\0' ;index++);   //  for( index=0; s[index]!='\0' ;index++);
           return index;
     

//        return index;
}  // arr[index]== *(arr+index)
