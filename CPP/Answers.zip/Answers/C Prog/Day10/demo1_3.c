#include<stdio.h>
#include<string.h>
#define LEN 40
char* mystrcat(char *d, const char * s );
// src append at end of dest and retrun dest
int main()
{
    char src[LEN], *ptr=NULL,dest[LEN] ;
    int index;
    
    printf("\n Enter src :: ");   //beam
    scanf("%s", src);  // scanf("%s", &name);  

    printf("\n Enter dest :: "); // sun
    scanf("%*c%s", dest);  
    
    
    ptr= strcat(dest, src);

    printf("\n dest=%s", dest) ;// using return statement
    printf("\n dest=%s", ptr) ;// using pointer

    

    return 0;
}