#include <stdio.h>
#include<stdlib.h>
int main(void)
{
    int *ptr=NULL, no , index;

    printf("\n Enter how many numbers u want :: ");
    scanf("%d", &no);

    ptr= (int*)malloc(no*sizeof(int));
    if(ptr==NULL)
        printf("\n Unable to allocate memory");
    else
    {
        printf("\n Enter value for array = \n");
        for(index=0; index<no; index++)
        {
            printf("\n ptr[%d]", index);
            //scanf("%d", &ptr[index]);  // array notation
           // scanf("%d", &index[ptr]);
           //scanf("%d", (ptr+index));// //pointer notation
           scanf("%d", (index+ptr));
        }

        printf("\n Elements of array  = \n");

        for(index=0; index<no; index++)
        {
            // array notation
            //printf("\n ptr[%d] %d [%u]", index, ptr[index], &ptr[index]);
            //printf("\n [%d]ptr %d [%u]", index, index[ptr], &index[ptr]  );
            //pointer notation
            //printf("\n *(ptr+%d) %d [%u]", index, *(ptr+index), (ptr+index));
            printf("\n ptr[%d] %d [%u]", index, *(index+ptr), (index+ptr));
        }

         free(ptr);
            ptr=NULL;
          printf("\n memrory is freed");
      //  printf("\n *ptr=%d", *ptr); // error
    }
    return 0;
}