// strchr find the 1st occurance of char if not found return NULL;
#include<stdio.h>
#include<string.h>

char* mystrchr(const char *s, int find);
int main()
{
    char name[40], *ptr=NULL, key;
    int index;
    
    printf("\n Enter Name :: ");
    scanf("%s", name);  // scanf("%s", &name);  
    //gets(name);

    printf("\n Enter char to search :: ");
    scanf("%*c%c", &key);

    ptr= strchr(name, key);
    if(ptr!=NULL)
        printf("\n %c is found in %s at %d location", key, name, ptr-name);
    else    
        printf("\n %c is not found in %s ", key, name);


    ptr= mystrchr(name, key);
    if(ptr!=NULL)
        printf("\n %c is found in %s at %d location using my fun", key, name, ptr-name);
    else    
        printf("\n %c is not found in %s using my fun", key, name);
    return 0;
}
char* mystrchr(const char *s, int find)
{
    int index;
    index=0;
    while(*(s+index)!='\0')   // while(s[index]!='\0')
    {
        if(*(s+index)== find)   // if(s[index]==find))
            return (s+index);        //return &s[index];
        index++;    
    }
    return NULL;
}  // s[index] == *(s+ index) == *(index+s) == index[s]

// return 10 ;  int
// return 10.1 ;  double
//return 10.1f ;  float
//return 10.1F ;  float
//return 10.1L ;  long
//return 10.1l ;  long
//return 'A';     char
// return "sunbeam";  char*




