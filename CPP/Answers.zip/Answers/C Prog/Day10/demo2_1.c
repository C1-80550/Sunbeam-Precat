#include <stdio.h>
#include<stdlib.h>
int main(void)
{
    char *ptr=NULL;

    ptr= (char*)malloc(1*sizeof(char));
    if(ptr==NULL)
        printf("\n Unable to allocate memory");
    else
    {
        printf("\n Enter value for ptr :;");
        scanf("%c", ptr); // correct   //scanf("%d", &ptr); // wrong

        printf("\n *ptr=%c *ptr=%d", *ptr, *ptr);

        free(ptr);
      / ptr=NULL;
        printf("\n memrory is freed");
      //  printf("\n *ptr=%d", *ptr); // error
    }
    return 0;
}