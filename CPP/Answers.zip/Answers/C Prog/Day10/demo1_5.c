#include<stdio.h>
#include<string.h>
#define LEN 40   // case is not consider capital and small are same here
int mystcasercmp(const char *s1, const char * s2 );

int main()
{
    char src[LEN],dest[LEN] ;
    int ans;
    
    printf("\n Enter src :: ");   //beam
    scanf("%s", src);  // scanf("%s", &name);  

    printf("\n Enter dest :: "); // sun
    scanf("%*c%s", dest);  
           // gcc                            // tc/ vs
    ans= strcasecmp(dest, src);    // ans= strcmpiest, src);

    if(ans==0)
        printf("%s is equal to %s", dest, src);
    else if (ans>0)
        printf("%s is grater than %s", dest, src);
    else if(ans<0)
        printf("%s is smaller than %s", dest, src);
    
    
    
    

    return 0;
}