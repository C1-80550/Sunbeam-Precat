#include<stdio.h>
#define SIZE 5
//void accept_array(int a[SIZE], int size);
void accept_array(int a[], int size);  // array notation
void display_array(int *a, int size);  // pointer notation
int main(void)
{
    int arr[SIZE], b[7];

    printf("\n Enter elememts of array arr :: \n");
    accept_array(arr, SIZE);

    printf("\n elements of array arr are:: \n");
    display_array(arr, SIZE);

    printf("\n Enter elememts of array b :: \n");
    accept_array(b, 7);

    printf("\n elements of array b are:: \n");
    display_array(b, 7);
    //arr++; // arr is array so not allowed

    return 0;
}
void accept_array(int a[], int size)
{
    int index;
    for(index=0; index<size; index++)
    {
        printf("\n a[%d] = ", index);
        //scanf("%d", &a[index]); // array notation
        //scanf("%d", &index[a]);
        //scanf("%d", (a+index)); // pointer notation
          scanf("%d", (index+a));
    }
    printf("\n size of a=%d",sizeof(a));  // a is pointer who holds address of array
   // a++;               // 64 bit 8 bytes  
    // allowed as a is pointer not a array        // 32 bit 4 bytes
    return;
}
void display_array(int *a, int size)
{
    int index;
 //   a++;
    for(index= 0; index<size ; index++)
    {
        // array notation
        //printf("\n a[%d] %d [%u]", index, a[index], &a[index]);
        //printf("\n [%d]a %d [%u]", index, index[a], &index[a]);
        // pointer notation
        //printf("\n *(a+index) %d [%u]", index, *(a+index), (a+index));
        printf("\n *(%d+a) %d [%u]", index, *(index+a), (index+a));        
    }
    return;
}
// a[index]== *(a+index) == *(index+a) == index[a]
