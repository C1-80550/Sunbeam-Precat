#include<string.h>
#include<stdio.h>
#define LEN 40
int main(void)
{
    // string
    char city1[LEN]="pune";  // \0 added by compiler
    char city2[]={'p','u','n', 'e', '\0'};  // \0 should be added by user
    char city3[LEN]={'k','a','r', 'a','d', '\0'};  // \0 should be added by user
    char city4[]="karad";  // \0 added by compiler

   // array of char
    char city5[LEN]={'k','a','r', 'a','d'};  



    printf("\n lenght of %s  is %d ", city1, strlen(city1)); // pune 4
    printf("\n size of %s  is %d ", city1, sizeof(city1));  // pune  40

     printf("\n lenght of %s  is %d ", city2, strlen(city2)); // pune 4
    printf("\n size of %s  is %d ", city2, sizeof(city2));  // pune  5

 printf("\n lenght of %s  is %d ", city3, strlen(city3)); // karad 5
    printf("\n size of %s  is %d ", city3, sizeof(city3));  // karad  40

 printf("\n lenght of %s  is %d ", city4, strlen(city4)); // karad 5
    printf("\n size of %s  is %d ", city4, sizeof(city4));  // karad  6

    return 0;
}