#include<stdio.h>
int main(void)
{
    int no1=10;
    float pi=3.142f;
    char ch='A';

   // void pointer can store address of any data type
    void *ptr=NULL;

    ptr=&no1; // no1 is of int data type
    //printf("\n *ptr=%d", *ptr);  //error: invalid use of void expression
    printf("\n *ptr=%d", *(int*)ptr);  // allowed  *ptr=10
    
    ptr= &pi;
    //printf("\n *ptr=%f", *ptr);  //error: invalid use of void expression
    printf("\n *ptr=%f", *(float*)ptr);  // allowed *ptr=3.142

    ptr=&ch;
    //printf("\n *ptr=%c", *ptr);  //error: invalid use of void expression
    printf("\n *ptr=%c", *(char*)ptr);   // allowed *ptr='A'
    
    printf("\n ptr=%u", ptr);  
    // ansi c say this should error 
    ptr++;  // in gcc  scale factor of void is consider as 1 byte
    printf("\n ptr=%u", ptr);

   return 0;
}