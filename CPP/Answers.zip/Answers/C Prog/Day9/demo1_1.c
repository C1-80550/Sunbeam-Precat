#include<stdio.h>
#define SIZE 5
//void accept_array(int a[SIZE], int size);
void accept_array(int a[], int size);  // array notation
void display_array(int *a, int size);  // pointer notation
int sum_array(int *a, int size);
int main(void)
{
    int arr[SIZE], ans=0;

    printf("\n Enter elememts of array arr :: \n");
    accept_array(arr, SIZE);

    printf("\n elements of array arr are:: \n");
    display_array(arr, SIZE);

    ans= sum_array(arr, SIZE);
    printf("\n sum of array=%d", ans);

    return 0;
}
void accept_array(int a[], int size)
{
    int index;
    for(index=0; index<size; index++)
    {
        printf("\n a[%d] = ", index);
        //scanf("%d", &a[index]); // array notation
        //scanf("%d", &index[a]);
        //scanf("%d", (a+index)); // pointer notation
          scanf("%d", (index+a));
    }
    return;
}
void display_array(int *a, int size)
{
    int index;
 //   a++;
    for(index= 0; index<size ; index++)
    {
        // array notation
        //printf("\n a[%d] %d [%u]", index, a[index], &a[index]);
        //printf("\n [%d]a %d [%u]", index, index[a], &index[a]);
        // pointer notation
        //printf("\n *(a+index) %d [%u]", index, *(a+index), (a+index));
        printf("\n *(%d+a) %d [%u]", index, *(index+a), (index+a));        
    }
    return;
}
int sum_array(int *a, int size)
{
    int sum, index;
    for(sum=index=0; index<size; index++)
    {
        sum+= *(a+index);//sum+=a[index];
    }
    return sum;
}





