#include<stdio.h>
int main(void)
{
    //const float pi=3.142f;
    // or
    float const  pi=3.142f;

    // we can not modify value of constant using following operators
    //  = , pre and post ++ . pre post -- , short hand operators
    //pi=4.4f;   // error
    /*pi++;
    ++pi;
    --pi;
    pi--;
    pi+=2;
    pi-=2;
    pi*=2;
    pi/=2;*/

    return 0;
}