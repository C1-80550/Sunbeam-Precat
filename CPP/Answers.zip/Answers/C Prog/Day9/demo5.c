#include<string.h>
#include<stdio.h>
#define LEN 40
int main(void)
{
    char city[LEN];
    printf("\n Enter city :: ");
    //scanf("%s", city);  // name of array itself is a base address
    // scanf can scan only upto space 

  //  gets(city); //gets will scan till new line char \n
   // scanf("%[^\n]s", city); // scan  upto \n means one single line
   // scanf("%[^.]s", city); // scan  upto . means multiple lines
    //scanf("%[^*]s", city); // scan  upto * means multiple lines
    //scanf("%[A-Z]s", city); // scan  upto capital letters
   // scanf("%[a-z]s", city); // scan  upto small letters
    //scanf("%[0-9]s", city); // scan  upto digits 
     //scanf("%[^A-Z]s", city); // scan  upto small letters
    // scanf("%[^a-z]s", city); // scan  upto capital letters
     scanf("%[^0-9]s", city); // scan  upto alphabets letters
    printf("\n city=%s", city);

    return 0;
}