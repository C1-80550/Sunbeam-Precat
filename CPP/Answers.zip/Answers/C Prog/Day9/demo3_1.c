/* case 1 pi variable is constant
                 value of ptr is not constant
                 Address of ptr is not constant
*/

#include<stdio.h>
int main(void)
{
    //const float pi=3.142f;
    // or
    float const  pi=3.142f;
     float pj=10.2f;
    float *ptr=&pi;
    // we can change the value of constant variable using pointer
    
                              // 3.142  3.142
     printf("\n pi=%.3f *ptr=%.3f", pi, *ptr);
     *ptr= 4.4f;  // allowed  as value of pointer is not constant
                              // 4.400  4.400
     printf("\n pi=%.3f *ptr=%.3f", pi, *ptr);

     ptr=&pj; // allowed as address of pointer is not constant
     printf("\n pi=%.3f *ptr=%.3f  pj=%.3f", pi, *ptr, pj);
                                      // 4.400  10.200  10.200


    return 0;
}