#include<stdio.h>
#define SIZE 5
//void accept_array(int a[SIZE], int size);
void accept_array(int a[], int size);  // array notation
void display_array(int *a, int size);  // pointer notation
void max_min_array(int *a, int size, int *pMax, int *pMin);
int main(void)
{
    int arr[SIZE], max=0, min=0;

    printf("\n Enter elememts of array arr :: \n");
    accept_array(arr, SIZE);

    printf("\n elements of array arr are:: \n");
    display_array(arr, SIZE);

    max_min_array(arr, SIZE, &max, &min);
    printf("\n max of array=%d", max);
    printf("\n min of array=%d", min);

    return 0;
}
void accept_array(int a[], int size)
{
    int index;
    for(index=0; index<size; index++)
    {
        printf("\n a[%d] = ", index);
        //scanf("%d", &a[index]); // array notation
        //scanf("%d", &index[a]);
        //scanf("%d", (a+index)); // pointer notation
          scanf("%d", (index+a));
    }
    return;
}
void display_array(int *a, int size)
{
    int index;
 //   a++;
    for(index= 0; index<size ; index++)
    {
        // array notation
        //printf("\n a[%d] %d [%u]", index, a[index], &a[index]);
        //printf("\n [%d]a %d [%u]", index, index[a], &index[a]);
        // pointer notation
        //printf("\n *(a+index) %d [%u]", index, *(a+index), (a+index));
        printf("\n *(%d+a) %d [%u]", index, *(index+a), (index+a));        
    }
    return;
}
void max_min_array(int *a, int size, int *pMax, int *pMin)
{
    int max, index;
    for(index=1, *pMax=*pMin= a[0]; index<size; index++)
    {
        if( *pMax < a[index])
            *pMax= a[index];
        if( *pMin > a[index])
            *pMin= a[index];
    }
    return;
}

// rev the array   swap last with 0 and 2ed last with 1 till nidle elements of array
// print rev  for(index=size-1; index>0; index--)
// avarage of array == sum/ num of elements

