/* case 4 pi variable is constant
                 value of ptr is   constant
                 Address of ptr is  constant
*/

#include<stdio.h>
int main(void)
{
    //const float pi=3.142f;
    // or
    float const  pi=3.142f;
     float pj=10.2f;
    const float * const ptr=&pi; // address of pointer is constant
                                 // value of pointer is constant
   // float const * const ptr=&pi;                                  
    
    
                              // 3.142  3.142
     printf("\n pi=%.3f *ptr=%.3f", pi, *ptr);

   // *ptr= 4.4f;  // not allowed  as value of pointer is  constant
                              // 3.142   3.142
     printf("\n pi=%.3f *ptr=%.3f", pi, *ptr);

   // ptr=&pj; //not  allowed as address of pointer is constant
     printf("\n pi=%.3f *ptr=%.3f  pj=%.3f", pi, *ptr, pj);
                                      // 3.142  3.142  10.200


    return 0;
}