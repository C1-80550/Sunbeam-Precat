// function overloading
//case 3 function having same name different order of arguements
#include<stdio.h>
float sum(int n1 , float n2)  // sum@@int, float
{
    return n1+n2;
}
float sum(float n1 , int n2)  // sum@@float, int
{
    return n1+n2;
}
int main(void)
{
    float ans=0;
    ans= sum(10.1f, 20);  // sum@@float , int
    printf("\n ans=%.2f", ans);  // ans=30.1

    ans= sum(10, 20.2f);  // sum@@int, float
    printf("\n ans=%.3f", ans); // ans=30.2
    return 0;
    
}

 //g++ -S demo4_3.cpp   demo4_3.s (linux) // demo4_3.asm  (windows)