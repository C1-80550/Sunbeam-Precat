// struture in c
#include<stdio.h>
// by default structure member alligment 4 bytes
#pragma pack(1) // structure member alligment 1 byte
struct emp
{
    //variable(c) / data member(cpp) / field(java)
    int empno;
    char name[10];
    float sal;
}; // slack bytes ()
int main(void)
{
    // int no1; int data type and no1 is variable of int data type
    // struct emp is user defined data type 
    // e1 is (variable c) /(object cpp) of user defined data type struct emp
    struct emp e1;
    printf("\n Enter Emp info :: ");
    printf("\n Enter Emp No = ");
    scanf("%d", &e1.empno);
    printf("\n Enter Emp Name = ");
    scanf("%s", e1.name);
    printf("\n Enter Emp sal = ");
    scanf("%f", &e1.sal);

    printf("\n Empno  Name  Sal \n");
    printf("%-6d%-10s%-6.2f",e1.empno, e1.name, e1.sal);


    printf("\n size of e1=%d", sizeof(e1));
  
    return 0;   
}

/*
  {

        int i=3, j=0;
        // gcc
        //  4     5*5=25 *6==150
        //  3     4     5
        j= ++i * ++i * ++i;
        printf("\n i=%d j=%d", i, j);

        {
            int i=3, j=0;
        // gcc
        //  4     5*5=25 *6==150*7=1050
        //  3     4     5     6
        j= ++i * ++i * ++i * ++i ;
        printf("\n i=%d j=%d", i, j);
        }

        {
             int i=3, j=0;
        // TC/VS
        //  4     5      6      6*6*6=216
        //  3     4     5
        j= ++i * ++i * ++i;   //6 216
        printf("\n i=%d j=%d", i, j);
           
        }
    }

*/