// function overloading
//case 1 function having same name different no of arguements
#include<stdio.h>
int sum(int n1 , int n2)  // sum@@int, int
{
    return n1+n2;
}
int sum(int n1 , int n2, int n3)  // sum@@int, int, int
{
    return n1+n2+n3;
}
int main(void)
{
    int ans=0;
    ans= sum(10, 20);  // sum@@int , int
    printf("\n ans=%d", ans);  // ans=30

    ans= sum(10, 20, 30);  // sum@@int, int, int
    printf("\n ans=%d", ans); // ans=60
    return 0;
    
}

 //g++ -S demo4_1.cpp   demo4_1.s (linux) // demo4_1.asm  (windows)