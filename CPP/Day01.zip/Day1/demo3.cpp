#include<stdio.h>
// macro argument dont have data types
#define sq(a) a*a  // macro is command
inline int square(int a); // inline is request
// function argument have data type
int main(void)
{
    int x=5, y=0;
    y= sq(x);   // y= x*x;   y=5*5; y =25;
    printf("\n x=%d y=%d using macro ", x, y); // x=5 y =25

    y= sq(x+x);   // y= x+x*x+x;   y=5+5*5+5; y = 5+25+5; y=35
    printf("\n x=%d y=%d using macro ", x, y); // x=5 y =35

    y= 25/sq(x);   // y= 25/ x*x;   y=25/ 5*5; y=25;
    printf("\n x=%d y=%d using macro ", x, y); // x=5 y =25

    y= sq((x+x));   // y= (x+x)*(x+x);   y=(5+5)*(5+5); y=10*10 ==100;
    printf("\n x=%d y=%d using macro ", x, y); // x=5 y =100

    
    y= square(x);
    printf("\n x=%d y=%d using function ", x, y); // x=5 y =25
    
}
inline int square(int a)
{
    return a*a;
}

// g++ -E -o demo3.i demo3.cpp  (Cpp)
// gcc -E -o demo3.i demo3.c  (C)