// struture in cpp 
#include<stdio.h>
#pragma pack(1) 
struct emp
{
    private:
    //variable(c) / data member(cpp) / field(java)
        int empno;
        char name[10];
        float sal;

    public:
    // member function or methods
        void accept_emp_info()
        {
            printf("\n Enter Emp No = ");
            scanf("%d", &empno);
            printf("\n Enter Emp Name = ");
            scanf("%s", name);
            printf("\n Enter Emp sal = ");
            scanf("%f", &sal);
            return; 
        }
        void display_emp_info()
        {
            printf("\n Empno  Name  Sal \n");
            printf("%-6d%-10s%-6.2f\n",empno, name, sal);
            return;
        }

}; // slack bytes ()

//typedef struct emp EMP;
//EMP e1; // struct emp e1;

int main(void)
{
    // int no1; int data type and no1 is variable of int data type
    // struct emp is user defined data type 
    // e1 is (variable c) /(object cpp) of user defined data type struct emp
    emp e1; //struct emp e1;
    printf("\n Enter Emp info :: ");
    //cpp                       c
    e1.accept_emp_info();  //accept_emp_info(&e1);

    printf("\n Emp info :: \n");
    e1.display_emp_info(); // display_emp_info(&e1);

    //e1.sal=-10000;  //error: ‘float emp::sal’ is private within this context


    printf("\n Emp info with new sal :: \n");
    e1.display_emp_info() ;//display_emp_info(&e1);

    printf("\n size of e1=%d", sizeof(e1));
    printf("\n &e1=%u &e1+1=%u", &e1, &e1+1);
    return 0;   
}
// const int no1;
// int const no2;