// function overloading
//case 2 function having same name different types of arguements
#include<stdio.h>
int sum(int n1 , int n2)  // sum@@int, int
{
    return n1+n2;
}
float sum(float n1 , float n2)  // sum@@float, float
{
    return n1+n2;
}
int main(void)
{
    int ans=0;
    ans= sum(10, 20);  // sum@@int , int
    printf("\n ans=%d", ans);  // ans=30

    float ans1=0;
    ans1= sum(10.1f, 20.2f);  // sum@@float, float
    printf("\n ans=%.3f", ans1); // ans=30.3
    return 0;
    
}

 //g++ -S demo4_2.cpp   demo4_2.s (linux) // demo4_2.asm  (windows)