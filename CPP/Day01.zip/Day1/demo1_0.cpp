#include<stdio.h>
int main(void)
{
    int empno;
    char name[10];
    float sal;

    printf("\n Enter Emp No = ");
    scanf("%d", &empno);
    printf("\n Enter Emp Name = ");
    scanf("%s", name);
    printf("\n Enter Emp sal = ");
    scanf("%f", &sal);

    printf("\n Empno  Name  Sal \n");
    printf("%-6d%-10s%-6.2f",empno, name, sal);

    return 0;   
    
}