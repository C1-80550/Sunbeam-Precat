// struture in c using functions
#include<stdio.h>
// by default structure member alligment 4 bytes
#pragma pack(1) // structure member alligment 1 byte
struct emp
{
    //variable(c) / data member(cpp) / field(java)
    int empno;
    char name[10];
    float sal;
}; // slack bytes ()
void accept_emp_info(struct emp *e);  // 4 to 8 bytes
void display_emp_info(const struct emp *e); // 4 to 8 bytes
int main(void)
{
    // int no1; int data type and no1 is variable of int data type
    // struct emp is user defined data type 
    // e1 is (variable c) /(object cpp) of user defined data type struct emp
    struct emp e1;
    printf("\n Enter Emp info :: ");
    accept_emp_info(&e1);

    printf("\n Emp info :: \n");
    display_emp_info(&e1);

    e1.sal=-10000;


    printf("\n Emp info with new sal :: \n");
    display_emp_info(&e1);

    printf("\n size of e1=%d", sizeof(e1));
    printf("\n &e1=%u &e1+1=%u", &e1, &e1+1);
    return 0;   
}

void accept_emp_info(struct emp *e)
{
    printf("\n Enter Emp No = ");
    scanf("%d", &e->empno);
    printf("\n Enter Emp Name = ");
    scanf("%s", e->name);
    printf("\n Enter Emp sal = ");
    scanf("%f", &e->sal);
    return; 
}
void display_emp_info(const struct emp *e)
{
    //e->sal=0;  // error: assignment of member ‘emp::sal’ in read-only object
    printf("\n Empno  Name  Sal \n");
    printf("%-6d%-10s%-6.2f\n",e->empno, e->name, e->sal);
    printf("%-6d%-10s%-6.2f\n",(*e).empno, (*e).name, (*e).sal);

    return;
}

// const int no1;
// int const no2;