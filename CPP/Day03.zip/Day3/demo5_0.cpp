/* types of member function
  1. Facilitator -- input and output  facility of input output
  2. ctor
  3. dtor
  4. settor method - mutator
  5. gettor method - inspectors
*/

// demo of input and output (Facilitator)
#include<iostream>
using namespace std;
namespace NComplex
{
    class Compelx
    {
        private:
           //variable/ data member /fields
            int real;
            int imag;
        public:
            // member function / methods

            // 1.1 input 
            //void accept_input(className * const this)
            //void accept_input(Complex * const this)
            void accept_input()
            {
                cout<<"Enter Real=";
                cin>>this->real;
                cout<<"Enter Imag=";
                cin>>this->imag;                
            }

            //void display_output(Complex * const this)
            void display_output()
            {
                cout<<"this->Real="<<this->real <<"\t &this->real = ["<< &this->real<<"]\n" ;
                cout<<"this->Imag="<<this->imag <<"\t &this->imag = ["<< &this->imag<<"]\n" ;
                
            }



    };// end of class Complex
}// end of Namespace NComplex
using namespace NComplex;
int main()
{
    Compelx c1,c2;
    cout<<"Enter data for c1"<<endl;
    c1.accept_input();
    cout<<"c1 ="<<endl;
    c1.display_output();

    cout<<"Enter data for c2"<<endl;
    c2.accept_input();
    cout<<"c2 ="<<endl;
    c2.display_output();
    
    return 0;
}