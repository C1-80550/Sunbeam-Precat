#include<iostream> //#include<iostream.h>
using namespace std;
int main(void)
{
    int no1, no2;
    cout<<"Enter no1=";
    //cin>>&no1; //error in cpp scanf("%d", &no1); 
    cin>>no1; // allowed  in cpp

    cout<<"Enter no2=";
    //cin>>&no2; //error in cpp scanf("%d", &no2); 
    cin>>no2; // allowed  in cpp

    cout<<"no1= "<<no1<<" \t &no1=[" <<&no1<<" ] "<<endl;
    cout<<"no2= "<<no2<<" \t &no2=[" <<&no2<<" ] "<<"\n";
                             // address will be print hex
    return 0;
}