// demo of setter method mutator
// mutator modify state (values store in data member )of the object
#include<iostream>
using namespace std;
namespace NComplex
{
    class Compelx
    {
        private:
           //variable/ data member /fields
            int real;
            int imag;
        public:
            // member function / methods

            // 1.1 input 
            //void accept_input(className * const this)
            //void accept_input(Complex * const this)
            void accept_input()
            {
                cout<<"Enter Real=";
                cin>>this->real;
                cout<<"Enter Imag=";
                cin>>this->imag;                
            }

            //void display_output(Complex * const this)
            void display_output()
            {
                cout<<"this->Real="<<this->real <<"\t &this->real = ["<< &this->real<<"]\n" ;
                cout<<"this->Imag="<<this->imag <<"\t &this->imag = ["<< &this->imag<<"]\n" ;
                
            }
        // 4. mutator
          //void set_real(Complex * const this, int real)
            void set_real(int real)
            {
                this->real= real;
            }
          //void set_imag(Complex * const this, int imag)
            void set_imag(int imag)
            {
                this->imag= imag;
            }


    };// end of class Complex
}// end of Namespace NComplex
using namespace NComplex;
int main()
{
    Compelx c1;
    cout<<"Enter data for c1"<<endl;
    int r, i;
    cout<<"Enter real for c1 =" ;
    cin>>r;
    cout<<"Enter imag for c1 =" ;
    cin>>i;
    // setting values of real and imag using mutator (setter) function
    c1.set_real(r); 
    c1.set_imag(i); 

    cout<<"c1 ="<<endl;
    c1.display_output();

    
    return 0;
}