#include<stdio.h>//or #include<cstdio>
#include<stdlib.h>//or #include<cstdlib>
#include<iostream> //#include<iostream.h>
int main(void)
{
    int no1, no2;
    std::cout<<"Enter no1=";
    //std::cin>>&no1; //error in cpp scanf("%d", &no1); 
    std::cin>>no1; // allowed  in cpp

    std::cout<<"Enter no2=";
    //std::cin>>&no2; //error in cpp scanf("%d", &no2); 
    std::cin>>no2; // allowed  in cpp

    std::cout<<"no1= "<<no1<<" \t &no1=[" <<&no1<<" ] "<<std::endl;
    std::cout<<"no2= "<<no2<<" \t &no2=[" <<&no2<<" ] "<<"\n";
                             // address will be print hex
    return 0;
}