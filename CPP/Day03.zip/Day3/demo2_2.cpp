#include<iostream> //#include<iostream.h>
using namespace std;
int main(void)
{
    cout<<"int datatype= "<<endl;
    {
        int no1, no2;
        cout<<"Enter no1=";
        //cin>>&no1; //error in cpp scanf("%d", &no1); 
        cin>>no1; // allowed  in cpp

        cout<<"Enter no2=";
        //cin>>&no2; //error in cpp scanf("%d", &no2); 
        cin>>no2; // allowed  in cpp

        cout<<"no1= "<<no1<<" \t &no1=[" <<&no1<<" ] "<<endl;
        cout<<"no2= "<<no2<<" \t &no2=[" <<&no2<<" ] "<<"\n";
                                 // address will be print hex
    }
    cout<<"======================================"<<endl;

    cout<<"float data type= "<<endl;
    {
        float no1, no2;
        cout<<"Enter no1=";
        //cin>>&no1; //error in cpp scanf("%d", &no1); 
        cin>>no1; // allowed  in cpp

        cout<<"Enter no2=";
        //cin>>&no2; //error in cpp scanf("%d", &no2); 
        cin>>no2; // allowed  in cpp

        cout<<"no1= "<<no1<<" \t &no1=[" <<&no1<<" ] "<<endl;
        cout<<"no2= "<<no2<<" \t &no2=[" <<&no2<<" ] "<<"\n";
                                 // address will be print hex
    }
    cout<<"======================================"<<endl;


    cout<<"char datatype= "<<endl;
    {
        char no1, no2;
        cout<<"Enter no1=";
        //cin>>&no1; //error in cpp scanf("%d", &no1); 
        cin>>no1; // allowed  in cpp

        cout<<"Enter no2=";
        //cin>>&no2; //error in cpp scanf("%d", &no2); 
        cin>>no2; // allowed  in cpp

        cout<<"no2= "<<no1<<" \t &no1=[" <<(void*)&no1<<" ] "<<endl;
        cout<<"no2= "<<no2<<" \t &no2=[" <<(void*)&no2<<" ] "<<"\n";
                                 // address will be print hex
    }
    cout<<"======================================"<<endl;
    return 0;
}