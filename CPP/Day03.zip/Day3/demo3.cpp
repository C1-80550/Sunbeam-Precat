#include<iostream>
using namespace std;
#pragma pack(1) 


class emp
{
    private:
    //variable(c) / data member(cpp) / field(java)
        int empno;
        char name[10];
        float sal;

    public:
    // member function or methods
        //e2.accept_emp_info();  // this=&e2;
        //e1.accept_emp_info();  // this=&e1;
        //void accept_emp_info(emp * const this)
        void accept_emp_info()
        {
            cout<<"\n Enter Emp No = ";
            cin>>this->empno;
            cout<<"\n Enter Emp Name = ";
            cin>>this->name;
            cout<<"\n Enter Emp sal = ";
            cin>>this->sal;
            return; 
        }
        //e1.display_emp_info(); // this=&e1;
        //e2.display_emp_info(); // this=&e2;
        //void display_emp_info(emp * const this)
        void display_emp_info()
        {
            cout<<"\n Empno  Name  Sal \n";
            cout<<this->empno<<"\t"<<this->name<<" \t"<< this->sal<<endl;
            return;
        }
    //  void set_salary(emp * const this,float sal)
        void set_salary(float sal)
        {
           this->sal= sal;
           return;
        }

}; // end of emp class 
int main(void)
{
    // class emp is user defined data type 
    // e1 is (variable c) /(object cpp) of user defined data type struct emp
    emp e1; //class emp e1;
    cout<<"\n Enter Emp info :: ";
    //cpp                       c
    e1.accept_emp_info();  //accept_emp_info(&e1);

    cout<<"\n Emp info :: \n";
    e1.display_emp_info(); // display_emp_info(&e1);

    //e1.sal=-10000;  //error: ‘float emp::sal’ is private within this context

    e1.set_salary(12000);  // update sal

    cout<<"\n Emp info with new sal :: \n";
    e1.display_emp_info() ;//display_emp_info(&e1);





    return 0;   
}