// demo of ctor
/*
    ctor is special member function of class which automatically gets called when
obejct is created
    name of ctor should be name of the class
    ctor dont have any return type not even void

    there are 3 types of ctors in cpp
    1. default ctor
    2. parameterless ctor  or no argrument ctor
    3. parameterized ctor
       ---  copy ctor comes under parameterized ctor

    
*/

#include<iostream>
using namespace std;
namespace NComplex
{
    class Compelx
    {
        private:
           //variable/ data member /fields
            int real;
            int imag;
        public:
            // member function / methods

            // 1.1 input 
            //void accept_input(className * const this)
            //void accept_input(Complex * const this)
            void accept_input()
            {
                cout<<"Enter Real=";
                cin>>this->real;
                cout<<"Enter Imag=";
                cin>>this->imag;                
            }

            //void display_output(Complex * const this)
            void display_output()
            {
                cout<<"this->Real="<<this->real <<"\t &this->real = ["<< &this->real<<"]\n" ;
                cout<<"this->Imag="<<this->imag <<"\t &this->imag = ["<< &this->imag<<"]\n" ;
                
            }
            // if we dont write ctor compiler will provide default ctor

    };// end of class Complex

}// end of Namespace NComplex
using namespace NComplex;
Compelx c2; // global object
int main()
{
    Compelx c1;  // local object
    cout<<"c1 ="<<endl;   
    c1.display_output();  // real = garbage value imag= garbage value

    cout<<"c2 ="<<endl;   
    c2.display_output();  // real = 0  imag= 0

    static Compelx c3;
    cout<<"c3 ="<<endl;   
    c3.display_output();  // real = 0 value imag= 0

   register Compelx c4;  // register object
    cout<<"c4 ="<<endl;   
    c4.display_output();  // real = garbage value imag= garbage value

    return 0;
}