// size of empty class/ struture object is ___1 byte_________.
#include<iostream>
using namespace std;
class Empty
{

};
struct empty
{

};

int main()
{
    Empty e1;  // class Empty e1;
    empty e2;  // struct empty e2;

    cout<<"size of e1="  <<sizeof(e1)<<endl;
    cout<<"size of e2="  <<sizeof(e2)<<endl;

    cout<<"size of Empty="  <<sizeof(Empty)<<endl;
    cout<<"size of empty="  <<sizeof(empty)<<endl;

    cout<<" &e1="<<&e1<<endl;  // object is phyical entity
    cout<<" &e2="<<&e2<<endl;

    //cout<<" &Empty="<<&Empty<<endl;  // error as class and struct are logical entity
    //cout<<" &empty="<<&empty<<endl;

    return 0;
}

