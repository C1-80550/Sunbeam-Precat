// demo of getter method mutator
// inspector dont  modify state (values store in data member )of the object
#include<iostream>
using namespace std;
namespace NComplex
{
    class Compelx
    {
        private:
           //variable/ data member /fields
            int real;
            int imag;
        public:
            // member function / methods

            // 1.1 input 
            //void accept_input(className * const this)
            //void accept_input(Complex * const this)
            void accept_input()
            {
                cout<<"Enter Real=";
                cin>>this->real;
                cout<<"Enter Imag=";
                cin>>this->imag;                
            }

            //void display_output(Complex * const this)
            void display_output()
            {
                cout<<"this->Real="<<this->real <<"\t &this->real = ["<< &this->real<<"]\n" ;
                cout<<"this->Imag="<<this->imag <<"\t &this->imag = ["<< &this->imag<<"]\n" ;
                
            }
        // 4. mutator
          //void set_real(Complex * const this, int real)
            void set_real(int real)
            {
                this->real= real;
            }
          //void set_imag(Complex * const this, int imag)
            void set_imag(int imag)
            {
                this->imag= imag;
            }

    //  5. gettor method (inspectors)
        //int get_real(Complex * const this)
        int get_real()
        {
            return this->real;
        }
        //int get_imag(Complex * const this)
        int get_imag()
        {
            return this->imag;
        }

    };// end of class Complex
}// end of Namespace NComplex
using namespace NComplex;
int main()
{
    Compelx c1;
    cout<<"Enter data for c1"<<endl;
    int r, i;
    cout<<"Enter real for c1 =" ;
    cin>>r;
    cout<<"Enter imag for c1 =" ;
    cin>>i;
    // setting values of real and imag using mutator (setter) function
    c1.set_real(r); 
    c1.set_imag(i); 

  // getting values of real and imag using inspectors(getter) functions
    r= c1.get_real();
    i= c1.get_imag();

    cout<<" real of c1="<<r<<endl;
    cout<<" imag of c1="<<i<<endl;

    cout<<"c1 ="<<endl;
    c1.display_output();

    
    return 0;
}