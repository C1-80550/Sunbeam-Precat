/*

// seq file access
types files
1. text file 
    .txt , .c , .i , .asm  ,

    1. char by char --->> fputc, fgetc
    2. string by string --->> fgets, fputs
    3. structure by structure -->>  fprintf, fscanf  


2. binary file
    .exe , .bat , .mp3 , .mp4

    1. read and write date in binary file ----> fwrite, fread  (1st  parameter void pointer)
        char by char , string by string and structure by structure

   FILE struture --->> stdio.h
   FILE *fp=NULL;
   fp= fopen(path, mode_of_file);

   process

   fclose(fp); // close one file
   fcloseall();  // close all open files


stdin
stdout
stderr



 

    mode of file for text -?
    w write  old data erase               wb
    a append                              ab
    r                                     rb 
    w+  read write                        wb+
    a+  read append  best mode            ab+   
    r+  read write                        rb+ 


// random file access
   fseek

*/

// write data into text file char by char using fputc function 

#include<stdio.h>
int main(void)
{
    char ch;
    int cnt;
    FILE *fpWrite=NULL;

//    fpWrite= fopen("file1.txt","w");
                   //file_path  mode_file
    fpWrite= fopen("file1.txt","a");
    if( fpWrite==NULL)
        printf("\n unable to create file");
    else
    {   
        printf("\n enter your data :: \n");
        cnt=0;                           // -1    (winodw ctrl+z ) linux ctrl+d
        while( (ch=fgetc(stdin))!=EOF)
        {
            fputc(ch,fpWrite); // write data into text file
            cnt++;
        }
        printf("\n %d chars added into file ", cnt);
        fclose(fpWrite);
    }
    return 0;
}

// home word ----  count no of char, digits,spaces, alphabets , lines, tabs, spaces