// read data from text file char by char using fgetc function 

#include<stdio.h>
int main(void)
{
    char ch;
    int cnt;
    FILE *fpRead=NULL;


                   //file_path  mode_file
    fpRead= fopen("file1.txt","r");
    if( fpRead==NULL)
        printf("\n unable to read file");
    else
    {   
        printf("\n your data :: \n");
        cnt=0;                           // -1    (winodw ctrl+z ) linux ctrl+d
        while( (ch=fgetc(fpRead))!=EOF)
        {
            fputc(ch,stdout); // write data on console
           // getchar();
            cnt++;
        }
        printf("\n %d chars read from file ", cnt);
        fclose(fpRead);
        // fcloseall();
    }
    return 0;
}