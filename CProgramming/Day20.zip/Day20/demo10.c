#include<stdio.h>
int main(void)
{
    FILE *fp=NULL;
    char ch;
    fp= fopen("abc.txt", "r");
    if(fp==NULL)
        printf("\n unable to open file");
    else
    {
        fseek(fp,-1, SEEK_END); // go to last char in file
        ch= fgetc(fp);
        printf("\nch=%c", ch);
        fseek(fp, -1L, 1); // last char

        fseek(fp,-10, SEEK_CUR); // 
        ch= fgetc(fp);
        printf("\nch=%c", ch);
        fseek(fp, -1L, 1);

        fseek(fp,5, SEEK_CUR); // 
        ch= fgetc(fp);
        printf("\nch=%c", ch);
        fseek(fp, -1L, 1);


        fclose(fp);
    }
    return 0;
}
