// read emp (emp structure) info from binary file using fread
#include<stdio.h>
struct emp
{
    int empno;
    char name[10];
    float sal;
};
void display_emp_info(const struct emp *e1);
int main(void)
{
    FILE *fpEmpRead=NULL;
    struct emp e;
    int cnt;
    fpEmpRead= fopen("empinfo.dat","rb");
    if( fpEmpRead==NULL)
        printf("\n Unable to open file for read");
    else
    {
        
        // read all record from binary file
        printf("\n Empno  Name   Sal\n");
        cnt=0;
        while (fread(&e,sizeof(struct emp),1,fpEmpRead))  // while(1) while(1) while(1) while(0)
        {
            display_emp_info(&e);
            cnt++;
        }
        printf("\n %d records read from file", cnt);
        fclose(fpEmpRead);
    }
    return 0;
}

void display_emp_info(const struct emp *e1)
{
 
    printf("%-6d%-10s%-6.3f\n", e1->empno, e1->name, e1->sal);
   // printf("%-6d%-10s%-6.3f\n", (*e1).empno, (*e1).name, (*e1).sal);
    return;
}