// read data from text file string by string (no fo char) using fgets function 
#define SIZE  5
#include<stdio.h>
int main(void)
{
    char arr[SIZE];
    
    FILE *fpRead=NULL;

//    fpWrite= fopen("file1.txt","w");
                   //file_path  mode_file
    
    //fpRead= fopen("D:\\sunbeam\\OM24\\Day20\\file1.txt","r");  // windows
    fpRead= fopen("/home/sunbeam/OM24/Day20/file1.txt","r");  // linux
    if( fpRead==NULL)
        printf("\n unable to read file");
    else
    {   
        printf("\n your data :: \n");
                        
        while( fgets(arr, SIZE, fpRead)!=NULL)
        {
            fputs(arr,stdout); // print data  on console
            getchar();
        }
        printf("\n data read  from file ");
        fclose(fpRead);
    }
    return 0;
}