// write data into text file string by string (no fo char) using fputs function 
#define SIZE  40
#include<stdio.h>
int main(void)
{
    char arr[SIZE];
    
    FILE *fpWrite=NULL;

//    fpWrite= fopen("file1.txt","w");
                   //file_path  mode_file
    
    //fpWrite= fopen("D:\\sunbeam\\OM24\\Day20\\file1.txt","a");  // windows
    fpWrite= fopen("/home/sunbeam/OM24/Day20/file1.txt","a");  // linux
    if( fpWrite==NULL)
        printf("\n unable to create file");
    else
    {   
        printf("\n enter your data :: \n");
                        
        while( fgets(arr, SIZE, stdin)!=NULL)
        {
            fputs(arr,fpWrite);
        }
        printf("\n data added into file ");
        fclose(fpWrite);
    }
    return 0;
}