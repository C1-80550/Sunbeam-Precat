#include<stdio.h>
#define SIZE  40
int main(void)
{
    char words[SIZE];
    FILE *fpRead=NULL;
    int index=0;
    fpRead= fopen("data.txt","r");
    if(fpRead==NULL)
        printf("\n unable to open file");
    else
    {
        index=0;
        while(fscanf(fpRead,"%s", words)!=EOF)
        {
            index++;
            printf("\n %d] %s", index, words);
        }
        printf("\n %d words read from file ", index);
        fclose(fpRead);
    }
}