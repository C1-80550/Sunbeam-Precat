#include<stdio.h>
int main(void)
{
    FILE *fp=NULL;
    char ch;
    fp= fopen("abc.txt", "r");
    if(fp==NULL)
        printf("\n unable to open file");
    else
    {
        //fseek(fp,-1,2); // to to last char in file E
        fseek(fp , -1, SEEK_END);
        do
        {
            ch= fgetc(fp);
            //if(ch=='\n')  // for windows remove comments
                //fseek(fp, -1, 1);
            printf("%c", ch);            

        }while(!fseek(fp,-2L, SEEK_CUR));
        //}while(!fseek(fp,-2L, 1));

        fclose(fp);
    }
    return 0;
}
