// read emp (emp structure) info from text file using fscanf
#include<stdio.h>
struct emp
{
    int empno;
    char name[10];
    float sal;
};
void display_emp_info(const struct emp *e1);
int main(void)
{
    FILE *fpEmpRead=NULL;
    struct emp e;

    fpEmpRead= fopen("empinfo.txt","r");
    if( fpEmpRead==NULL)
        printf("\n Unable to open file for read");
    else
    {
        
        // read 1st record from file
        fscanf(fpEmpRead,"%d\t%s\t%f\n",&e.empno, e.name, &e.sal );
        display_emp_info(&e);
        printf("\n 1st record read from file");
        fclose(fpEmpRead);
    }
    return 0;
}

void display_emp_info(const struct emp *e1)
{
    printf("\n Empno  Name   Sal\n");
    printf("%-6d%-10s%-6.3f\n", e1->empno, e1->name, e1->sal);
   // printf("%-6d%-10s%-6.3f\n", (*e1).empno, (*e1).name, (*e1).sal);
    return;
}