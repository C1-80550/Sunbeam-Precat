// write emp (emp structure) info into text file using fprintf
#include<stdio.h>
struct emp
{
    int empno;
    char name[10];
    float sal;
};
void accept_emp_info(struct emp *e1);
int main(void)
{
    FILE *fpEmpWrite=NULL;
    struct emp e;

    fpEmpWrite= fopen("empinfo.txt","a");
    if( fpEmpWrite==NULL)
        printf("\n Unable to open file for write");
    else
    {
        accept_emp_info(&e);
        fprintf(fpEmpWrite,"%d\t%s\t%f\n",e.empno, e.name, e.sal );
        printf("\n record is added into file");
        fclose(fpEmpWrite);
    }
    return 0;
}

void accept_emp_info(struct emp *e1)
{
    fprintf(stdout,"\n Enter emp no= ");
    fscanf(stdin,"%d", &e1->empno);
    fprintf(stdout,"\n Enter emp name= ");
    fscanf(stdin,"%s",e1->name);
    fprintf(stdout,"\n Enter emp sal = ");
    fscanf(stdin,"%f", &e1->sal);
    return;
}