/*
1. write a data char by char into text file using fgetc
2. read a data char by char from text file using fgetc
3. write a data string by string  (no of chars) into text file using fputs
4. read data string by string  (no of chars) from text file using fgets
5. write emp info into text file using fprintf
6. read emp data from text file using fscanf
7. write emp info into binary file using fwrite
8. read emp data from binary file using fread
9. count no of words from text file
10. use of fseek 
*/